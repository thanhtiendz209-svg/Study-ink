import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:study_ink/models/notebook.dart';
import 'package:study_ink/services/notebook_asset_store.dart';
import 'package:study_ink/services/zip_notebook_backup.dart';

void main() {
  test('ZIP backup stores shared images once and restores with a fresh ID', () async {
    final root = await Directory.systemTemp.createTemp('studyink_v06_zip_');
    try {
      final assets = NotebookAssetStore(rootOverride: root);
      final book = Notebook.create(title: 'Ôn tập Vật lí');
      final bytes = Uint8List.fromList([137, 80, 78, 71, 13, 10, 26, 10]);
      final id = await assets.put(book.id, bytes);
      book.pages.first.backgroundAssetId = id;
      book.pages.first.elements.add(PageElement(
        id: 'img', type: 'image', x: 50, y: 60, width: 200,
        height: 80, imageAssetId: id,
      ));
      book.pages.first.strokes.add(InkStroke(
        kind: 'pen', color: 0xff123456, width: 3,
        points: [const InkPoint(1, 2), const InkPoint(3, 4)],
      ));
      final zipBytes = await ZipNotebookBackup.encode(book, assets);
      final zip = ZipDecoder().decodeBytes(zipBytes, verify: true);
      expect(zip.length, 3); // meta.json + notebook.json + single media
      expect(zip.any((e) => e.name == 'media/$id.bin'), isTrue);
      expect(zipBytes.length, greaterThan(10));
      final bundle = ZipNotebookBackup.decode(zipBytes);
      expect(bundle.media.length, 1);
      final restored = await bundle.restore(assets, newId: 'restored_2026');
      expect(restored.id, 'restored_2026');
      expect(restored.title, 'Ôn tập Vật lí');
      expect(restored.pages.single.strokes.single.points.length, 2);
      expect(restored.pages.single.backgroundAssetId, id);
      expect(restored.pages.single.elements.single.imageAssetId, id);
      expect(await assets.read(restored.id, id), bytes);
      // A generated ZIP must not mutate the source notebook.
      expect(book.pages.single.backgroundAssetId, id);
    } finally {
      await root.delete(recursive: true);
    }
  });

  test('ZIP rejects unknown path entries (no zip-slip extraction)', () {
    final book = Notebook.create();
    final zip = Archive()
      ..add(ArchiveFile.string('meta.json', jsonEncode({
        'format': 'studyink-zip', 'version': 1, 'mediaCount': 0,
      })))
      ..add(ArchiveFile.string('notebook.json', book.encode()))
      ..add(ArchiveFile.string('../escape.txt', 'x'));
    expect(() => ZipNotebookBackup.decode(
      ZipEncoder().encodeBytes(zip)), throwsFormatException);
  });

  test('ZIP rejects missing images and digest mismatches', () {
    final book = Notebook.create();
    final bytes = Uint8List.fromList([1, 2, 3, 4]);
    final id = sha256.convert(bytes).toString();
    book.pages.first.backgroundAssetId = id;
    Archive container({required bool includeAsset, bool corrupt = false}) {
      final a = Archive()
        ..add(ArchiveFile.string('meta.json', jsonEncode({
          'format': 'studyink-zip', 'version': 1,
          'mediaCount': includeAsset ? 1 : 0,
        })))
        ..add(ArchiveFile.string('notebook.json', book.encode()));
      if (includeAsset) {
        a.add(ArchiveFile.bytes('media/$id.bin', corrupt ? [9, 9] : bytes));
      }
      return a;
    }
    expect(() => ZipNotebookBackup.decode(
      ZipEncoder().encodeBytes(container(includeAsset: false))),
      throwsFormatException);
    expect(() => ZipNotebookBackup.decode(
      ZipEncoder().encodeBytes(container(includeAsset: true, corrupt: true))),
      throwsFormatException);
  });

  test('ZIP supports legacy inline Base64 input without modifying original', () async {
    final root = await Directory.systemTemp.createTemp('studyink_v06_inline_');
    try {
      final assets = NotebookAssetStore(rootOverride: root);
      final book = Notebook.create();
      book.pages.first.backgroundImageBase64 = base64Encode([2, 3, 4]);
      final zipBytes = await ZipNotebookBackup.encode(book, assets);
      final restored = ZipNotebookBackup.decode(zipBytes);
      expect(restored.media.length, 1);
      expect(book.pages.first.backgroundImageBase64, isNotNull);
      expect(restored.book.pages.first.backgroundImageBase64, isNull);
    } finally {
      await root.delete(recursive: true);
    }
  });
}
