import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:study_ink/utils/touch_navigation.dart';

void main() {
  test('two-finger zoom keeps content under the moving focal point', () {
    final original = Matrix4.identity();
    final result = TouchNavigation.transform(original,
        const Offset(100, 100), const Offset(110, 120), 2);
    expect(result.getMaxScaleOnAxis(), 2);
    expect(result.entry(0, 3), -90);
    expect(result.entry(1, 3), -80);
  });

  test('pinch zoom cannot exceed page zoom bounds', () {
    final original = Matrix4.identity();
    final result = TouchNavigation.transform(original,
        Offset.zero, Offset.zero, 500);
    expect(result.getMaxScaleOnAxis(), 5);
    final invalid = TouchNavigation.transform(original,
        Offset.zero, Offset.zero, -1);
    expect(invalid.getMaxScaleOnAxis(), 1);
  });
}
