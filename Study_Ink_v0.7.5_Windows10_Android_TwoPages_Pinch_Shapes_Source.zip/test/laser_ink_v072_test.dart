import 'package:flutter_test/flutter_test.dart';
import 'package:study_ink/models/laser_ink.dart';
import 'package:study_ink/models/notebook.dart';

void main() {
  final t0 = DateTime.utc(2026, 11, 2, 0, 0, 0);
  test('laser draws while held and fades only after release', () {
    final session = LaserInkSession();
    session.start(const InkPoint(10, 20), color: 0xffff315a, width: 5,
      duration: const Duration(seconds: 3));
    session.append(const InkPoint(10, 20)); // deduplicate jitter
    session.append(const InkPoint(80, 20));
    expect(session.traces.single.stroke.points.length, 2);
    expect(session.traces.single.opacityAt(t0.add(const Duration(minutes: 1))), 1);
    session.finish(t0);
    expect(session.traces.single.opacityAt(t0.add(const Duration(seconds: 2))), 1);
    expect(session.traces.single.opacityAt(t0.add(const Duration(milliseconds: 2600))),
      closeTo(0.5, 0.02));
    expect(session.traces.single.opacityAt(t0.add(const Duration(seconds: 3))), 0);
    expect(session.removeExpired(t0.add(const Duration(seconds: 3))), isTrue);
    expect(session.isEmpty, isTrue);
  });

  test('two laser gestures expire independently', () {
    final session = LaserInkSession();
    session.start(const InkPoint(1, 1), color: 0xff00ff00, width: 3,
      duration: const Duration(seconds: 2));
    session.finish(t0);
    session.start(const InkPoint(9, 9), color: 0xffff0000, width: 6,
      duration: const Duration(seconds: 5));
    session.finish(t0.add(const Duration(seconds: 1)));
    session.removeExpired(t0.add(const Duration(seconds: 2)));
    expect(session.traces.length, 1);
    expect(session.traces.single.stroke.color, 0xffff0000);
  });

  test('cancel removes only in-progress laser; clear removes all', () {
    final session = LaserInkSession();
    session.start(const InkPoint(1, 1), color: 0xffff0000, width: 4,
      duration: const Duration(seconds: 3));
    session.finish(t0);
    session.start(const InkPoint(2, 2), color: 0xff00ff00, width: 4,
      duration: const Duration(seconds: 3));
    session.cancel();
    expect(session.traces.length, 1);
    session.clear();
    expect(session.isEmpty, isTrue);
  });

  test('laser never changes notebook serialization or saved strokes', () {
    final book = Notebook.create();
    final before = book.encode();
    final session = LaserInkSession();
    session.start(const InkPoint(20, 40), color: 0xffff315a, width: 5,
      duration: const Duration(seconds: 3));
    session.append(const InkPoint(90, 40));
    session.finish(t0);
    expect(book.encode(), before);
    expect(book.pages.first.strokes, isEmpty);
  });

  test('laser remains visible while held regardless of expiration clock', () {
    final session = LaserInkSession();
    session.start(const InkPoint(5, 5), color: 0xffff315a, width: 5,
      duration: const Duration(seconds: 2));
    expect(session.removeExpired(t0.add(const Duration(days: 9))), false);
    expect(session.traces.single.opacityAt(t0.add(const Duration(days: 9))), 1);
  });
}
