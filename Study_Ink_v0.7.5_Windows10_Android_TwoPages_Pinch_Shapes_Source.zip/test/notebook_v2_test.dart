import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:study_ink/models/notebook.dart';

void main() {
  test('v0.1 backup remains readable in v0.3', () {
    final oldData = {
      'format': 'studyink',
      'schemaVersion': 1,
      'id': 'legacy1',
      'title': 'Old notes',
      'updatedAt': '2026-09-01T00:00:00.000',
      'pages': [
        {'id': 'p1', 'pattern': 'grid', 'strokes': []}
      ],
    };
    final restored = Notebook.decode(jsonEncode(oldData));
    expect(restored.pages.length, 1);
    expect(restored.pages.first.backgroundImageBase64, isNull);
    expect(restored.toJson()['schemaVersion'], 5);
  });

  test('raster background and ink survive serialization and duplicate', () {
    final notebook = Notebook.create();
    notebook.pages.first.backgroundImageBase64 = base64Encode([137, 80, 78]);
    notebook.pages.first.strokes.add(InkStroke(
      kind: 'pen', color: 0xff333333, width: 2,
      points: [const InkPoint(10, 20), const InkPoint(30, 40, 1.2)],
    ));
    final decoded = Notebook.decode(notebook.encode());
    final cloned = decoded.pages.first.duplicate('second');
    expect(cloned.id, 'second');
    expect(cloned.backgroundImageBase64, notebook.pages.first.backgroundImageBase64);
    cloned.strokes.first.points.add(const InkPoint(99, 99));
    expect(decoded.pages.first.strokes.first.points.length, 2);
    final moved = decoded.pages.first.strokes.first.translated(5, -2);
    expect(moved.points.first.x, 15);
    expect(moved.points.first.y, 18);
    expect(decoded.pages.first.strokes.first.points.first.x, 10);
  });
}
