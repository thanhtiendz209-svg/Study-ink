import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:study_ink/models/notebook.dart';
import 'package:study_ink/widgets/page_painter.dart';
import 'package:study_ink/services/import_service.dart';
import 'package:study_ink/utils/lasso_geometry.dart';

void main() {
  test('smooth path retains endpoints and has measurable length', () {
    final path = PagePainter.smoothPath([
      const InkPoint(10, 10), const InkPoint(30, 50),
      const InkPoint(60, 40), const InkPoint(90, 80),
    ]);
    expect(path.getBounds().left, closeTo(10, 0.001));
    expect(path.getBounds().right, closeTo(90, 0.001));
    expect(path.computeMetrics().first.length, greaterThan(100));
  });

  test('repaint triggers on revision while stroke list instance stays same', () {
    final ink = <InkStroke>[];
    final original = PagePainter(pattern: PaperPattern.blank,
      strokes: ink, revision: 1, pageId: 'p1');
    final updated = PagePainter(pattern: PaperPattern.blank,
      strokes: ink, revision: 2, pageId: 'p1');
    expect(updated.shouldRepaint(original), isTrue);
    final unchanged = PagePainter(pattern: PaperPattern.blank,
      strokes: ink, revision: 1, pageId: 'p1');
    expect(unchanged.shouldRepaint(original), isFalse);
  });

  test('lasso can encompass two independent editable overlays', () {
    final elements = [
      PageElement(id: 'text', type: 'text', x: 10, y: 10,
        width: 50, height: 30),
      PageElement(id: 'image', type: 'image', x: 100, y: 80,
        width: 40, height: 50),
      PageElement(id: 'far', type: 'text', x: 700, y: 900,
        width: 50, height: 50),
    ];
    const selection = [Offset(0, 0), Offset(220, 0),
      Offset(220, 220), Offset(0, 220)];
    final chosen = <int>{};
    for (var i = 0; i < elements.length; i++) {
      if (LassoGeometry.intersectsRect(
          PagePainter.elementBounds(elements[i]), selection)) {
        chosen.add(i);
      }
    }
    expect(chosen, {0, 1});
    expect(elements[1].translated(10, 5).x, 110);
    expect(elements[1].x, 100);
  });

  test('rejects invalid PDF page window before opening a document', () async {
    await expectLater(ImportService.rasterizePdf(Uint8List(0),
      startPage: 0), throwsFormatException);
    await expectLater(ImportService.rasterizePdf(Uint8List(0),
      pageCount: 31), throwsFormatException);
  });
}
