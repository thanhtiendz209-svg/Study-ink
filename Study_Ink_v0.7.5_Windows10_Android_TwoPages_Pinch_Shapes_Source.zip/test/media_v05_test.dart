import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:study_ink/models/notebook.dart';
import 'package:study_ink/services/notebook_asset_store.dart';

void main() {
  test('externalizing inline media keeps editable layout and roundtrips', () async {
    final temp = await Directory.systemTemp.createTemp('studyink_media_test_');
    try {
      final assets = NotebookAssetStore(rootOverride: temp);
      final book = Notebook.create();
      final background = Uint8List.fromList([137, 80, 78, 71, 1, 2, 3, 4]);
      book.pages.first.backgroundImageBase64 = base64Encode(background);
      book.pages.first.elements.add(PageElement(id: 'photo', type: 'image',
        x: 12, y: 34, width: 200, height: 80,
        imageBase64: base64Encode(background)));
      await assets.externalize(book);
      final page = book.pages.first;
      expect(page.backgroundImageBase64, isNull);
      expect(page.elements.single.imageBase64, isNull);
      expect(page.backgroundAssetId, page.elements.single.imageAssetId);
      expect(await assets.read(book.id, page.backgroundAssetId!), background);
      final roundtrip = Notebook.decode(book.encode());
      expect(roundtrip.toJson()['schemaVersion'], 5);
      expect(roundtrip.pages.single.elements.single.x, 12);
      expect(roundtrip.pages.single.elements.single.imageAssetId,
          page.backgroundAssetId);
      expect(book.encode().contains('backgroundImageBase64'), isFalse);
    } finally {
      await temp.delete(recursive: true);
    }
  });

  test('asset identifiers cannot escape notebook folder', () async {
    final temp = await Directory.systemTemp.createTemp('studyink_media_test_');
    try {
      final assets = NotebookAssetStore(rootOverride: temp);
      await expectLater(assets.read('mybook', '../../foo'), throwsFormatException);
      await expectLater(assets.put('../escape', Uint8List.fromList([1])), throwsFormatException);
    } finally {
      await temp.delete(recursive: true);
    }
  });
}
