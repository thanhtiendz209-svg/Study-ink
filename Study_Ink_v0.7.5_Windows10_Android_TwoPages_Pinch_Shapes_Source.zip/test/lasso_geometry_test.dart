import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:study_ink/models/notebook.dart';
import 'package:study_ink/utils/lasso_geometry.dart';

void main() {
  const square = [Offset(0, 0), Offset(100, 0),
    Offset(100, 100), Offset(0, 100)];

  test('polygon test for inside/outside points', () {
    expect(LassoGeometry.pointInside(const Offset(50, 50), square), isTrue);
    expect(LassoGeometry.pointInside(const Offset(150, 50), square), isFalse);
  });

  test('stroke crossing polygon edge is selected', () {
    final line = InkStroke(kind: 'pen', color: 0xff000000, width: 3,
      points: [const InkPoint(-10, 50), const InkPoint(110, 50)]);
    expect(LassoGeometry.selectsStroke(line, square), isTrue);
  });

  test('far-away stroke is not selected', () {
    final line = InkStroke(kind: 'pen', color: 0xff000000, width: 3,
      points: [const InkPoint(150, 150), const InkPoint(250, 250)]);
    expect(LassoGeometry.selectsStroke(line, square), isFalse);
  });

  test('lasso can select a text/photo bounding rectangle', () {
    expect(LassoGeometry.intersectsRect(
      const Rect.fromLTWH(30, 30, 20, 20), square), isTrue);
    expect(LassoGeometry.intersectsRect(
      const Rect.fromLTWH(300, 300, 20, 20), square), isFalse);
  });
}
