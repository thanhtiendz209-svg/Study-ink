import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:study_ink/models/notebook.dart';
import 'package:study_ink/utils/stroke_eraser.dart';

void main() {
  InkStroke line({String kind = 'pen', StrokePattern pattern = StrokePattern.solid}) =>
      InkStroke(kind: kind, color: 0xff123456, width: 2,
        pattern: pattern, points: [
          const InkPoint(0, 50, 0.5), const InkPoint(100, 50, 1.0),
        ]);

  test('erase middle of freehand line, retain both editable portions', () {
    final result = StrokeEraser.eraseCircle(line(), const Offset(50, 50), radius: 5);
    expect(result.changed, isTrue);
    expect(result.strokes, hasLength(2));
    expect(result.strokes.first.points.first.x, 0);
    expect(result.strokes.last.points.last.x, 100);
    expect(result.strokes.first.points.last.x, lessThan(45));
    expect(result.strokes.last.points.first.x, greaterThan(55));
    expect(result.strokes.every((s) => s.color == 0xff123456 && s.kind == 'pen'), isTrue);
    // Preserve and interpolate pressure where cuts create new endpoints.
    expect(result.strokes.first.points.last.pressure, greaterThan(0.5));
    expect(result.strokes.last.points.first.pressure, lessThan(1.0));
  });

  test('missed erase does not change original stroke or its geometry', () {
    final original = line();
    final result = StrokeEraser.eraseCircle(original, const Offset(50, 100), radius: 5);
    expect(result.changed, false);
    expect(identical(result.strokes.single, original), true);
  });

  test('erase at beginning and entirety of one-point stroke', () {
    final result = StrokeEraser.eraseCircle(line(), const Offset(0, 50), radius: 8);
    expect(result.changed, true);
    expect(result.strokes, hasLength(1));
    expect(result.strokes.single.points.first.x, greaterThan(8));
    final dot = InkStroke(kind: 'pencil', color: 0xff123456, width: 3,
      points: [const InkPoint(10, 10)]);
    expect(StrokeEraser.eraseCircle(dot, const Offset(10, 10), radius: 3).strokes, isEmpty);
  });

  test('fast eraser motion sweeps continuous area between pointer events', () {
    final result = StrokeEraser.eraseSweep(line(),
      const Offset(50, 0), const Offset(50, 100), radius: 8);
    expect(result.changed, true);
    expect(result.strokes, hasLength(2));
  });

  test('brush strokes retain kind and width and are serializable after split', () {
    final brush = line(kind: 'brush');
    final result = StrokeEraser.eraseCircle(brush, const Offset(50, 50), radius: 5);
    expect(result.strokes, hasLength(2));
    final book = Notebook.create()..pages.first.strokes.addAll(result.strokes);
    final restored = Notebook.decode(book.encode());
    expect(restored.pages.first.strokes, hasLength(2));
    expect(restored.pages.first.strokes.every((s) => s.kind == 'brush' && s.width == 2), true);
  });

  test('dashed geometric line is partially erased without erasing remaining dashes', () {
    final dash = line(kind: 'line', pattern: StrokePattern.dashed);
    final result = StrokeEraser.eraseCircle(dash, const Offset(20, 50), radius: 6);
    expect(result.changed, true);
    expect(result.strokes, isNotEmpty);
    expect(result.strokes.every((s) => s.kind == 'pen'), true);
    expect(result.strokes.every((s) => s.pattern == StrokePattern.solid), true);
  });

  test('erase a part of rectangle and keep remaining sides', () {
    final rectangle = InkStroke(kind: 'rectangle', color: 0xff000000, width: 3,
      points: [const InkPoint(10, 10), const InkPoint(100, 100)]);
    final result = StrokeEraser.eraseCircle(rectangle, const Offset(50, 10), radius: 10);
    expect(result.changed, true);
    expect(result.strokes.length, greaterThanOrEqualTo(2));
    expect(result.strokes.every((s) => s.kind == 'pen'), true);
  });

  test('cube hidden edges remain after erasing a visible line', () {
    final cube = InkStroke(kind: 'cube', color: 0xff000000, width: 3,
      points: [const InkPoint(10, 10), const InkPoint(230, 190)]);
    final result = StrokeEraser.eraseCircle(cube, const Offset(10, 90), radius: 7);
    expect(result.changed, true);
    expect(result.strokes, isNotEmpty);
    expect(result.strokes.any((s) => Color(s.color).a < 1), true);
    final untouched = StrokeEraser.eraseCircle(cube, const Offset(450, 450), radius: 7);
    expect(untouched.changed, false);
    expect(untouched.strokes.single.kind, 'cube');
  });
}
