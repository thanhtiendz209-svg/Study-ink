import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:study_ink/models/notebook.dart';
import 'package:study_ink/utils/stroke_eraser.dart';
import 'package:study_ink/widgets/page_painter.dart';
import 'package:study_ink/widgets/stroke_geometry.dart';

void main() {
  InkStroke shape(String kind, {StrokePattern pattern = StrokePattern.solid}) =>
      InkStroke(kind: kind, color: 0xff2563eb, width: 4.5,
        pattern: pattern,
        points: [const InkPoint(10, 20), const InkPoint(210, 180)]);

  test('triangle, parallelogram and hexagon have closed outlines', () {
    final starts = <String, Offset>{
      'triangle': const Offset(110, 20),
      'parallelogram': const Offset(58, 20),
      'hexagon': const Offset(60, 20),
    };
    for (final entry in starts.entries) {
      final source = shape(entry.key);
      final geometry = StrokeGeometry.pathFor(source);
      final metrics = geometry.computeMetrics().toList();
      expect(metrics, hasLength(1), reason: entry.key);
      expect(metrics.single.isClosed, isTrue, reason: entry.key);
      expect(metrics.single.length, greaterThan(400), reason: entry.key);
      expect(PagePainter.touchesStroke(source, entry.value, radius: 9), isTrue,
        reason: '${entry.key} should be selectable on an edge');
    }
  });

  test('new shapes preserve pattern, width and color across save and undo copy', () {
    final book = Notebook.create(title: 'Hình học');
    for (final name in ['triangle', 'parallelogram', 'hexagon']) {
      book.pages.first.strokes.add(shape(name, pattern: StrokePattern.dashed));
    }
    final restored = Notebook.decode(book.encode());
    for (final stroke in restored.pages.first.strokes) {
      expect(stroke.pattern, StrokePattern.dashed);
      expect(stroke.width, 4.5);
      expect(stroke.color, 0xff2563eb);
      expect(stroke.clone().kind, stroke.kind);
      final dashed = StrokeGeometry.patternPath(
          StrokeGeometry.pathFor(stroke), stroke.pattern, stroke.width);
      expect(dashed.computeMetrics().length, greaterThan(3));
    }
    // The old v0.6 format still deserializes, keeping default solid lines.
    final old = InkStroke.fromJson({
      'kind': 'rectangle', 'color': 0xff000000, 'width': 2,
      'points': [{'x': 0, 'y': 0}, {'x': 20, 'y': 20}],
    });
    expect(old.pattern, StrokePattern.solid);
  });

  test('partial eraser splits the outline of new shapes when it touches them', () {
    for (final name in ['triangle', 'parallelogram', 'hexagon']) {
      final s = shape(name);
      final metrics = StrokeGeometry.pathFor(s).computeMetrics().toList();
      final point = metrics.first.getTangentForOffset(metrics.first.length * .25)!.position;
      final erased = StrokeEraser.eraseCircle(s, point, radius: 11);
      expect(erased.changed, isTrue, reason: name);
      expect(erased.strokes, isNotEmpty, reason: name);
      expect(erased.strokes.every((e) => e.kind == 'pen'), isTrue);
      // The original geometry stays editable if the eraser doesn't touch it.
      final miss = StrokeEraser.eraseCircle(s, const Offset(850, 1000), radius: 11);
      expect(miss.changed, isFalse);
      expect(miss.strokes.single.kind, name);
    }
  });

  test('partial eraser also accepts dashed new geometry', () {
    final source = shape('triangle', pattern: StrokePattern.dashed);
    final result = StrokeEraser.eraseSweep(
      source, const Offset(105, 10), const Offset(115, 35), radius: 14);
    expect(result.changed, isTrue);
    expect(result.strokes, isNotEmpty);
  });
}
