import 'dart:math' as math;

import 'package:flutter_test/flutter_test.dart';
import 'package:study_ink/models/notebook.dart';
import 'package:study_ink/utils/shape_recognizer.dart';

void main() {
  InkStroke freehand(List<InkPoint> points, {String kind = 'pen'}) => InkStroke(
    kind: kind, color: 0xff0d5cc9, width: 4,
    pattern: StrokePattern.dashed, points: points);

  List<InkPoint> segment(double ax, double ay, double bx, double by,
      {int steps = 20}) => [
    for (var i = 0; i <= steps; i++)
      InkPoint(ax + (bx - ax) * i / steps,
          ay + (by - ay) * i / steps),
  ];

  test('straight freehand stroke becomes editable straight line', () {
    final points = [
      for (var i = 0; i <= 50; i++)
        InkPoint(20 + i * 5, 30 + i * .8 + math.sin(i * .4)),
    ];
    final recognized = ShapeRecognizer.recognize(freehand(points));
    expect(recognized?.kind, 'line');
    expect(recognized!.points, hasLength(2));
    expect(recognized.width, 4);
    expect(recognized.color, 0xff0d5cc9);
    expect(recognized.pattern, StrokePattern.dashed);
  });

  test('closed hand-drawn rectangle becomes rectangle', () {
    final points = <InkPoint>[
      ...segment(40, 50, 250, 50),
      ...segment(250, 50, 250, 185),
      ...segment(250, 185, 40, 185),
      ...segment(40, 185, 42, 52),
    ];
    expect(ShapeRecognizer.recognize(freehand(points))?.kind, 'rectangle');
  });

  test('drawn triangle becomes upright triangle', () {
    final points = <InkPoint>[
      ...segment(40, 225, 150, 35),
      ...segment(150, 35, 260, 225),
      ...segment(260, 225, 40, 225),
    ];
    expect(ShapeRecognizer.recognize(freehand(points))?.kind, 'triangle');
  });

  test('round closed shape becomes editable ellipse', () {
    final points = [
      for (var i = 0; i <= 100; i++)
        InkPoint(180 + (95 + math.sin(i * .2)) * math.cos(i * math.pi / 50),
            140 + (65 + math.cos(i * .3)) * math.sin(i * math.pi / 50)),
    ];
    expect(ShapeRecognizer.recognize(freehand(points))?.kind, 'ellipse');
  });

  test('writing, short marks, unfinished boxes and laser are not converted', () {
    final tiny = segment(10, 10, 31, 12);
    expect(ShapeRecognizer.recognize(freehand(tiny)), isNull);
    expect(ShapeRecognizer.recognize(freehand(
      [...segment(20, 20, 220, 20), ...segment(220, 20, 220, 180)])), isNull);
    final zigzag = [
      ...segment(30, 30, 100, 180),
      ...segment(100, 180, 140, 40),
      ...segment(140, 40, 220, 190),
    ];
    expect(ShapeRecognizer.recognize(freehand(zigzag)), isNull);
    expect(ShapeRecognizer.recognize(freehand(zigzag, kind: 'laser')), isNull);
  });

  test('recognized geometry is still serializable and editable', () {
    final input = freehand(segment(15, 25, 215, 110));
    final output = ShapeRecognizer.recognize(input)!;
    final notebook = Notebook.create();
    notebook.pages.first.strokes.add(output);
    final restored = Notebook.decode(notebook.encode());
    expect(restored.pages.first.strokes.single.kind, 'line');
    expect(restored.pages.first.strokes.single.points.last.x, 215);
  });
}
