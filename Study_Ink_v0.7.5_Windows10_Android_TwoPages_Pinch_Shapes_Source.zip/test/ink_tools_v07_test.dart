import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:study_ink/models/notebook.dart';
import 'package:study_ink/widgets/stroke_geometry.dart';
import 'package:study_ink/widgets/page_painter.dart';

void main() {
  test('legacy strokes default to solid; new style survives undo and JSON', () {
    final legacy = InkStroke.fromJson({'kind': 'line', 'color': 0xff112233,
      'width': 3, 'points': [{'x': 1, 'y': 2}, {'x': 100, 'y': 30}]});
    expect(legacy.pattern, StrokePattern.solid);
    final dashed = InkStroke(kind: 'cube', color: 0xff000000, width: 4,
      pattern: StrokePattern.dashed,
      points: [const InkPoint(10, 10), const InkPoint(210, 180)]);
    expect(InkStroke.fromJson(dashed.toJson()).pattern, StrokePattern.dashed);
    expect(dashed.clone().pattern, StrokePattern.dashed);
    expect(dashed.translated(5, 5).pattern, StrokePattern.dashed);
    final book = Notebook.create();
    book.pages.first.strokes.add(dashed);
    expect(Notebook.decode(book.encode()).pages.first.strokes.first.pattern,
      StrokePattern.dashed);
  });

  test('box has visible and hidden edges; dashed path shortens draw segments', () {
    final box = InkStroke(kind: 'cube', color: 0xff000000, width: 3,
      points: [const InkPoint(10, 10), const InkPoint(210, 170)]);
    final paths = StrokeGeometry.cubePaths(const Rect.fromLTWH(10, 10, 200, 160));
    expect(paths.$1.computeMetrics().length, greaterThan(1));
    expect(paths.$2.computeMetrics().length, 3);
    final dashed = StrokeGeometry.patternPath(paths.$1, StrokePattern.dashed, 3);
    expect(dashed.computeMetrics().length, greaterThan(paths.$1.computeMetrics().length));
    expect(PagePainter.touchesStroke(box, const Offset(10, 80)), isTrue);
  });

  test('arrow and custom ink tools create paths and preserve data', () {
    for (final kind in ['pencil', 'brush', 'calligraphy', 'marker', 'arrow']) {
      final s = InkStroke(kind: kind, color: 0xff345678, width: 2,
        points: [const InkPoint(0, 0), const InkPoint(90, 90)]);
      expect(InkStroke.fromJson(s.toJson()).kind, kind);
    }
    final arrow = InkStroke(kind: 'arrow', color: 0xff000000, width: 2,
      points: [const InkPoint(0, 0), const InkPoint(100, 0)]);
    expect(StrokeGeometry.pathFor(arrow).computeMetrics().first.length,
      greaterThan(99));
  });
}
