import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:study_ink/models/notebook.dart';
import 'package:study_ink/services/notebook_repository.dart';
import 'package:study_ink/services/portable_backup.dart';

void main() {
  test('v5 compresses repeated ink point JSON without losing precision', () {
    final book = Notebook.create(title: 'Bài ghi toán');
    book.pages.first.strokes.add(InkStroke(
      kind: 'pen', color: 0xff123456, width: 2.75,
      points: [
        for (var i = 0; i < 250; i++)
          InkPoint(i / 7, i * 2 / 9, i.isEven ? 1.0 : 0.654321),
      ],
    ));
    final compact = book.encode();
    final legacy = jsonEncode(book.toLegacyJson());
    expect(compact.length, lessThan(legacy.length));
    expect(Notebook.decode(compact).pages.first.strokes.first.points[137].pressure,
        0.654321);
    expect(Notebook.decode(legacy).pages.first.strokes.first.points[136].x,
        136 / 7);
    expect(Notebook.decode(compact).toJson()['schemaVersion'], 5);
    expect(book.toLegacyJson()['schemaVersion'], 4);
  });

  test('legacy map points and invalid compact points are handled', () {
    final old = InkPoint.fromJson({'x': 12.25, 'y': 30, 'pressure': 0.8});
    expect(old.toJson(), [12.25, 30, 0.8]);
    expect(InkPoint.fromJson([12.25, 30]).pressure, 1);
    expect(() => InkPoint.fromJson([1]), throwsFormatException);
    expect(() => InkPoint.fromJson([1, 'wrong']), throwsFormatException);
  });

  test('portable legacy backup actually remains schema v4', () async {
    final book = Notebook.create();
    book.pages.first.strokes.add(InkStroke(kind: 'pen', color: 0xff000000,
        width: 3, points: [const InkPoint(1, 2, 0.7)]));
    final root = await Directory.systemTemp.createTemp('studyink_legacy_backup_');
    try {
      final repo = NotebookRepository(rootOverride: root);
      final backup = await PortableBackup.encode(book, repo.assets);
      final json = jsonDecode(backup) as Map<String, dynamic>;
      final page = (json['pages'] as List).first as Map<String, dynamic>;
      final stroke = (page['strokes'] as List).first as Map<String, dynamic>;
      expect(json['schemaVersion'], 4);
      expect((stroke['points'] as List).first, isA<Map>());
      expect(Notebook.decode(backup).pages.first.strokes.first.points.first.pressure, 0.7);
    } finally {
      await root.delete(recursive: true);
    }
  });

  test('cleanup keeps media used by .bak and removes only truly orphaned blobs', () async {
    final root = await Directory.systemTemp.createTemp('studyink_cleanup_');
    try {
      final repo = NotebookRepository(rootOverride: root);
      final book = Notebook.create();
      final assetA = await repo.assets.put(book.id, Uint8List.fromList([1, 2, 3]));
      final assetB = await repo.assets.put(book.id, Uint8List.fromList([4, 5, 6, 7]));
      book.pages.first.backgroundAssetId = assetA;
      await repo.save(book);
      book.pages.first.backgroundAssetId = assetB;
      await repo.save(book); // backup references A, current references B.
      var report = await repo.inspectMedia(book.id);
      expect(report.unusedFileCount, 0);
      book.pages.first.backgroundAssetId = null;
      await repo.save(book); // backup references B; A is now unused.
      report = await repo.inspectMedia(book.id);
      expect(report.unusedFileCount, 1);
      expect(report.unusedBytes, 3);
      final cleaned = await repo.inspectMedia(book.id, removeUnused: true);
      expect(cleaned.unusedFileCount, 1);
      expect(await repo.assets.read(book.id, assetB), [4, 5, 6, 7]);
      await expectLater(repo.assets.read(book.id, assetA), throwsA(isA<FileSystemException>()));
    } finally {
      await root.delete(recursive: true);
    }
  });

  test('cleanup refuses to delete if the backup snapshot is corrupt', () async {
    final root = await Directory.systemTemp.createTemp('studyink_cleanup_error_');
    try {
      final repo = NotebookRepository(rootOverride: root);
      final book = Notebook.create();
      final asset = await repo.assets.put(book.id, Uint8List.fromList([8]));
      await repo.save(book);
      final backup = File('${root.path}/study_ink/${book.id}.json.bak');
      await backup.writeAsString('{broken');
      await expectLater(repo.inspectMedia(book.id, removeUnused: true), throwsFormatException);
      expect(await repo.assets.read(book.id, asset), [8]);
    } finally {
      await root.delete(recursive: true);
    }
  });
}
