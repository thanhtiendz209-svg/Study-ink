import 'package:flutter_test/flutter_test.dart';
import 'package:study_ink/models/notebook.dart';

void main() {
  test('Luu va tai so tay khong mat net, ap luc va so trang', () {
    final book = Notebook.create(title: 'Toán & Vật lí');
    book.pages.first.strokes.add(InkStroke(
      kind: 'pen',
      color: 0xff2563eb,
      width: 3.5,
      points: [const InkPoint(12, 14, 0.6), const InkPoint(27, 31, 1.2)],
    ));
    book.pages.add(NotePage(id: 'second', pattern: PaperPattern.lined));

    final decoded = Notebook.decode(book.encode());
    expect(decoded.title, 'Toán & Vật lí');
    expect(decoded.pages, hasLength(2));
    expect(decoded.pages[1].pattern, PaperPattern.lined);
    expect(decoded.pages[0].strokes.single.points.last.pressure, 1.2);
    expect(decoded.pages[0].strokes.single.width, 3.5);
  });

  test('Tu choi du lieu khong dung phien ban', () {
    expect(
      () => Notebook.decode('{"format":"studyink","schemaVersion":999}'),
      throwsFormatException,
    );
  });

  test('Luon co it nhat mot trang sau khi phuc hoi', () {
    final book = Notebook.create();
    final map = book.toJson()..['pages'] = [];
    final restored = Notebook.fromJson(map);
    expect(restored.pages, hasLength(1));
  });
}
