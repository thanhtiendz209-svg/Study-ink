import 'package:flutter_test/flutter_test.dart';
import 'package:study_ink/utils/spread_layout.dart';

void main() {
  test('facing pages stay together when the active side changes', () {
    expect(SpreadLayout.visible(0, 6, twoPage: true), [0, 1]);
    expect(SpreadLayout.visible(1, 6, twoPage: true), [0, 1]);
    expect(SpreadLayout.visible(2, 6, twoPage: true), [2, 3]);
    expect(SpreadLayout.visible(3, 6, twoPage: true), [2, 3]);
  });

  test('the final odd page has only one real page', () {
    expect(SpreadLayout.visible(4, 5, twoPage: true), [4]);
    expect(SpreadLayout.visible(4, 5, twoPage: false), [4]);
    expect(SpreadLayout.visible(0, 0, twoPage: true), isEmpty);
  });
}
