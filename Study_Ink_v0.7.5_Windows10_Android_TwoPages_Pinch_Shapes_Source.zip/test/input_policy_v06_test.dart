import 'dart:ui' show PointerDeviceKind;
import 'package:flutter_test/flutter_test.dart';
import 'package:study_ink/utils/ink_input_policy.dart';

void main() {
  test('default mode accepts touch, mouse, stylus', () {
    const policy = InkInputPolicy();
    expect(policy.accepts(PointerDeviceKind.touch), isTrue);
    expect(policy.accepts(PointerDeviceKind.mouse), isTrue);
    expect(policy.accepts(PointerDeviceKind.stylus), isTrue);
    expect(policy.accepts(PointerDeviceKind.trackpad), isFalse);
  });

  test('stylus-only mode blocks touches and mouse handwriting', () {
    const policy = InkInputPolicy(stylusOnly: true);
    expect(policy.accepts(PointerDeviceKind.touch), isFalse);
    expect(policy.accepts(PointerDeviceKind.mouse), isFalse);
    expect(policy.accepts(PointerDeviceKind.stylus), isTrue);
    expect(policy.accepts(PointerDeviceKind.invertedStylus), isTrue);
  });
}
