import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:study_ink/models/notebook.dart';
import 'package:study_ink/widgets/page_painter.dart';

void main() {
  test('Tay cham vao net ve', () {
    final line = InkStroke(kind: 'line', color: 0xff000000, width: 3, points: [
      const InkPoint(0, 0), const InkPoint(100, 0),
    ]);
    expect(PagePainter.touchesStroke(line, const Offset(50, 4)), isTrue);
    expect(PagePainter.touchesStroke(line, const Offset(50, 100)), isFalse);
  });
}
