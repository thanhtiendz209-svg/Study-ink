import 'package:flutter_test/flutter_test.dart';
import 'package:study_ink/models/notebook.dart';
import 'package:study_ink/models/page_structure_history.dart';

void main() {
  test('delete page, undo restores ink and media references, redo deletes it', () {
    final assetId = List.filled(64, 'a').join();
    final pages = [
      NotePage(id: 'a'),
      NotePage(id: 'b', backgroundAssetId: assetId,
        strokes: [InkStroke(kind: 'pen', width: 3, color: 123,
          points: [const InkPoint(20, 30)])]),
      NotePage(id: 'c'),
    ];
    final history = PageStructureHistory();
    history.recordDelete(pages[1], 1);
    pages.removeAt(1);
    expect(pages.map((e) => e.id), ['a', 'c']);
    expect(history.undo(pages), 1);
    expect(pages.map((e) => e.id), ['a', 'b', 'c']);
    expect(pages[1].backgroundAssetId, assetId);
    expect(pages[1].strokes.single.points.single.x, 20);
    expect(history.redo(pages), 1);
    expect(pages.map((e) => e.id), ['a', 'c']);
  });

  test('new/duplicate page can be undone and restored', () {
    final pages = [NotePage(id: 'one')];
    final history = PageStructureHistory();
    final duplicate = pages.single.duplicate('two');
    history.recordInsert(duplicate, 1);
    pages.add(duplicate);
    // Editing after inserting is retained for redo when removed via undo.
    pages[1].strokes.add(InkStroke(kind: 'pen', color: 1,
      width: 2, points: [const InkPoint(30, 50)]));
    expect(history.undo(pages), 0);
    expect(pages.length, 1);
    expect(history.redo(pages), 1);
    expect(pages.length, 2);
    expect(pages[1].strokes.length, 1);
  });

  test('history never deletes the sole remaining page', () {
    final history = PageStructureHistory();
    final only = NotePage(id: 'only');
    history.recordInsert(only, 0);
    final pages = [only];
    expect(history.undo(pages), isNull);
    expect(pages.single.id, 'only');
    expect(history.canUndo, isTrue);
  });
}
