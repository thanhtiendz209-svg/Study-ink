import 'package:flutter_test/flutter_test.dart';
import 'package:study_ink/models/notebook_summary.dart';

void main() {
  test('small library summary round-trips without notebook images', () {
    final value = NotebookSummary(
      id: '123_abc', title: 'Giải tích',
      updatedAt: DateTime.utc(2026, 11, 2), pageCount: 42,
    );
    final restored = NotebookSummary.fromJson(value.toJson());
    expect(restored.id, '123_abc');
    expect(restored.title, 'Giải tích');
    expect(restored.pageCount, 42);
    expect(restored.updatedAt, DateTime.utc(2026, 11, 2));
    expect(restored.toJson().containsKey('pages'), isFalse);
  });

  test('reject unsafe sidecar notebook ids', () {
    expect(() => NotebookSummary.fromJson({
      'id': '../../secrets', 'pageCount': 1,
    }), throwsFormatException);
    expect(() => NotebookSummary.fromJson({
      'id': 'ok', 'pageCount': -1,
    }), throwsFormatException);
  });
}
