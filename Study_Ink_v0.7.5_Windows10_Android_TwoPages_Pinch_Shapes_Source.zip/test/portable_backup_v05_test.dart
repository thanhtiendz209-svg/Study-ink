import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:study_ink/models/notebook.dart';
import 'package:study_ink/services/notebook_asset_store.dart';
import 'package:study_ink/services/portable_backup.dart';

void main() {
  test('portable export embeds media and can be imported without local paths', () async {
    final root = await Directory.systemTemp.createTemp('studyink_backup_');
    try {
      final assets = NotebookAssetStore(rootOverride: root);
      final book = Notebook.create(title: 'Ghi chú khoa học');
      book.pages.first.backgroundImageBase64 = base64Encode([1, 2, 3]);
      book.pages.first.elements.add(PageElement(
          id: 'img', type: 'image', x: 20, y: 20,
          width: 100, height: 120, imageBase64: base64Encode([4, 5, 6])));
      await assets.externalize(book);
      final data = await PortableBackup.encode(book, assets);
      expect(data.contains('backgroundAssetId'), isFalse);
      expect(data.contains('imageAssetId'), isFalse);
      final restored = PortableBackup.decode(data);
      expect(restored.pages.first.backgroundImageBase64, base64Encode([1, 2, 3]));
      expect(restored.pages.first.elements.single.imageBase64, base64Encode([4, 5, 6]));
    } finally {
      await root.delete(recursive: true);
    }
  });

  test('rejects nonportable reference-only backup', () {
    final book = Notebook.create();
    book.pages.first.backgroundAssetId = List.filled(64, 'c').join();
    expect(() => PortableBackup.decode(book.encode()), throwsFormatException);
  });
}
