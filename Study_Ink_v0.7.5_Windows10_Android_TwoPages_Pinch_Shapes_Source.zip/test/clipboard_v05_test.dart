import 'package:flutter_test/flutter_test.dart';
import 'package:study_ink/models/notebook.dart';
import 'package:study_ink/models/selection_clipboard.dart';

void main() {
  test('copy mixed selection and paste into another page without aliasing', () {
    final source = NotePage(id: 'source', strokes: [
      InkStroke(kind: 'pen', color: 0xff123456, width: 2, points: [
        const InkPoint(100, 200), const InkPoint(160, 260),
      ]),
    ], elements: [
      PageElement(id: 'image1', type: 'image', x: 180, y: 240,
        width: 200, height: 100, imageAssetId: List.filled(64, 'a').join()),
      PageElement(id: 'text1', type: 'text', x: 150, y: 220,
        width: 220, height: 120, text: 'Bài học'),
    ]);
    final copied = SelectionClipboard.capture(source, {0}, {0, 1});
    final target = NotePage(id: 'target');
    var i = 0;
    final indices = copied.pasteInto(target, () => 'new_${i++}', x: 20, y: 30);
    expect(indices.strokes, {0});
    expect(indices.elements, {0, 1});
    expect(target.strokes.single.points.first.x, 20);
    expect(target.strokes.single.points.first.y, 30);
    expect(target.elements.first.x, 100);
    expect(target.elements.first.y, 70);
    expect(target.elements.first.imageAssetId, List.filled(64, 'a').join());
    expect(target.elements.first.id, 'new_0');
    target.elements[1].text = 'Changed';
    expect(source.elements[1].text, 'Bài học');
  });

  test('empty selection does not change destination', () {
    final source = NotePage(id: 'source');
    final clipboard = SelectionClipboard.capture(source, {}, {});
    final target = NotePage(id: 'target');
    expect(clipboard.isEmpty, isTrue);
    clipboard.pasteInto(target, () => 'unused');
    expect(target.strokes, isEmpty);
    expect(target.elements, isEmpty);
  });
}
