"""Approximate bracket/string/comment scan. NOT a Dart compiler."""
from pathlib import Path

root=Path(__file__).resolve().parents[1]
files=list(root.rglob('*.dart'))
opening='([{'
closing=')]} '
pairs={')':'(',']':'[','}':'{'}
for path in files:
    s=path.read_text('utf8')
    stack=[]
    i=0
    line=1
    while i<len(s):
        c=s[i]
        if c=='\n':line+=1;i+=1;continue
        if s.startswith('//',i):
            i=s.find('\n',i)
            if i<0:break
            continue
        if s.startswith('/*',i):
            level=1;i+=2
            while i<len(s) and level:
                if s.startswith('/*',i):level+=1;i+=2
                elif s.startswith('*/',i):level-=1;i+=2
                else:
                    if s[i]=='\n':line+=1
                    i+=1
            assert level==0,(path,line,'unterminated comment')
            continue
        raw=(c=='r' and i+1<len(s) and s[i+1] in "'\"")
        if c in "'\"" or raw:
            if raw:i+=1;c=s[i]
            # Dart interpolation syntax is not parsed (all string text skipped).
            triple=s.startswith(c*3,i)
            delim=c*(3 if triple else 1)
            i+=len(delim)
            while i<len(s) and not s.startswith(delim,i):
                if s[i]=='\n':line+=1
                if s[i]=='\\' and not raw:i+=2
                else:i+=1
            assert i<len(s),(path,line,'unterminated string')
            i+=len(delim)
            continue
        if c in opening:stack.append((c,line))
        if c in pairs:
            assert stack and stack[-1][0]==pairs[c], (path,line, 'mismatched',c,stack[-1] if stack else None)
            stack.pop()
        i+=1
    assert not stack,(path,'unclosed',stack)
print(f'PASS: {len(files)} Dart files have balanced bracket and terminated strings/comments (approximate)')
