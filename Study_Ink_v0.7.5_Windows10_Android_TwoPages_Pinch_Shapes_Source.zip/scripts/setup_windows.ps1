# Run once in PowerShell from the extracted project directory.
$ErrorActionPreference = 'Stop'
if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
  Write-Host 'Flutter SDK not found. Install Flutter, add it to PATH, then retry.' -ForegroundColor Red
  exit 1
}
flutter doctor
flutter create --project-name study_ink --platforms=windows,android .
flutter pub get
dart run pdfx:install_windows
flutter analyze
flutter test
Write-Host 'Start Windows with: flutter run -d windows' -ForegroundColor Green
Write-Host 'Start Android with: flutter run -d <android-device-id>' -ForegroundColor Green
