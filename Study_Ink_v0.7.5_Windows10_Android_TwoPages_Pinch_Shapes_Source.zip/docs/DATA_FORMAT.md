# Study Ink — dữ liệu v0.7.4

## Dữ liệu nội bộ

Schema sổ tay mới là `schemaVersion: 5`; dùng mảng điểm gọn `[x,y]` hoặc `[x,y,pressure]` để giảm dữ liệu mà không làm tròn. Bản mới vẫn đọc được schema 1–4, và mục Xuất JSON bản cũ tạo lại schema 4. `study_ink/<id>.json` giữ thông tin trang/nét và SHA-256 cho media trong `study_ink/assets/<id>/<hash>.bin`. Một sổ có thể tham chiếu cùng một ảnh từ nhiều trang.

`.json.bak` giúp khôi phục nếu bản ghi mới lỗi. **Không chuyển trực tiếp tệp JSON autosave sang thiết bị khác** vì nó không chứa ảnh.

## ZIP portable (`.studyink.zip`) — mới trong v0.6

```text
meta.json                    {"format":"studyink-zip","version":1,"mediaCount":N,...}
notebook.json                sổ tay schemaVersion 5, tham chiếu imageAssetId/backgroundAssetId
media/<sha256hex>.bin        ảnh gốc, đặt tên theo SHA-256 nội dung
```

- Sao lưu **không** chứa mật khẩu hoặc mã hóa. Ai nhận ZIP có thể đọc dữ liệu.
- Giới hạn giải nén: 160 MB ZIP, 240 MB nội dung, tối đa 512 ảnh, tối đa 20 MB/ảnh, 20 MB JSON. Có kiểm tra checksum ZIP và hash tất cả ảnh.
- Chỉ chấp nhận ba mẫu tên entry đã nêu; không tự tạo tệp từ entry path, loại trừ đường dẫn `../` hoặc liên kết.
- Ảnh tham chiếu bắt buộc có mặt và mã SHA-256 trùng dữ liệu; ảnh không tham chiếu bị từ chối.
- Khi nhập, tạo ID sổ mới rồi lưu từng ảnh theo hash để tránh ghi đè sổ cũ.
- V0.6 vẫn nhập được `.studyink.json` kiểu cũ (ảnh Base64) và vẫn xuất được khi chọn mục tương thích.

## Lịch sử chỉnh sửa

- Undo/Redo nội dung: tối đa 40 bản sao trang/ID trong bộ nhớ, như v0.5.
- Undo/Redo cấu trúc trang: tối đa 30 thao tác trong bộ nhớ, độc lập với Undo/Redo nét viết.
- Cả hai lịch sử không được lưu khi đóng ứng dụng; sổ được lưu ở trạng thái cuối cùng.

## Lưu ý dữ liệu

Có dọn media thủ công trong thư viện, kiểm tra cả `.json` và `.bak` và yêu cầu xác nhận. Không dọn khi editor đang mở; nên sao lưu trước.
