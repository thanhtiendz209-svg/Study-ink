# Tối ưu dung lượng Study Ink v0.7.4

## 1. Dữ liệu ghi chú: v5 (không làm tròn)

Các điểm của nét bút được lưu bằng mảng JSON `[x,y]` hoặc `[x,y,pressure]`, thay cho ba tên trường `x`, `y`, `pressure` lặp lại ở từng điểm. **Không làm tròn** số thực, giữ lực nhấn chính xác. Phiên bản `schemaVersion: 5` vẫn đọc được sổ có schema 1–4 và các điểm lưu dưới dạng đối tượng cũ.

- Sổ tay autosave và ZIP backup mới dùng v5.
- **Xuất JSON tương thích** vẫn tạo schema 4 với điểm dạng đối tượng; cần sử dụng mục này nếu chuyển ngược về ứng dụng cũ.
- Sổ mới v5 không thể mở trực tiếp bằng ứng dụng Study Ink v0.7.3 trở về trước. **Sao lưu trước khi nâng cấp.**
- Số liệu tiết kiệm phải tính trên tài liệu thực tế; phần chữ, ảnh và PNG/PDF không được giảm tự động bằng cách này.

## 2. Dọn ảnh không còn dùng (có xác nhận)

Trong thư viện, chọn biểu tượng cây chổi bên cạnh sổ để xem số lượng ảnh không còn được tham chiếu; chọn **Dọn dung lượng** để xóa.

- Chỉ xóa tệp `assets/<notebookId>/<sha256>.bin` không có trong **cả hai** ảnh chụp `notebook.json` và `notebook.json.bak`.
- Chặn thao tác nếu bản snapshot không đọc được, thiếu thư mục media hoặc đang có file lưu `.tmp`.
- Không tự động xóa dữ liệu để tránh mất ảnh có thể còn được Undo/Redo trong bộ nhớ cần dùng khi editor đang mở; thao tác dọn chỉ đặt ở thư viện.
- Nên sao lưu `.studyink.zip` trước khi dọn sổ quan trọng.
- Dọn ảnh không xóa nét viết trong các trang.

## 3. Dung lượng ứng dụng khi cài

Workflow `.github/workflows/build.yml` tạo APK **riêng theo ABI** bằng `flutter build apk --release --split-per-abi --split-debug-info=build/symbols/android`. GitHub Actions hiển thị kích thước thực tế của từng APK trong **Job summary**. Máy x86_64 không nên tải nhầm APK arm64; cần chọn đúng kiến trúc. Các bản phát hành này **chưa tích hợp chức năng cập nhật trong ứng dụng**.

Workflow cũng thống kê tổng kích thước thư mục ứng dụng Windows 10 x64 **chưa nén**. Windows yêu cầu giữ tất cả thư viện `.dll` và `data/` cùng file EXE.

Không có số đo trước/sau cho APK và Windows khi chưa chạy CI. File ZIP **mã nguồn** có thể lớn hơn do bổ sung test/tài liệu nhưng không phản ánh dung lượng ứng dụng đã biên dịch.

## 4. Kiểm tra chất lượng

```
flutter pub get
flutter analyze --no-fatal-infos
flutter test
flutter build apk --release --split-per-abi --split-debug-info=build/symbols/android
# Trên Windows (cần cài desktop toolchain và pdfx):
dart run pdfx:install_windows
flutter build windows --release --split-debug-info=build/symbols/windows
```

Các bài test mới kiểm tra dữ liệu v5, bản sao JSON cũ và dọn media có bảo vệ `.bak`. Cần kiểm nghiệm thực tế độ mượt nét bút, kích thước PDF, mức RAM và cài đặt trên Windows 10/Android trước khi sử dụng lâu dài.
