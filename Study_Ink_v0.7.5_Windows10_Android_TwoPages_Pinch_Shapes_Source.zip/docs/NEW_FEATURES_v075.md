# Study Ink v0.7.5 — kiểm thử tính năng mới

## Hai trang cạnh nhau
- Nhấn biểu tượng cuốn sách trên thanh trên cùng; hai trang hiện trong một vùng cuộn/thu phóng.
- Cặp trang cố định: trang 1–2; 3–4; 5–6. Khi chọn trang thứ hai của cùng cặp, trang đầu vẫn hiển thị.
- Trang được chọn có viền xanh. Nhấn bên trái/phải để chọn và viết, bôi, chọn đối tượng trên trang đó.
- Nếu trang cuối không có trang đối diện, nhấn Thêm trang đối diện.
- Thử nhập PDF 4 trang và kiểm tra ảnh nền, nét mực cả 2 trang; thử Undo theo từng trang.

## Thu phóng bằng hai ngón trong chế độ bút
- Chọn Bút mực và viết bằng một ngón; kết thúc nét phải lưu bình thường.
- Chạm ngón thứ hai trong lúc đang viết; nét chưa hoàn thành không được lưu; di chuyển 2 ngón để vừa thu phóng vừa rê trang.
- Rút một ngón; ngón còn lại không tự vẽ thêm nét. Rút cả hai ngón rồi viết lại để tạo nét mới.
- Thử với Chỉ nhận bút bật; ngón tay không vẽ, nhưng pinch vẫn hoạt động.
- Trên laptop dùng chuột có thể dùng nút zoom +/- và chế độ Bàn tay kéo trang.

## Nhận dạng hình viết tay
- Nút cây đũa phép bật/tắt nhận dạng (mặc định tắt).
- Dùng Bút mực tạo nét thẳng dài >= 45 px hoặc hình tròn, elip, chữ nhật, tam giác hướng lên khép kín đủ rõ.
- Khi nhấc bút, hình được thay bởi đối tượng hình học mà vẫn giữ màu, độ dày, kiểu nét.
- Nét ngắn, chữ viết, đường gấp khúc chưa kín, laser và nét tẩy không bị tự đổi.
- Dùng Undo để khôi phục trước thao tác nhận dạng.
- Hình hộp vẽ tự do không được tự nhận dạng ở phiên này; vẫn dùng công cụ Hình hộp riêng.

## Chạy bài kiểm thử và tạo ứng dụng
```
flutter create --project-name study_ink --platforms=windows,android .
flutter pub get
flutter analyze --no-fatal-infos
flutter test
flutter build apk --release --split-per-abi
```
Trên Windows cần Visual Studio C++ Desktop và `dart run pdfx:install_windows` trước khi build. Không dùng bản thử nghiệm để lưu bản duy nhất của ghi chú quan trọng.
