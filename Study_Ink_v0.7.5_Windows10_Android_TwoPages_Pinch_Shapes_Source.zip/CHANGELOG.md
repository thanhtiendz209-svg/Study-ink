# Study Ink — Lịch sử phát triển

## v0.7.5 — hai trang cạnh nhau, cảm ứng hai ngón, tự nắn hình (2026-11-03)

- Chế độ 1 trang/2 trang, cặp 1–2, 3–4 ổn định; hai trang trong cặp đều chọn viết được và dùng chung khung thu phóng.
- Theo dõi 2 tiếp xúc ngón tay độc lập với công cụ viết; hủy nét đang vẽ khi bắt đầu pinch để tránh nét rác; có thể vừa phóng to vừa di chuyển giấy.
- Bộ nhận dạng hình viết tay offline, opt-in: đường thẳng, chữ nhật, elip/tròn, tam giác hướng lên; nét không chắc chắn giữ nguyên; kết quả là hình có thể chỉnh sửa/lưu/Undo như các hình khác.
- Thêm kiểm thử toán thu phóng, bố cục hai trang, nhận dạng hình và chống nhận nhầm.
- Không thêm thước kẻ/thước đo góc. Chưa xác nhận Flutter build và thiết bị thật.

## v0.7.4 (tối ưu dung lượng, 2026-11-03)

- JSON nét viết v5: điểm mảng ngắn không làm tròn, đọc định dạng cũ, xuất JSON tương thích v4.
- Dọn ảnh không dùng theo yêu cầu, giữ media của .json và .bak, có xác nhận.
- GitHub Actions build APK riêng theo CPU, có bảng kích thước thực tế và thống kê Windows portable.
- Thêm 5 bài kiểm thử hồi quy. Không thêm thước kẻ hoặc thước đo góc.

## v0.7.3 (mã nguồn, 2026-11-02)

- Thêm tam giác, hình bình hành, lục giác; dùng chung đường nét cho xuất PDF, tẩy nét và hit-test.
- Cho chỉnh nét liên tục 0,5–30 px thay 5 cỡ bút; chỉnh alpha 10–100% từ bảng màu; giữ từng cấu hình màu, kiểu nét, độ rộng theo công cụ trong phiên.
- Dạ quang mới dùng đúng độ dày lựa chọn; nét dạ quang đã lưu vẫn tương thích.
- Không bổ sung thước kẻ hoặc thước đo góc.
- Unit test mới kiểm tra hình học, nét đứt, tẩy một phần và JSON tương thích; chưa chạy Flutter SDK trong môi trường soạn mã.


## v0.7.2 — laser ink (2026-11-02)

- Thêm công cụ Bút laser với màu đỏ hồng mặc định, chọn màu và kích cỡ, tùy chọn nét tắt sau 2/3/5 giây.
- Nét laser sáng có glow và fade 800 ms cuối, tồn tại trong lớp vẽ overlay và không lưu vào trang, ZIP hay PDF.
- Nhiều nét laser tự hết hạn riêng, hỗ trợ hủy nét/chuyển trang và tự dừng timer khi không còn hiệu ứng.
- Bổ sung `LaserInkSession`, `LaserInkPainter` và 5 test tự động chưa chạy với Flutter SDK.


## v0.7.1 — Tẩy một phần nét (mã nguồn)

- Tách nét viết tại đường tẩy bằng giao cắt đường tròn / đoạn thẳng; giữ đầu mút, áp lực bút, kiểu bút và màu sắc trên các đoạn còn lại.
- Quét các vị trí giữa 2 sự kiện con trỏ để tẩy liên tục khi rê nhanh. Một cử chỉ tẩy = một mốc Undo.
- Nét hình học, nét đứt hoặc chấm chỉ được làm phẳng thành các đoạn mực riêng khi thật sự chạm tẩy.
- Thêm vòng tròn xem trước và năm kích cỡ tẩy, kiểm thử hình học, nét đứt, hình hộp, sao lưu.
- Bỏ thước kẻ và thước đo góc khỏi phạm vi phát triển.
- Chưa kiểm thử Flutter runtime hoặc thiết bị thật.

- 4 loại bút mới: bút chì, bút cọ, bút thư pháp, và bổ sung bút mực/dạ quang sẵn có. Đây là mô phỏng phần mềm; chưa tương đương vật lý bút Scrble Ink.
- 16 màu dựng sẵn và bảng HSV để chọn màu tùy ý (không cần cài plugin màu).
- Kiểu nét liền / đứt / chấm, lưu theo mỗi nét và tự khôi phục khi mở lại sổ.
- Hình hộp (cube) kéo thả có các cạnh khuất nét đứt; hình mũi tên; giữ đường thẳng/chữ nhật/elip.
- Lối tắt nhập PDF trên thanh công cụ (PDF chuyển raster để viết đè, không chỉnh sửa PDF gốc).
- Tăng giới hạn độ phân giải khi render PDF từ 960 lên 1440px cạnh dài.
- Định dạng dữ liệu giữ schemaVersion 4; vẫn đọc sổ v0.6.
- Thêm test kiểm tra nét đứt, hình hộp, kiểu bút và chuyển đổi JSON.

**Lưu ý:** Bản beta chưa có áp lực nghiêng bút chuẩn vật lý, snapping hình học,
3D thực thụ hoặc chỉnh sửa vector/PDF gốc. Phải chạy GitHub Actions và kiểm thử
trên Windows 10/Android thật trước khi coi là phần mềm ổn định.
