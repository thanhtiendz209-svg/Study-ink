# Study Ink v0.7.5 — mã nguồn Flutter cho Windows 10 x64 và Android

**Study Ink** là dự án ứng dụng ghi chú viết tay offline, được phát triển tiếp từ v0.6. **Chỉ hai nền tảng mục tiêu: Windows 10 x64 và Android**. Không yêu cầu hoặc hướng dẫn nâng cấp lên Windows 11. Ứng dụng không sử dụng mã nguồn, logo hay tên thương mại của Scrble Ink.

> **Tình trạng kiểm thử:** đã viết mã nguồn và test cho những thay đổi mới, nhưng môi trường tạo ZIP không có Flutter/Dart SDK. Chưa chạy được `flutter pub get`, `flutter analyze`, `flutter test` hay build EXE/APK. Những tính năng dưới đây được **triển khai trong mã nguồn nhưng chưa được xác minh khi chạy thực tế**.

## Mới trong v0.7.5: hai trang, cử chỉ hai ngón và nhận dạng hình

- **Chế độ hai trang:** nhấn biểu tượng cuốn sách trên AppBar để đổi giữa một và hai trang. Các cặp 1–2, 3–4... nằm cạnh nhau (nếu lẻ trang cuối thì có nút thêm trang đối diện). Có thể viết lên **cả hai trang** bằng cách nhấn chọn trang cần viết; trang được chọn có viền xanh. Khung xem tự căn lại để hiển thị cả cặp, sau đó có thể phóng to.
- **Thu phóng hai ngón ngay khi viết:** dùng hai đầu ngón tay để phóng to/thu nhỏ và kéo vùng giấy bất kể công cụ bút đang chọn. Chạm một ngón vẫn viết; khi bắt đầu cử chỉ hai ngón, nét đang vẽ (nếu có) sẽ bị hủy thay vì lưu thành đường mực ngoài ý muốn. Giới hạn tỷ lệ 20–500%. Khi bật chế độ Chỉ nhận bút, hai ngón vẫn thao tác trang bình thường.
- **Nhận dạng hình vẽ tay (bật/tắt):** nhấn nút cây đũa phép trên thanh công cụ, hoặc trong menu **Tự nắn hình vẽ tay**. Khi bật, nét bút viết tay được nhận dạng thận trọng thành **đường thẳng, hình chữ nhật, hình elip (bao gồm hình tròn), tam giác hướng lên** sau khi nhấc bút. Nét viết không đủ rõ được giữ nguyên; Undo để hoàn tác chuyển đổi. Các hình sau nhận dạng là đối tượng hình học có thể chọn, tẩy từng phần, dùng nét đứt, lưu và xuất PDF. Nhận dạng chạy offline, không gửi dữ liệu lên mạng. Mặc định **tắt** để không ảnh hưởng chữ viết.
- **Giới hạn:** chưa nhận dạng hình hộp, hình nghiêng/tam giác đảo ngược, hình đa giác tự do; chưa có AI/OCR. Chế độ hai trang trên màn hình điện thoại dọc có thể nhỏ, hãy xoay ngang và phóng to. Các cải tiến cần được kiểm thử trên Windows 10 và Android thật.
- **Kiểm thử mới:** bài test đơn vị cho hình học, cặp trang, toán thu phóng; công cụ kiểm tra cấu trúc tĩnh không thay thế Flutter Analyze/Test.
- **Không bổ sung** thước kẻ hay thước đo góc theo yêu cầu.

## Tính năng giữ từ v0.7.3: bộ bút và hình học nâng cấp

- Chỉnh **độ dày bút liên tục 0,5–30 px** bằng thanh trượt trong thanh công cụ; thay menu 5 mức cũ. Bảng màu thêm thanh chỉnh **độ trong suốt 10–100%**, áp dụng cho bút và hình.
- Nhớ **độ dày, màu và kiểu nét riêng theo công cụ** trong phiên đang mở: thay đổi bút mực, bút chì, dạ quang hay công cụ hình không làm mất cấu hình vừa chọn. (Chưa lưu xuyên phiên làm việc.)
- Thêm **tam giác, hình bình hành và lục giác**. Kéo hai điểm bao để vẽ; hỗ trợ nét liền, nét đứt và nét chấm, chọn đối tượng, dời hình, tẩy từng phần, Undo/Redo, lưu và xuất PDF.
- Sửa **độ dày thật** của nét dạ quang mới: không nhân 5 lần giá trị chọn nữa. Nét dạ quang đã lưu ở v0.7.2 vẫn giữ nguyên giá trị cũ và hiển thị như trước.
- Chưa thêm thước kẻ / thước đo góc theo yêu cầu. Chưa triển khai nhận dạng chữ viết hoặc chỉnh PDF vector.
- **Kiểm thử:** Có thêm unit test cho hình mới và lưu tương thích; mã nguồn cần tiếp tục `flutter analyze`, `flutter test`, `flutter build` và thử trên thiết bị thật.

## Mới trong v0.7.2: bút laser (viết nháp tự biến mất)

- Bấm biểu tượng **tia chớp** trên thanh công cụ để chọn **Bút laser**. Vẽ bằng chuột, ngón tay hoặc bút (nếu chế độ chỉ nhận bút được tắt).
- Mặc định bút laser **đỏ hồng**, sáng với viền phát quang; có thể chọn màu nhanh, màu HSV tùy ý và độ dày từ thanh công cụ.
- Nét laser **giữ nguyên khi đang viết**, sau khi nhấc bút sẽ hiển thị rõ rồi **mờ dần và biến mất** trong 2, 3 (mặc định), hoặc 5 giây từ khi kết thúc nét.
- Nhiều nét laser hoạt động độc lập; mỗi nét tự hết hạn theo thời điểm người dùng nhấc bút. Nút xóa tức thì xóa toàn bộ laser đang hiện.
- **Hoàn toàn tạm thời:** không lưu trong JSON, ZIP, PDF, không nằm trong lịch sử Undo/Redo; đổi trang sẽ xóa laser đang hiện.
- Không dùng timer khi không còn nét laser, khoảng 30 khung hình/giây khi hiệu ứng mờ đang hoạt động.
- Có 5 unit test kiểm tra thời gian mờ, hai nét độc lập, hủy nét và không làm thay đổi tệp ghi chú.
- **Chưa biên dịch và thử trên thiết bị thật**, phải dùng Flutter/GitHub Actions để xác nhận.

## Mới trong v0.7.1: tẩy một phần nét vẽ (Windows 10 + Android)

- **Tẩy một phần:** Chọn công cụ tẩy để xóa phần mực ngay dưới đầu tẩy; các đoạn còn lại vẫn là nét riêng có thể di chuyển/chọn được. Dùng chuột, chạm hoặc stylus.
- **Rê tẩy nhanh:** Quét dọc đường đi giữa hai sự kiện chạm để tránh bỏ sót. Kích cỡ tẩy: đường kính 12 / 20 / 28 / 44 / 64 px, có vòng hiển thị đầu tẩy.
- **Hình học:** Tẩy được từng đoạn đường thẳng/nét đứt/chu vi hình hộp. Khi tẩy vào một hình, hình được chuyển thành các đoạn mực độc lập để giữ lại những phần còn thấy (không còn chỉnh kích thước như một khối hình duy nhất).
- **Undo/Redo:** Một lượt rê tẩy tạo một bước hoàn tác, tự lưu sau khi nhấc bút. Nét chưa bị tẩy không bị thay đổi.
- **Giới hạn:** Chỉ tẩy nét mực và hình được vẽ, không tẩy chữ đã nhập, ảnh hoặc nền PDF. Kết quả quanh biên tẩy cần kiểm chứng thêm trên thiết bị thật.
- **Không phát triển công cụ thước kẻ / thước đo góc** theo yêu cầu.
- **Tình trạng:** Đã sửa mã nguồn và bổ sung unit test nhưng chưa biên dịch hoặc kiểm thử thiết bị thật.

## Mới trong v0.7: vẽ hình hộp, nét đứt, bảng màu và PDF

- Bộ bút: bút mực, bút chì (mờ hơn), bút cọ (nét rộng), bút thư pháp (nét hơi rộng và có áp lực bút nếu phần cứng hỗ trợ), dạ quang.
- 16 màu gợi ý, nhấn biểu tượng **bảng màu** để chọn màu HSV tùy ý; cỡ nét có sẵn 2/3/5/8/12 px.
- Công cụ hình: đường thẳng, mũi tên, chữ nhật, elip và **hình hộp 3D biểu diễn dạng chiếu**; nhấn menu kiểu nét để chọn **liền / đứt / chấm**. Cạnh khuất của hình hộp tự hiển thị nét đứt.
- Nhấn **PDF** trên thanh công cụ để thêm tài liệu và viết lên từng trang; vẫn có giới hạn 30 MB và 30 trang/lượt. PDF gốc được hiển thị thành ảnh, không chỉnh sửa nội dung gốc.
- Thêm `test/ink_tools_v07_test.dart` kiểm tra dữ liệu tương thích v0.6, hình hộp và dash pattern.

**Tình trạng:** đã triển khai mã nguồn, nhưng phải chạy `flutter analyze`, `flutter test` và build trên GitHub trước khi coi là bản phát hành. Không nên sử dụng làm nơi lưu tài liệu duy nhất.

## Chức năng v0.1–v0.5 tiếp tục giữ

- Tạo nhiều sổ tay; thêm/xóa/nhân bản trang; giấy trắng, kẻ ngang, ô ly và chấm.
- Vẽ bằng chuột, ngón tay, bút cảm ứng; bút, dạ quang, tẩy, màu/cỡ bút, đường thẳng/chữ nhật/ellipse.
- Phóng to, thu nhỏ, khoanh chọn nhiều đối tượng, sao chép/dán nội bộ, Undo/Redo nét vẽ theo từng trang.
- Thêm/chỉnh sửa văn bản, ảnh nổi có thể di chuyển, ảnh làm nền; ghi chú lên PDF đã raster hóa.
- Lưu offline: `study_ink/<id>.json` và ảnh `study_ink/assets/<id>/<sha256>.bin`.
- Xuất PDF hình ảnh (không chỉnh sửa chữ gốc của tài liệu) và nhập bản sao JSON cũ.

## Điểm mới v0.6

### 1. Sao lưu ZIP thực sự

- Menu editor → **Sao lưu ZIP (đề xuất)** → tạo `Tên sổ.studyink.zip`.
- ZIP lưu `meta.json`, `notebook.json`, `media/<SHA-256>.bin` — không nhân 4/3 dung lượng bởi Base64 trong JSON.
- Thư viện → **Nhập bản sao sổ tay** → chọn `.zip` hoặc bản `.json` cũ.
- Kiểm tra đường dẫn, tệp lạ, trùng tên, checksum ZIP, SHA-256 của từng ảnh, và ảnh thiếu; từ chối bản sao hỏng.
- Sổ được nhập có ID mới, không ghi đè sổ hiện có. Ảnh được lưu vào thư mục asset của ID mới.
- Giới hạn thử nghiệm: ZIP 160 MB, tổng dữ liệu giải nén 240 MB, mỗi ảnh 20 MB, JSON nét viết 20 MB, tối đa 512 ảnh. Bản nhập JSON cũ tối đa 85 MB.
- **Tương thích:** v0.6 vẫn xuất được JSON kiểu v0.5 qua menu **Sao lưu JSON cho bản cũ**.

### 2. Bút cảm ứng, chế độ hạn chế chạm nhầm

- Menu editor → bật **Chỉ nhận bút khi viết** để từ chối các sự kiện vẽ từ ngón tay/chuột.
- Bút đảo đầu (`invertedStylus`) vẫn được nhận như đầu bút bình thường; chưa có xóa tự động theo đầu tẩy.
- Đây là **lọc sự kiện đầu vào**, không phải công nghệ palm rejection ở mức phần cứng. Một số bút điện dung rẻ tiền xuất hiện như `touch` và cũng bị chặn; khi đó hãy tắt chế độ.
- Để lại khả năng chọn công cụ **Bàn tay** để di chuyển trang bằng cử chỉ.

### 3. Hoàn tác thao tác với trang

- Sau khi xóa trang, một thanh thông báo có nút **Hoàn tác**.
- Menu editor → **Hoàn tác thêm/xóa trang**, **Làm lại thêm/xóa trang**; hỗ trợ thêm, nhân bản, xóa.
- Lịch sử thay đổi cấu trúc trang giới hạn 30 bước và **tách** khỏi nút Undo/Redo nét viết, tránh xóa dữ liệu ghi chú trong trang khi đổi trang.
- Bản thân lịch sử thao tác chỉ tồn tại trong phiên mở editor, không lưu vào file.

### 4. PDF theo từng trang → asset ngay

- Giữ giới hạn PDF 30 MB, nhập từ 1–30 trang/lượt.
- Thay vì giữ cùng lúc danh sách ảnh đã render dưới dạng Base64, v0.6 kết xuất **từng** trang và ghi trực tiếp vào thư mục ảnh.
- PDF vẫn được đọc vào RAM để mở và văn bản gốc chưa được chỉnh sửa trực tiếp. Chưa có benchmark chứng minh mức giảm RAM cụ thể.

## Build bản chạy thử (trên Windows 10)

Cần Flutter stable có Dart >=3.10, Visual Studio với workload **Desktop development with C++** + Windows SDK, và Android SDK nếu xây dựng APK.

```powershell
flutter doctor
flutter create --project-name study_ink --platforms=windows,android .
flutter pub get
dart run pdfx:install_windows
flutter analyze
flutter test
flutter run -d windows
```

Build phát hành nội bộ:

```powershell
flutter build windows --release
flutter build apk --release
```

**Lưu ý Windows:** phải sao chép trọn bộ thư mục `build/windows/x64/runner/Release/`, không chỉ `.exe`. Android bản release thử nghiệm cần được ký và kiểm tra trên thiết bị trước khi phân phối.

### GitHub Actions

1. Giải nén ZIP mã nguồn v0.7.5, tải toàn bộ tệp **kể cả `.github/workflows/build.yml`** vào repository riêng.
2. Vào Actions → **Build Study Ink v0.7.5 (Windows 10 x64 + Android)** → Run workflow.
3. Nếu tất cả bước `flutter analyze`, `flutter test` và build đạt, tải `study-ink-windows10-x64-portable` và `study-ink-android-test-apk` trong phần Artifacts.
4. CI Windows sử dụng Windows Server 2022 để biên dịch; việc kiểm thử trên **máy Windows 10 thực** vẫn bắt buộc. Workflow không tạo bộ cài MSI có chữ ký.

## Kiểm thử bắt buộc trước khi sử dụng ghi chú thật

- Mở sổ tay tạo bằng v0.5, tạo ZIP, chuyển sang Android rồi nhập và kiểm tra mọi trang, chữ/ảnh và nét.
- Thử nhập ZIP không đúng loại, ZIP bị lỗi, ảnh bị hỏng; ứng dụng phải báo lỗi và không ghi đè sổ khác.
- Kiểm tra xóa trang → Hoàn tác → Làm lại, nhất là trang có ảnh PDF.
- Thử bút cảm ứng thật trên Windows 10 và Android; chế độ Chỉ nhận bút cần thử với loại stylus cụ thể.
- Kiểm tra nhập PDF 20–30 trang, xuất PDF và lưu/đóng/mở lại; theo dõi RAM và lỗi treo.

## Giới hạn còn lại

Chưa xác minh biên dịch hoặc tốc độ thực tế. Chưa có OCR, đồng bộ cloud, chỉnh sửa vector/văn bản PDF gốc, dọn asset thừa, clipboard xuyên ứng dụng, hệ thống xử lý palm rejection thực sự hoặc bộ cài thương mại. Không dùng bản này như nơi lưu duy nhất của tài liệu quan trọng; hãy sao lưu đều đặn và kiểm tra mở lại tệp.

Xem [CHANGELOG.md](CHANGELOG.md), [docs/DATA_FORMAT.md](docs/DATA_FORMAT.md), [docs/ROADMAP.md](docs/ROADMAP.md).


## Tối ưu dung lượng v0.7.4

- Mã hóa nét viết gọn hơn (schema 5), giữ độ chính xác; mở được sổ cũ. Mục xuất JSON tương thích dùng schema 4.
- Nút cây chổi trong thư viện để xem và dọn ảnh dư thừa **sau khi xác nhận**, bảo vệ dữ liệu hiện tại và bản lưu dự phòng.
- Build APK theo kiến trúc CPU và hiện số MB trong GitHub Actions, không đoán trước dung lượng.
- Xem đầy đủ tại [docs/OPTIMIZATION_v074.md](docs/OPTIMIZATION_v074.md).
