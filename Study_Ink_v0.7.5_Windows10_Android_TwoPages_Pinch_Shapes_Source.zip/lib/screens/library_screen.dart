import 'package:flutter/material.dart';
import '../models/notebook.dart';
import '../models/notebook_summary.dart';
import '../services/notebook_repository.dart';
import '../services/export_service.dart';
import '../services/import_service.dart';
import '../widgets/pdf_range_dialog.dart';
import 'editor_screen.dart';

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key});

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  final _repository = NotebookRepository();
  List<NotebookSummary> _books = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    try {
      final books = await _repository.list();
      if (!mounted) return;
      setState(() {
        _books = books;
        _error = null;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = '$error';
      });
    }
  }

  Future<void> _newBook() async {
    try {
      final book = Notebook.create();
      await _repository.save(book);
      if (!mounted) return;
      await _open(book);
    } catch (e) {
      _showError(e);
    }
  }

  Future<void> _openById(String id) async {
    try {
      final book = await _repository.read(id);
      if (!mounted) return;
      await _open(book);
    } catch (e) {
      _showError(e);
    }
  }

  Future<void> _open(Notebook book) async {
    await Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => EditorScreen(book: book),
    ));
    // Ensure the latest sidecar metadata is committed before refreshing the
    // library, even if the editor's debounced autosave was still in flight.
    await _repository.save(book);
    await _refresh();
  }

  Future<void> _import() async {
    try {
      final book = await ExportService.importBackup();
      if (book == null) return;
      await _repository.externalizeMedia(book);
      await _repository.save(book);
      await _refresh();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Đã nhập bản sao sổ tay')),
      );
    } catch (e) {
      _showError(e);
    }
  }

  Future<void> _importPdf() async {
    final book = Notebook.create(title: 'Ghi chú PDF');
    var committed = false;
    try {
      final range = await choosePdfRange(context);
      if (range == null || !mounted) return;
      final pages = await ImportService.pickPdfPagesToAssets(
        bookId: book.id, assetStore: _repository.assets,
        startPage: range.start, pageCount: range.count);
      if (pages == null || pages.isEmpty) return;
      book.pages = pages;
      await _repository.save(book);
      committed = true;
      if (!mounted) return;
      await _open(book);
    } catch (error) {
      _showError(error);
    } finally {
      // Only remove temporary imported assets before the notebook is saved.
      if (!committed) {
        try { await _repository.assets.deleteBookAssets(book.id); } catch (_) {}
      }
    }
  }

  Future<void> _delete(NotebookSummary book) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Xóa sổ tay?'),
        content: Text('Xóa "${book.title}" khỏi thiết bị? Hãy sao lưu trước nếu cần.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Xóa')),
        ],
      ),
    );
    if (confirmed != true) return;
    try {
      await _repository.delete(book.id);
      await _refresh();
    } catch (e) {
      _showError(e);
    }
  }

  Future<void> _optimizeBook(NotebookSummary book) async {
    try {
      final preview = await _repository.inspectMedia(book.id);
      if (!mounted) return;
      if (preview.unusedFileCount == 0) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Không có ảnh dư thừa cần xóa.')),
        );
        return;
      }
      final mb = (preview.unusedBytes / (1024 * 1024)).toStringAsFixed(2);
      final accepted = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Dọn dung lượng sổ tay?'),
          content: Text('Phát hiện ${preview.unusedFileCount} tệp ảnh không còn được'
              ' sử dụng (khoảng $mb MB). Ảnh đang có trong bản lưu và bản'
              ' sao dự phòng .bak sẽ được giữ lại.\n\n'
              'Hãy sao lưu ZIP nếu đây là ghi chú quan trọng.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Dọn dung lượng')),
          ],
        ),
      );
      if (accepted != true) return;
      // Re-scan and check the files again before deleting anything.
      final cleaned = await _repository.inspectMedia(book.id, removeUnused: true);
      if (!mounted) return;
      final freed = (cleaned.unusedBytes / (1024 * 1024)).toStringAsFixed(2);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Đã xóa ${cleaned.unusedFileCount} ảnh không dùng, giải phóng $freed MB.'),
      ));
    } catch (error) {
      _showError(error);
    }
  }

  void _showError(Object error) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Không thể thực hiện: $error')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(
          mainAxisSize: MainAxisSize.min,
          children: [Icon(Icons.auto_stories_rounded), SizedBox(width: 10), Text('Study Ink')],
        ),
        actions: [
          IconButton(
            tooltip: 'Nhập PDF để ghi chú',
            onPressed: _importPdf,
            icon: const Icon(Icons.picture_as_pdf_outlined),
          ),
          IconButton(
            tooltip: 'Nhập bản sao sổ tay',
            onPressed: _import,
            icon: const Icon(Icons.file_upload_outlined),
          ),
          const SizedBox(width: 12),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _newBook,
        icon: const Icon(Icons.add),
        label: const Text('Sổ tay mới'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text('Không mở được thư viện: $_error'))
              : _books.isEmpty
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Column(mainAxisSize: MainAxisSize.min, children: [
                          Icon(Icons.draw_outlined, size: 76, color: Theme.of(context).colorScheme.primary),
                          const SizedBox(height: 18),
                          const Text('Sẵn sàng ghi chú?', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 8),
                          const Text('Tạo sổ tay đầu tiên để viết, vẽ và ghi lại bài học.', textAlign: TextAlign.center),
                        ]),
                      ),
                    )
                  : LayoutBuilder(builder: (context, constraints) {
                      final columns = constraints.maxWidth > 1050 ? 4 : constraints.maxWidth > 750 ? 3 : constraints.maxWidth > 480 ? 2 : 1;
                      return GridView.builder(
                        padding: const EdgeInsets.fromLTRB(20, 16, 20, 110),
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: columns,
                          mainAxisSpacing: 14,
                          crossAxisSpacing: 14,
                          mainAxisExtent: 205,
                        ),
                        itemCount: _books.length,
                        itemBuilder: (context, i) {
                          final b = _books[i];
                          return Card(
                            clipBehavior: Clip.antiAlias,
                            child: InkWell(
                              onTap: () => _openById(b.id),
                              child: Padding(
                                padding: const EdgeInsets.all(16),
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Row(children: [
                                    CircleAvatar(
                                      backgroundColor: Theme.of(context).colorScheme.primaryContainer,
                                      child: const Icon(Icons.menu_book_outlined),
                                    ),
                                    const Spacer(),
                                    IconButton(
                                      tooltip: 'Dọn ảnh không còn dùng',
                                      onPressed: () => _optimizeBook(b),
                                      icon: const Icon(Icons.cleaning_services_outlined),
                                    ),
                                    IconButton(
                                      tooltip: 'Xóa sổ tay',
                                      onPressed: () => _delete(b),
                                      icon: const Icon(Icons.delete_outline),
                                    ),
                                  ]),
                                  const Spacer(),
                                  Text(b.title, maxLines: 2, overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 18)),
                                  const SizedBox(height: 9),
                                  Text('${b.pageCount} trang · ${_formatDate(b.updatedAt)}',
                                    style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                                ]),
                              ),
                            ),
                          );
                        },
                      );
                    }),
    );
  }

  String _formatDate(DateTime d) => '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
}
