import 'dart:async';
import 'dart:convert';
import 'dart:ui' as ui;
import 'dart:ui' show PointerDeviceKind;

import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';

import '../models/notebook.dart';
import '../models/laser_ink.dart';
import '../models/selection_clipboard.dart';
import '../models/page_structure_history.dart';
import '../services/export_service.dart';
import '../services/import_service.dart';
import '../services/notebook_repository.dart';
import '../widgets/page_painter.dart';
import '../widgets/pdf_range_dialog.dart';
import '../utils/lasso_geometry.dart';
import '../utils/ink_input_policy.dart';
import '../utils/stroke_eraser.dart';
import '../utils/shape_recognizer.dart';
import '../utils/spread_layout.dart';
import '../utils/touch_navigation.dart';

class EditorScreen extends StatefulWidget {
  final Notebook book;
  const EditorScreen({super.key, required this.book});

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen>
    with WidgetsBindingObserver {
  final _repo = NotebookRepository();
  final _transform = TransformationController();
  // Deep-copied page snapshots keep ink, text, images, backgrounds together.
  // Retain up to 40 snapshots on each page independently, even after switching.
  final _undoByPage = <String, List<NotePage>>{};
  final _redoByPage = <String, List<NotePage>>{};
  List<NotePage> get _undo => _undoByPage.putIfAbsent(_page.id, () => <NotePage>[]);
  List<NotePage> get _redo => _redoByPage.putIfAbsent(_page.id, () => <NotePage>[]);
  SelectionClipboard? _clipboard;
  final _pageHistory = PageStructureHistory();
  bool _stylusOnly = false;
  // Two-page mode shows a stable pair (1-2, 3-4, ...); either page is editable.
  bool _twoPageView = false;
  // Shape recognition is opt-in: handwriting is never silently reformatted.
  bool _autoRecognizeShapes = false;
  // Track touch contacts in VIEWPORT coordinates, not transformed paper coords.
  final Map<int, Offset> _touchContacts = {};
  bool _pinching = false;
  int? _handPointer;
  Offset? _handLastPosition;

  int get _spreadStart => SpreadLayout.startFor(_pageIndex);
  List<int> get _visibleIndices => SpreadLayout.visible(
      _pageIndex, _book.pages.length, twoPage: _twoPageView);
  double get _canvasWidth => _twoPageView ? 2 * paperWidth + 28 : paperWidth;

  final _colors = const [
    Color(0xff172b4d), Color(0xff111827), Color(0xff64748b),
    Color(0xff2563eb), Color(0xff0891b2), Color(0xff14b8a6),
    Color(0xff138a6b), Color(0xff84cc16), Color(0xffeab308),
    Color(0xfff97316), Color(0xffdf3e4d), Color(0xffec4899),
    Color(0xff7c3aed), Color(0xffa855f7), Color(0xff92400e),
    Color(0xffffffff),
  ];

  late Notebook _book;
  int _pageIndex = 0;
  DrawingTool _tool = DrawingTool.pen;
  Color _color = const Color(0xff172b4d);
  double _size = 3.0;
  StrokePattern _strokePattern = StrokePattern.solid;
  // Switching between pen/pencil/brush/geometry no longer loses the style
  // chosen for that particular tool. These are session presets, not yet
  // persisted as user preferences between app launches.
  final Map<DrawingTool, double> _widthsByTool = {
    DrawingTool.pen: 3, DrawingTool.pencil: 2,
    DrawingTool.brush: 6, DrawingTool.calligraphy: 5,
    DrawingTool.marker: 16,
  };
  final Map<DrawingTool, Color> _colorsByTool = {};
  final Map<DrawingTool, StrokePattern> _patternsByTool = {};

  void _switchTool(DrawingTool next) {
    // Finish any current gesture before changing tools.
    if (_active != null) {
      _page.strokes.add(_active!);
      _contentRevision++;
      _queueSave();
      _active = null;
    }
    if (_laser.hasActive) _laser.cancel();
    // A tool change midway through an eraser/selection gesture should still
    // save the edits already applied to the page.
    if (_erasedThisGesture || _selectionMoved) _queueSave();
    _erasedThisGesture = false;
    _lastEraserPosition = null;
    _eraserCursor = null;
    _activePointer = null;
    _widthsByTool[_tool] = _size;
    _colorsByTool[_tool] = _color;
    _patternsByTool[_tool] = _strokePattern;
    setState(() {
      _tool = next;
      _size = _widthsByTool[next] ?? 3.0;
      _color = _colorsByTool[next] ?? const Color(0xff172b4d);
      _strokePattern = _patternsByTool[next] ?? StrokePattern.solid;
      if (next != DrawingTool.select) _clearSelection();
    });
  }

  Future<void> _choosePenWidth() async {
    var candidate = _tool == DrawingTool.laser ? _laserWidth : _size;
    final result = await showDialog<double>(
      context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, refresh) => AlertDialog(
        title: const Text('Độ dày nét bút'),
        content: SizedBox(width: 320, child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('${candidate.toStringAsFixed(1)} px'),
            Slider(
              min: 0.5, max: 30, divisions: 59,
              value: candidate.clamp(0.5, 30.0).toDouble(),
              label: '${candidate.toStringAsFixed(1)} px',
              onChanged: (value) => refresh(() => candidate = value),
            ),
            const SizedBox(height: 10),
            SizedBox(height: 36, child: Center(child: Container(
              height: candidate.clamp(0.5, 30.0).toDouble(),
              decoration: BoxDecoration(
                color: _tool == DrawingTool.laser ? _laserColor : _color,
                borderRadius: BorderRadius.circular(99),
              ),
            ))),
            const Text('Có thể chọn từ 0,5 đến 30 px'),
          ],
        )),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(ctx, candidate),
            child: const Text('Áp dụng')),
        ],
      )),
    );
    if (result == null || !mounted) return;
    setState(() {
      if (_tool == DrawingTool.laser) {
        _laserWidth = result;
      } else {
        _size = result;
        _widthsByTool[_tool] = result;
      }
    });
  }
  InkStroke? _active;
  final LaserInkSession _laser = LaserInkSession();
  Timer? _laserTimer;
  DateTime _laserNow = DateTime.now();
  Duration _laserDuration = const Duration(seconds: 3);
  Color _laserColor = const Color(0xffff315a);
  double _laserWidth = 5;
  int? _activePointer;
  bool _erasedThisGesture = false;
  Offset? _lastEraserPosition;
  Offset? _eraserCursor;
  double _eraserRadius = 14;
  Timer? _saveTimer;
  bool _saving = false;
  Size? _viewportSize;
  Map<String, ui.Image> _pageBackgrounds = {};
  int _backgroundRequest = 0;
  final Set<int> _selectedStrokes = <int>{};
  final Set<int> _selectedElements = <int>{};
  int _contentRevision = 0;
  final List<Offset> _lassoPath = [];
  final Map<int, InkStroke> _originalSelectedStrokes = {};
  final Map<int, PageElement> _originalSelectedElements = {};
  Offset? _selectionStart;
  bool _selectionMoved = false;
  bool _resizeSelection = false;
  bool _importing = false;
  Map<String, Map<String, ui.Image>> _elementImagesByPage = {};
  int _idSequence = 0;

  String _nextId() => '${DateTime.now().microsecondsSinceEpoch}_${_idSequence++}';

  bool get _hasSelection => _selectedStrokes.isNotEmpty || _selectedElements.isNotEmpty;
  int? get _singleElementIndex => _selectedElements.length == 1
      ? _selectedElements.first : null;

  void _clearSelection() {
    _selectedStrokes.clear();
    _selectedElements.clear();
    _lassoPath.clear();
    _originalSelectedStrokes.clear();
    _originalSelectedElements.clear();
    _selectionStart = null;
    _selectionMoved = false;
    _resizeSelection = false;
  }

  void _selectAllOnPage() {
    setState(() {
      _clearSelection();
      _selectedStrokes.addAll(List<int>.generate(_page.strokes.length, (i) => i));
      _selectedElements.addAll(List<int>.generate(_page.elements.length, (i) => i));
      _tool = DrawingTool.select;
    });
  }

  NotePage get _page => _book.pages[_pageIndex];

  void _copySelection() {
    if (!_hasSelection) return;
    _clipboard = SelectionClipboard.capture(_page, _selectedStrokes, _selectedElements);
    _notify('Đã sao chép các đối tượng, có thể dán sang trang khác');
    setState(() {});
  }

  void _pasteSelection() {
    if (_clipboard == null || _clipboard!.isEmpty) return;
    _captureHistory();
    setState(() {
      _clearSelection();
      final result = _clipboard!.pasteInto(_page, _nextId);
      _selectedStrokes.addAll(result.strokes);
      _selectedElements.addAll(result.elements);
      _tool = DrawingTool.select;
      _contentRevision++;
    });
    _loadPageBackground();
    _queueSave();
  }

  @override
  void initState() {
    super.initState();
    _book = widget.book;
    WidgetsBinding.instance.addObserver(this);
    _loadPageBackground();
  }

  @override
  void dispose() {
    _saveTimer?.cancel();
    _laserTimer?.cancel();
    _laser.clear();
    // Luu tat ca thay doi chua ghi truoc khi dong trang.
    unawaited(_flushSave());
    WidgetsBinding.instance.removeObserver(this);
    _transform.dispose();
    for (final image in _pageBackgrounds.values) { image.dispose(); }
    for (final pageImages in _elementImagesByPage.values) {
      for (final image in pageImages.values) { image.dispose(); }
    }
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused || state == AppLifecycleState.inactive) {
      _laserTimer?.cancel();
      _laserTimer = null;
      _laser.clear();
      if (mounted) setState(() {});
      _flushSave();
    }
  }

  // Animate only while completed laser strokes are waiting to disappear.
  // This timer updates a screen overlay and NEVER queues a notebook save.
  void _startLaserFade() {
    if (_laserTimer != null) return;
    _laserTimer = Timer.periodic(const Duration(milliseconds: 33), (_) {
      if (!mounted) {
        _laserTimer?.cancel();
        _laserTimer = null;
        return;
      }
      setState(() {
        _laserNow = DateTime.now();
        _laser.removeExpired(_laserNow);
      });
      if (_laser.isEmpty) {
        _laserTimer?.cancel();
        _laserTimer = null;
      }
    });
  }

  void _clearLaser() {
    _laserTimer?.cancel();
    _laserTimer = null;
    _laser.clear();
  }

  Future<ui.Image> _decodeImage(String? encoded, String? assetId,
      {int? targetWidth}) async {
    if (encoded == null && assetId == null) {
      throw const FormatException('Thiếu dữ liệu ảnh');
    }
    final bytes = encoded != null
        ? base64Decode(encoded)
        : await _repo.readMedia(_book.id, assetId!);
    final codec = await ui.instantiateImageCodec(bytes,
      targetWidth: targetWidth);
    try {
      final frame = await codec.getNextFrame();
      return frame.image;
    } finally {
      codec.dispose();
    }
  }

  Future<void> _loadPageBackground() async {
    final request = ++_backgroundRequest;
    final indices = _visibleIndices;
    final backgrounds = <String, ui.Image>{};
    final elementImages = <String, Map<String, ui.Image>>{};
    try {
      for (final index in indices) {
        final page = _book.pages[index];
        if (page.backgroundImageBase64 != null || page.backgroundAssetId != null) {
          backgrounds[page.id] = await _decodeImage(page.backgroundImageBase64,
              page.backgroundAssetId, targetWidth: 900);
        }
        final images = <String, ui.Image>{};
        elementImages[page.id] = images;
        for (final element in page.elements) {
          if (element.type == 'image' &&
              (element.imageBase64 != null || element.imageAssetId != null)) {
            images[element.id] = await _decodeImage(element.imageBase64,
                element.imageAssetId, targetWidth: 800);
          }
        }
      }
      if (!mounted || request != _backgroundRequest) return;
      final oldBackgrounds = _pageBackgrounds;
      final oldImages = _elementImagesByPage;
      setState(() {
        _pageBackgrounds = Map<String, ui.Image>.of(backgrounds);
        _elementImagesByPage = {
          for (final entry in elementImages.entries)
            entry.key: Map<String, ui.Image>.of(entry.value),
        };
      });
      for (final image in oldBackgrounds.values) { image.dispose(); }
      for (final pageImages in oldImages.values) {
        for (final image in pageImages.values) { image.dispose(); }
      }
      backgrounds.clear();
      elementImages.clear();
    } catch (error) {
      if (mounted && request == _backgroundRequest) _notifyError(error);
    } finally {
      for (final image in backgrounds.values) { image.dispose(); }
      for (final pageImages in elementImages.values) {
        for (final image in pageImages.values) { image.dispose(); }
      }
    }
  }

  Future<void> _importPdfPages() async {
    if (_importing) return;
    final range = await choosePdfRange(context);
    if (range == null || !mounted) return;
    setState(() => _importing = true);
    try {
      final pages = await ImportService.pickPdfPagesToAssets(
        bookId: _book.id, assetStore: _repo.assets,
        startPage: range.start, pageCount: range.count);
      if (pages == null || pages.isEmpty || !mounted) return;
      setState(() {
        for (final page in pages) {
          _pageHistory.recordInsert(page, _book.pages.length);
          _book.pages.add(page);
        }
        _contentRevision++;
        _pageIndex = _book.pages.length - pages.length;
        _undo.clear();
        _redo.clear();
        _clearSelection();
      });
      await _loadPageBackground();
      _queueSave();
      _notify('Đã thêm ${pages.length} trang PDF để ghi chú');
    } catch (error) {
      _notifyError(error);
    } finally {
      if (mounted) setState(() => _importing = false);
    }
  }

  Future<void> _importImageBackground() async {
    try {
      final image = await ImportService.pickImageBackground();
      if (image == null || !mounted) return;
      if (_page.backgroundImageBase64 != null) {
        final confirm = await showDialog<bool>(context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Thay ảnh nền?'),
            content: const Text('Ảnh nền hiện tại sẽ được thay, các nét vẽ vẫn giữ nguyên.'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Hủy')),
              FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Thay ảnh')),
            ],
          ),
        );
        if (confirm != true || !mounted) return;
      }
      final assetBook = Notebook(id: _book.id, title: _book.title,
          updatedAt: _book.updatedAt, pages: [NotePage(id: _page.id,
            backgroundImageBase64: image)]);
      await _repo.externalizeMedia(assetBook);
      if (!mounted) return;
      _captureHistory();
      setState(() {
        _page.backgroundImageBase64 = null;
        _page.backgroundAssetId = assetBook.pages.first.backgroundAssetId;
        _page.pattern = PaperPattern.blank;
        _contentRevision++;
      });
      await _loadPageBackground();
      _queueSave();
      _notify('Đã chèn ảnh làm nền trang');
    } catch (error) {
      _notifyError(error);
    }
  }

  void _notify(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  void _duplicatePage() {
    final copy = _page.duplicate(
      '${DateTime.now().microsecondsSinceEpoch}_copy',
    );
    setState(() {
      _pageHistory.recordInsert(copy, _pageIndex + 1);
      _book.pages.insert(_pageIndex + 1, copy);
      _pageIndex++;
      _undo.clear();
      _redo.clear();
      _clearSelection();
    });
    _loadPageBackground();
    _queueSave();
  }

  void _deleteSelection() {
    if (!_hasSelection) return;
    _captureHistory();
    setState(() {
      final indices = _selectedStrokes.toList()..sort((a, b) => b.compareTo(a));
      for (final index in indices) {
        if (index >= 0 && index < _page.strokes.length) _page.strokes.removeAt(index);
      }
      final elements = _selectedElements.toList()..sort((a, b) => b.compareTo(a));
      for (final element in elements) {
        if (element >= 0 && element < _page.elements.length) {
          _page.elements.removeAt(element);
        }
      }
      _clearSelection();
      _contentRevision++;
    });
    _loadPageBackground();
    _queueSave();
  }

  void _duplicateSelection() {
    if (!_hasSelection) return;
    _captureHistory();
    setState(() {
      final previousStrokes = _selectedStrokes.toList()..sort();
      final previousElements = _selectedElements.toList()..sort();
      _clearSelection();
      for (final index in previousStrokes) {
        if (index < 0 || index >= _page.strokes.length) continue;
        _page.strokes.add(_page.strokes[index].translated(24, 24));
        _selectedStrokes.add(_page.strokes.length - 1);
      }
      for (final index in previousElements) {
        if (index < 0 || index >= _page.elements.length) continue;
        _page.elements.add(_page.elements[index]
            .translated(24, 24).copyWith(id: _nextId()));
        _selectedElements.add(_page.elements.length - 1);
      }
      _contentRevision++;
    });
    _loadPageBackground();
    _queueSave();
  }

  Future<void> _insertOverlayImage() async {
    try {
      final base64Image = await ImportService.pickImageBackground();
      if (base64Image == null || !mounted) return;
      final decoded = await _decodeImage(base64Image, null, targetWidth: 800);
      final ratio = decoded.width / decoded.height;
      decoded.dispose();
      const width = 430.0;
      final height = (width / ratio).clamp(80.0, 650.0).toDouble();
      final imageBook = Notebook(id: _book.id, title: _book.title,
        updatedAt: _book.updatedAt, pages: [NotePage(id: _page.id, elements: [
          PageElement(id: _nextId(), type: 'image', x: 150, y: 150,
            width: width, height: height, imageBase64: base64Image),
        ])]);
      await _repo.externalizeMedia(imageBook);
      if (!mounted) return;
      _captureHistory();
      setState(() {
        _page.elements.add(imageBook.pages.first.elements.first);
        _clearSelection();
        _selectedElements.add(_page.elements.length - 1);
        _tool = DrawingTool.select;
        _contentRevision++;
      });
      await _loadPageBackground();
      _queueSave();
      _notify('Đã chèn ảnh: dùng công cụ Chọn để kéo hoặc thay đổi kích thước');
    } catch (error) { _notifyError(error); }
  }

  Future<void> _textDialog({Offset? at, int? editIndex}) async {
    final pageWhenOpened = _page;
    final current = editIndex == null ? null : _page.elements[editIndex];
    final controller = TextEditingController(text: current?.text ?? '');
    double fontSize = current?.fontSize ?? 30;
    if (![18.0, 24.0, 30.0, 36.0, 48.0, 60.0].contains(fontSize)) {
      fontSize = 30;
    }
    final value = await showDialog<(String, double)>(
      context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, update) => AlertDialog(
        title: Text(current == null ? 'Chèn văn bản' : 'Sửa văn bản'),
        content: SizedBox(width: 390, child: Column(
          mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(controller: controller, autofocus: true, maxLines: 4,
              maxLength: 2000,
              decoration: const InputDecoration(labelText: 'Nội dung',
                border: OutlineInputBorder())),
            const SizedBox(height: 10),
            Row(children: [
              const Text('Cỡ chữ: '),
              DropdownButton<double>(value: fontSize,
                items: [18.0, 24.0, 30.0, 36.0, 48.0, 60.0].map((n) =>
                  DropdownMenuItem(value: n, child: Text('${n.toInt()} px'))).toList(),
                onChanged: (size) { if (size != null) update(() => fontSize = size); }),
            ]),
          ],
        )),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(ctx,
            (controller.text.trim(), fontSize)), child: const Text('Lưu')),
        ],
      )),
    );
    Future<void>.delayed(const Duration(milliseconds: 350), controller.dispose);
    if (!mounted || value == null || value.$1.isEmpty ||
        !identical(pageWhenOpened, _page)) return;
    _captureHistory();
    setState(() {
      if (editIndex != null && editIndex < _page.elements.length) {
        _page.elements[editIndex]
          ..text = value.$1
          ..fontSize = value.$2;
        _clearSelection();
        _selectedElements.add(editIndex);
      } else {
        _page.elements.add(PageElement(
          id: _nextId(), type: 'text',
          x: (at?.dx ?? 160).clamp(0, paperWidth - 400).toDouble(),
          y: (at?.dy ?? 200).clamp(0, paperHeight - 140).toDouble(),
          width: 400, height: 140, text: value.$1,
          fontSize: value.$2, color: _color.toARGB32(),
        ));
        _clearSelection();
        _selectedElements.add(_page.elements.length - 1);
      }
      _tool = DrawingTool.select;
      _contentRevision++;
    });
    _queueSave();
  }

  void _editSelectedText() {
    final index = _singleElementIndex;
    if (index != null && index < _page.elements.length &&
        _page.elements[index].type == 'text') {
      _textDialog(editIndex: index);
    }
  }

  Future<void> _flushSave() async {
    _saveTimer?.cancel();
    _book.updatedAt = DateTime.now();
    try {
      await _repo.save(_book);
    } catch (error) {
      _notifyError(error);
    }
  }

  void _queueSave() {
    _saveTimer?.cancel();
    _book.updatedAt = DateTime.now();
    _saveTimer = Timer(const Duration(milliseconds: 550), () async {
      if (mounted) setState(() => _saving = true);
      try {
        await _repo.save(_book);
      } catch (error) {
        _notifyError(error);
      } finally {
        if (mounted) setState(() => _saving = false);
      }
    });
  }

  void _notifyError(Object error) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Không thể thực hiện: $error')),
    );
  }

  void _captureHistory() {
    _undo.add(_page.duplicate(_page.id));
    if (_undo.length > 40) _undo.removeAt(0);
    _redo.clear();
  }

  void _restoreSnapshot(NotePage snapshot) {
    _page.strokes = [for (final s in snapshot.strokes) s.clone()];
    _page.elements = [for (final e in snapshot.elements) e.clone()];
    _page.pattern = snapshot.pattern;
    _page.backgroundImageBase64 = snapshot.backgroundImageBase64;
    _page.backgroundAssetId = snapshot.backgroundAssetId;
    _contentRevision++;
    _clearSelection();
  }

  void _undoAction() {
    if (_undo.isEmpty) return;
    setState(() {
      _redo.add(_page.duplicate(_page.id));
      _restoreSnapshot(_undo.removeLast());
    });
    _loadPageBackground();
    _queueSave();
  }

  void _redoAction() {
    if (_redo.isEmpty) return;
    setState(() {
      _undo.add(_page.duplicate(_page.id));
      _restoreSnapshot(_redo.removeLast());
    });
    _loadPageBackground();
    _queueSave();
  }

  InkPoint _fromEvent(PointerEvent e) {
    var pressure = 1.0;
    if (e.kind == PointerDeviceKind.stylus && e.pressureMax > e.pressureMin) {
      pressure = 0.5 + 0.8 *
          ((e.pressure - e.pressureMin) / (e.pressureMax - e.pressureMin));
    }
    return InkPoint(e.localPosition.dx.clamp(0.0, paperWidth).toDouble(),
        e.localPosition.dy.clamp(0.0, paperHeight).toDouble(), pressure);
  }

  void _down(PointerDownEvent e) {
    if (_pinching || _tool == DrawingTool.hand || _activePointer != null) return;
    if (!InkInputPolicy(stylusOnly: _stylusOnly).accepts(e.kind)) return;
    if (e.kind == PointerDeviceKind.mouse && e.buttons != kPrimaryButton) return;
    if (_tool == DrawingTool.text) {
      _textDialog(at: e.localPosition);
      return;
    }
    _activePointer = e.pointer;
    _erasedThisGesture = false;
    _lastEraserPosition = null;
    if (_tool == DrawingTool.eraser) {
      setState(_clearSelection);
      _eraseAt(e.localPosition);
      return;
    }
    if (_tool == DrawingTool.lasso) {
      setState(() {
        _clearSelection();
        _lassoPath.add(e.localPosition);
      });
      return;
    }
    if (_tool == DrawingTool.select) {
      _selectionStart = e.localPosition;
      _selectionMoved = false;
      _resizeSelection = false;
      final single = _singleElementIndex;
      if (single != null && _selectedStrokes.isEmpty &&
          single < _page.elements.length) {
        final handle = PagePainter.elementBounds(
          _page.elements[single]).inflate(6).bottomRight;
        if ((e.localPosition - handle).distance <= 25) {
          _resizeSelection = true;
        }
      }
      if (!_resizeSelection) {
        final onSelectedElement = _selectedElements.any((i) =>
          i >= 0 && i < _page.elements.length &&
          PagePainter.elementBounds(_page.elements[i])
              .inflate(8).contains(e.localPosition));
        final onSelectedStroke = _selectedStrokes.any((i) =>
          i >= 0 && i < _page.strokes.length && PagePainter.touchesStroke(
            _page.strokes[i], e.localPosition, radius: 20));
        if (!onSelectedElement && !onSelectedStroke) {
          final element = _page.elements.lastIndexWhere((item) =>
            PagePainter.elementBounds(item).contains(e.localPosition));
          final stroke = element < 0 ? _page.strokes.lastIndexWhere((item) =>
            PagePainter.touchesStroke(item, e.localPosition, radius: 15)) : -1;
          setState(() {
            _clearSelection();
            if (element >= 0) _selectedElements.add(element);
            if (stroke >= 0) _selectedStrokes.add(stroke);
          });
          _selectionStart = e.localPosition;
        }
      }
      _originalSelectedStrokes.clear();
      for (final index in _selectedStrokes) {
        _originalSelectedStrokes[index] = _page.strokes[index].clone();
      }
      _originalSelectedElements.clear();
      for (final index in _selectedElements) {
        _originalSelectedElements[index] = _page.elements[index].clone();
      }
      return;
    }
    if (_tool == DrawingTool.laser) {
      _laserNow = DateTime.now();
      setState(() => _laser.start(_fromEvent(e),
        color: _laserColor.toARGB32(), width: _laserWidth,
        duration: _laserDuration));
      return;
    }
    _captureHistory();
    final point = _fromEvent(e);
    _active = InkStroke(kind: _tool.name,
      color: _color.toARGB32(),
      width: _size,
      pattern: _strokePattern,
      points: [point]);
    setState(() {});
  }

  void _move(PointerMoveEvent e) {
    if (_pinching || _activePointer != e.pointer) return;
    if (_tool == DrawingTool.eraser) {
      _eraseAt(e.localPosition);
      return;
    }
    if (_tool == DrawingTool.lasso) {
      if (_lassoPath.isEmpty ||
          (e.localPosition - _lassoPath.last).distance > 3) {
        setState(() => _lassoPath.add(e.localPosition));
      }
      return;
    }
    if (_tool == DrawingTool.select) {
      final start = _selectionStart;
      if (start == null || !_hasSelection) return;
      final delta = e.localPosition - start;
      if (!_selectionMoved && delta.distance > 2) {
        _captureHistory();
        _selectionMoved = true;
      }
      if (!_selectionMoved) return;
      setState(() {
        for (final entry in _originalSelectedStrokes.entries) {
          _page.strokes[entry.key] = entry.value.translated(delta.dx, delta.dy);
        }
        for (final entry in _originalSelectedElements.entries) {
          final index = entry.key;
          final base = entry.value;
          if (_resizeSelection && _singleElementIndex == index) {
            _page.elements[index] = base.copyWith(
              width: (base.width + delta.dx).clamp(
                60.0, (paperWidth - base.x).clamp(60.0, paperWidth)).toDouble(),
              height: (base.height + delta.dy).clamp(
                40.0, (paperHeight - base.y).clamp(40.0, paperHeight)).toDouble(),
            );
          } else {
            _page.elements[index] = base.translated(delta.dx, delta.dy);
          }
        }
        _contentRevision++;
      });
      return;
    }
    if (_tool == DrawingTool.laser && _laser.hasActive) {
      setState(() => _laser.append(_fromEvent(e)));
      return;
    }
    if (_active == null) return;
    final point = _fromEvent(e);
    if ({DrawingTool.pen, DrawingTool.pencil, DrawingTool.brush,
         DrawingTool.calligraphy, DrawingTool.marker}.contains(_tool)) {
      final previous = _active!.points.last;
      final distance = (Offset(point.x, point.y) - Offset(previous.x, previous.y)).distance;
      if (distance < 0.6) return;
      _active!.points.add(point);
    } else {
      if (_active!.points.length == 1) {
        _active!.points.add(point);
      } else {
        _active!.points[1] = point;
      }
    }
    setState(() {});
  }

  void _up(PointerEvent e) {
    if (_pinching || _activePointer != e.pointer) return;
    _activePointer = null;
    if (_tool == DrawingTool.lasso) {
      final polygon = List<Offset>.of(_lassoPath)..add(e.localPosition);
      setState(() {
        _lassoPath.clear();
        _selectedStrokes.clear();
        _selectedElements.clear();
        for (var i = 0; i < _page.strokes.length; i++) {
          if (LassoGeometry.selectsStroke(_page.strokes[i], polygon)) {
            _selectedStrokes.add(i);
          }
        }
        for (var i = 0; i < _page.elements.length; i++) {
          if (LassoGeometry.intersectsRect(
              PagePainter.elementBounds(_page.elements[i]), polygon)) {
            _selectedElements.add(i);
          }
        }
        _tool = DrawingTool.select;
      });
      if (_hasSelection) _notify('Đã khoanh chọn: kéo đối tượng hoặc chọn Sao chép / Xóa');
      return;
    }
    if (_tool == DrawingTool.select) {
      if (_selectionMoved) _queueSave();
      _originalSelectedStrokes.clear();
      _originalSelectedElements.clear();
      _selectionStart = null;
      _selectionMoved = false;
      _resizeSelection = false;
      return;
    }
    if (_laser.hasActive) {
      setState(() {
        _laserNow = DateTime.now();
        _laser.finish(_laserNow);
      });
      _startLaserFade();
      return;
    }
    if (_active != null) {
      final finished = _active!;
      final recognized = _autoRecognizeShapes
          ? ShapeRecognizer.recognize(finished) : null;
      setState(() {
        _page.strokes.add(recognized ?? finished);
        _active = null;
        _contentRevision++;
      });
      if (recognized != null) _notify('Đã nhận dạng: ${recognized.kind} (Undo để hoàn tác)');
      _queueSave();
    } else if (_erasedThisGesture) {
      _queueSave();
    }
    _lastEraserPosition = null;
    if (_tool == DrawingTool.eraser) setState(() => _eraserCursor = null);
  }

  void _cancel(PointerCancelEvent e) {
    if (_pinching || _activePointer != e.pointer) return;
    _activePointer = null;
    if (_tool == DrawingTool.lasso) {
      setState(() => _lassoPath.clear());
      return;
    }
    if (_tool == DrawingTool.select) {
      if (_selectionMoved && _undo.isNotEmpty) {
        setState(() => _restoreSnapshot(_undo.removeLast()));
        _loadPageBackground();
      }
      _originalSelectedStrokes.clear();
      _originalSelectedElements.clear();
      _selectionStart = null;
      _selectionMoved = false;
      _resizeSelection = false;
      return;
    }
    if (_laser.hasActive) {
      setState(_laser.cancel);
      return;
    }
    if (_active != null && _undo.isNotEmpty) _undo.removeLast();
    setState(() {
      _active = null;
      _eraserCursor = null;
    });
    _lastEraserPosition = null;
    if (_erasedThisGesture && _undo.isNotEmpty) {
      // A cancelled erase gesture must not leave a partly erased page behind.
      setState(() => _restoreSnapshot(_undo.removeLast()));
      _queueSave();
    }
  }

  void _eraseAt(Offset position) {
    final from = _lastEraserPosition ?? position;
    _lastEraserPosition = position;
    final updated = <InkStroke>[];
    var changed = false;
    for (final stroke in _page.strokes) {
      final result = StrokeEraser.eraseSweep(
        stroke, from, position, radius: _eraserRadius);
      changed = changed || result.changed;
      updated.addAll(result.strokes);
    }
    if (changed && !_erasedThisGesture) {
      _captureHistory(); // Only one undo checkpoint for the whole drag.
      _erasedThisGesture = true;
    }
    if (changed) {
      setState(() {
        _page.strokes = updated;
        _contentRevision++;
        _eraserCursor = position;
      });
    } else if (_eraserCursor != position) {
      setState(() => _eraserCursor = position);
    }
  }

  void _selectPage(int index) {
    if (index == _pageIndex || index < 0 || index >= _book.pages.length) return;
    final previousStart = _spreadStart;
    setState(() {
      _pageIndex = index;
      _clearLaser();
      _active = null;
      _activePointer = null;
      _clearSelection();
    });
    // Reuse both decoded pages when moving within the same spread.
    if (!_twoPageView || _spreadStart != previousStart) _loadPageBackground();
  }

  void _toggleTwoPageView() {
    setState(() {
      _twoPageView = !_twoPageView;
      _touchContacts.clear();
      _pinching = false;
      _clearLaser();
      _clearSelection();
    });
    _loadPageBackground();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && _viewportSize != null) {
        _fit(_viewportSize!.width, _viewportSize!.height);
      }
    });
  }

  // Touch handling is independent from the selected writing tool.
  // One finger can draw ink, two fingers move and zoom the page.
  void _interruptInkForPinch() {
    var restore = false;
    if (_active != null) {
      _active = null;
      if (_undo.isNotEmpty) _undo.removeLast();
    }
    if (_erasedThisGesture || _selectionMoved) {
      if (_undo.isNotEmpty) {
        _restoreSnapshot(_undo.removeLast());
        restore = true;
      }
    }
    if (_laser.hasActive) _laser.cancel();
    _activePointer = null;
    _lastEraserPosition = null;
    _eraserCursor = null;
    _lassoPath.clear();
    _originalSelectedStrokes.clear();
    _originalSelectedElements.clear();
    _selectionStart = null;
    _selectionMoved = false;
    _erasedThisGesture = false;
    _resizeSelection = false;
    if (restore) _queueSave();
    setState(() {});
  }

  void _onViewportDown(PointerDownEvent event) {
    if (_tool == DrawingTool.hand && _handPointer == null) {
      _handPointer = event.pointer;
      _handLastPosition = event.localPosition;
    }
    if (event.kind != PointerDeviceKind.touch) return;
    _touchContacts[event.pointer] = event.localPosition;
    if (_touchContacts.length >= 2 && !_pinching) {
      _pinching = true;
      _interruptInkForPinch();
    }
  }

  void _onViewportMove(PointerMoveEvent event) {
    if (_tool == DrawingTool.hand && _handPointer == event.pointer &&
        !_pinching && _handLastPosition != null) {
      final delta = event.localPosition - _handLastPosition!;
      _handLastPosition = event.localPosition;
      final matrix = _transform.value.clone();
      matrix.setEntry(0, 3, matrix.entry(0, 3) + delta.dx);
      matrix.setEntry(1, 3, matrix.entry(1, 3) + delta.dy);
      _transform.value = matrix;
    }
    if (event.kind != PointerDeviceKind.touch) return;
    final before = _touchContacts[event.pointer];
    if (before == null) return;
    if (_pinching && _touchContacts.length == 2) {
      final other = _touchContacts.entries
          .firstWhere((entry) => entry.key != event.pointer).value;
      final oldCenter = (before + other) / 2;
      final newCenter = (event.localPosition + other) / 2;
      final oldDistance = (before - other).distance;
      final newDistance = (event.localPosition - other).distance;
      _zoomAround(oldCenter, newCenter,
          oldDistance > 1 ? newDistance / oldDistance : 1.0);
    }
    _touchContacts[event.pointer] = event.localPosition;
  }

  void _onViewportEnd(PointerEvent event) {
    _touchContacts.remove(event.pointer);
    if (_handPointer == event.pointer) {
      _handPointer = null;
      _handLastPosition = null;
    }
    // Do not create a new stroke from the remaining finger after pinching.
    if (_touchContacts.isEmpty) _pinching = false;
  }

  void _zoomAround(Offset before, Offset after, double factor) {
    _transform.value = TouchNavigation.transform(
        _transform.value, before, after, factor);
  }

  void _newPage() {
    setState(() {
      final newPage = NotePage(
        id: _nextId(),
        pattern: _page.pattern,
      );
      _pageHistory.recordInsert(newPage, _book.pages.length);
      _book.pages.add(newPage);
      _pageIndex = _book.pages.length - 1;
      _clearLaser();
      _undo.clear();
      _redo.clear();
      _clearSelection();
    });
    _loadPageBackground();
    _queueSave();
  }

  Future<void> _deletePage() async {
    if (_book.pages.length <= 1) return;
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Xóa trang?'),
      content: const Text('Nội dung trang sẽ bị xóa khỏi sổ tay.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Hủy')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Xóa')),
      ],
    ));
    if (ok != true || !mounted) return;
    setState(() {
      _pageHistory.recordDelete(_page, _pageIndex);
      _book.pages.removeAt(_pageIndex);
      _clearLaser();
      _pageIndex = _pageIndex.clamp(0, _book.pages.length - 1).toInt();
      _clearSelection();
    });
    _loadPageBackground();
    _queueSave();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Text('Đã xóa trang'),
      action: SnackBarAction(label: 'Hoàn tác', onPressed: _undoPageStructure),
    ));
  }

  void _undoPageStructure() {
    if (!_pageHistory.canUndo) return;
    setState(() {
      final destination = _pageHistory.undo(_book.pages);
      if (destination == null) return;
      _pageIndex = destination;
      _clearLaser();
      _activePointer = null;
      _active = null;
      _contentRevision++;
      _clearSelection();
    });
    _loadPageBackground();
    _queueSave();
  }

  void _redoPageStructure() {
    if (!_pageHistory.canRedo) return;
    setState(() {
      final destination = _pageHistory.redo(_book.pages);
      if (destination == null) return;
      _pageIndex = destination;
      _clearLaser();
      _activePointer = null;
      _active = null;
      _contentRevision++;
      _clearSelection();
    });
    _loadPageBackground();
    _queueSave();
  }

  Future<void> _rename() async {
    final controller = TextEditingController(text: _book.title);
    final value = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Đổi tên sổ tay'),
        content: TextField(controller: controller, autofocus: true,
          maxLength: 80, decoration: const InputDecoration(labelText: 'Tên sổ tay')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('Lưu')),
        ],
      ),
    );
    // Doi dialog hoan tat animation truoc khi dispose controller.
    Future<void>.delayed(const Duration(milliseconds: 350), controller.dispose);
    if (value == null || value.isEmpty) return;
    setState(() => _book.title = value);
    _queueSave();
  }

  Future<void> _export(String what) async {
    try {
      await _flushSave();
      final success = what == 'pdf'
          ? await ExportService.exportPdf(_book)
          : what == 'legacyBackup'
              ? await ExportService.exportLegacyBackup(_book)
              : await ExportService.exportBackup(_book);
      if (!mounted || !success) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã xuất tệp thành công')));
    } catch (error) {
      _notifyError(error);
    }
  }

  void _fit(double viewportW, double viewportH) {
    final scale = (viewportW / (_canvasWidth + 64))
        .clamp(0.25, 1.0).toDouble();
    final yFit = (viewportH / (paperHeight + 50)).clamp(0.25, 1.0).toDouble();
    final s = scale < yFit ? scale : yFit;
    final x = (viewportW - _canvasWidth * s) / 2;
    final y = (viewportH - paperHeight * s) / 2;
    final transform = Matrix4.identity();
    transform.setEntry(0, 0, s);
    transform.setEntry(1, 1, s);
    transform.setEntry(0, 3, x);
    transform.setEntry(1, 3, y);
    _transform.value = transform;
  }

  void _zoom(double factor) {
    final view = _viewportSize;
    if (view == null) return;
    final center = Offset(view.width / 2, view.height / 2);
    _zoomAround(center, center, factor);
  }

  Widget _paperSurface(int index) {
    final page = _book.pages[index];
    final active = index == _pageIndex;
    return DecoratedBox(
      decoration: BoxDecoration(
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.12),
          blurRadius: 12, offset: const Offset(0, 4))],
        border: Border.all(color: active ? const Color(0xff4b67cf) :
            const Color(0xffbec7dc), width: active ? 2 : 1),
      ),
      child: SizedBox(width: paperWidth, height: paperHeight,
        child: Listener(
          behavior: HitTestBehavior.opaque,
          onPointerDown: (event) {
            // A second finger touching the other page must not switch the
            // active page while a stroke/erase gesture is still running.
            if (!active && _activePointer == null && !_pinching) {
              _selectPage(index);
            }
            _down(event);
          },
          onPointerMove: _move,
          onPointerUp: _up,
          onPointerCancel: _cancel,
          child: Stack(children: [
            Positioned.fill(child: RepaintBoundary(child: CustomPaint(
              painter: PagePainter(
                pattern: page.pattern,
                strokes: page.strokes,
                elements: page.elements,
                background: _pageBackgrounds[page.id],
                elementImages: _elementImagesByPage[page.id] ?? const {},
                revision: _contentRevision,
                pageId: page.id,
              ),
            ))),
            if (active) Positioned.fill(child: IgnorePointer(child: CustomPaint(
              painter: InkInteractionPainter(
                preview: _active,
                laserTraces: _laser.traces,
                laserNow: _laserNow,
                eraserPosition: _tool == DrawingTool.eraser ? _eraserCursor : null,
                eraserRadius: _eraserRadius,
                strokes: page.strokes,
                elements: page.elements,
                selectedStrokeIndices: _selectedStrokes,
                selectedElementIndices: _selectedElements,
                lassoPath: _lassoPath,
              ),
            ))),
          ]),
        ),
      ),
    );
  }

  Widget _paperSpread() {
    if (!_twoPageView) return _paperSurface(_pageIndex);
    final indices = _visibleIndices;
    return Row(mainAxisSize: MainAxisSize.min, children: [
      _paperSurface(indices.first),
      const SizedBox(width: 28),
      if (indices.length > 1) _paperSurface(indices.last)
      else SizedBox(width: paperWidth, height: paperHeight,
        child: Center(child: FilledButton.icon(
          onPressed: _newPage,
          icon: const Icon(Icons.add), label: const Text('Thêm trang đối diện'),
        )),
      ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.sizeOf(context).width > 700;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: InkWell(
          onTap: _rename,
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Flexible(child: Text(_book.title, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 17))),
            const SizedBox(width: 5), const Icon(Icons.edit_outlined, size: 16),
          ]),
        ),
        actions: [
          if (_importing) const Padding(
            padding: EdgeInsets.symmetric(horizontal: 8),
            child: Center(child: SizedBox(width: 16, height: 16,
              child: CircularProgressIndicator(strokeWidth: 2))),
          ),
          if (_saving) const Padding(
            padding: EdgeInsets.symmetric(horizontal: 8),
            child: Center(child: SizedBox(width: 16, height: 16,
              child: CircularProgressIndicator(strokeWidth: 2))),
          ),
          if (_hasSelection) IconButton(tooltip: 'Sao chép',
            onPressed: _copySelection, icon: const Icon(Icons.content_copy_outlined)),
          if (_clipboard != null && !_clipboard!.isEmpty)
            IconButton(tooltip: 'Dán', onPressed: _pasteSelection,
              icon: const Icon(Icons.content_paste_outlined)),
          IconButton(tooltip: 'Hoàn tác', onPressed: _undo.isEmpty ? null : _undoAction,
            icon: const Icon(Icons.undo)),
          IconButton(tooltip: 'Làm lại', onPressed: _redo.isEmpty ? null : _redoAction,
            icon: const Icon(Icons.redo)),
          IconButton(
            tooltip: _twoPageView ? 'Trở về một trang' : 'Xem hai trang cạnh nhau',
            onPressed: _toggleTwoPageView,
            icon: Icon(_twoPageView ? Icons.chrome_reader_mode : Icons.menu_book_outlined),
          ),
          PopupMenuButton<String>(
            tooltip: 'Tệp và xuất',
            onSelected: (v) {
              if (v == 'pdf' || v == 'backup' || v == 'legacyBackup') _export(v);
              if (v == 'undoPage') _undoPageStructure();
              if (v == 'redoPage') _redoPageStructure();
              if (v == 'stylusOnly') setState(() => _stylusOnly = !_stylusOnly);
              if (v == 'autoShapes') setState(() => _autoRecognizeShapes = !_autoRecognizeShapes);
              if (v == 'deletePage') _deletePage();
              if (v == 'duplicatePage') _duplicatePage();
              if (v == 'importPdf') _importPdfPages();
              if (v == 'imageBackground') _importImageBackground();
              if (v == 'imageOverlay') _insertOverlayImage();
              if (v == 'editText') _editSelectedText();
              if (v == 'removeBackground') {
                _captureHistory();
                setState(() { _page.backgroundImageBase64 = null; _page.backgroundAssetId = null; _contentRevision++; });
                _loadPageBackground();
                _queueSave();
              }
              if (v == 'deleteSelected') _deleteSelection();
              if (v == 'selectAll') _selectAllOnPage();
              if (v == 'duplicateSelected') _duplicateSelection();
              if (v == 'copySelected') _copySelection();
              if (v == 'pasteSelected') _pasteSelection();
            },
            itemBuilder: (ctx) => [
              const PopupMenuItem(value: 'pdf', child: Text('Xuất PDF')),
              const PopupMenuItem(value: 'backup', child: Text('Sao lưu ZIP (đề xuất)')),
              const PopupMenuItem(value: 'legacyBackup', child: Text('Sao lưu JSON cho bản cũ')),
              CheckedPopupMenuItem(value: 'autoShapes', checked: _autoRecognizeShapes,
                child: const Text('Tự nắn hình vẽ tay (đường, tròn, chữ nhật, tam giác)')),
              CheckedPopupMenuItem(value: 'stylusOnly', checked: _stylusOnly,
                child: const Text('Chỉ nhận bút khi viết')),
              if (_pageHistory.canUndo)
                const PopupMenuItem(value: 'undoPage', child: Text('Hoàn tác thêm/xóa trang')),
              if (_pageHistory.canRedo)
                const PopupMenuItem(value: 'redoPage', child: Text('Làm lại thêm/xóa trang')),
              const PopupMenuItem(value: 'importPdf', child: Text('Thêm các trang từ PDF')),
              const PopupMenuItem(value: 'imageBackground', child: Text('Chèn ảnh làm nền trang')),
              const PopupMenuItem(value: 'imageOverlay', child: Text('Chèn ảnh có thể di chuyển / đổi cỡ')),
              if (_page.backgroundImageBase64 != null || _page.backgroundAssetId != null)
                const PopupMenuItem(value: 'removeBackground', child: Text('Bỏ ảnh nền')),
              const PopupMenuItem(value: 'duplicatePage', child: Text('Nhân bản trang hiện tại')),
              const PopupMenuItem(value: 'selectAll', child: Text('Chọn tất cả đối tượng trong trang')),
              if (_clipboard != null && !_clipboard!.isEmpty)
                const PopupMenuItem(value: 'pasteSelected', child: Text('Dán đối tượng đã sao chép')), 
              if (_singleElementIndex != null &&
                  _page.elements[_singleElementIndex!].type == 'text')
                const PopupMenuItem(value: 'editText', child: Text('Sửa văn bản đã chọn')),
              if (_hasSelection) ...[
                const PopupMenuItem(value: 'copySelected', child: Text('Sao chép đối tượng đã chọn')),
                const PopupMenuItem(value: 'duplicateSelected', child: Text('Nhân bản đối tượng đã chọn')),
                const PopupMenuItem(value: 'deleteSelected', child: Text('Xóa đối tượng đã chọn')),
              ],
              if (_book.pages.length > 1)
                const PopupMenuItem(value: 'deletePage', child: Text('Xóa trang hiện tại')),
            ],
          ),
        ],
      ),
      body: Column(children: [
        _toolbar(),
        if (_stylusOnly) MaterialBanner(
          content: const Text('Chế độ chỉ bút: chạm bằng ngón tay không tạo nét viết. Bút cảm ứng thông thường có thể được nhận là ngón tay.'),
          actions: [TextButton(
            onPressed: () => setState(() => _stylusOnly = false),
            child: const Text('Tắt'),
          )],
        ),
        Expanded(child: Row(children: [
          if (wide) _pagesPanel(),
          Expanded(child: LayoutBuilder(builder: (context, constraints) {
            final view = Size(constraints.maxWidth, constraints.maxHeight);
            if (_viewportSize != view) {
              _viewportSize = view;
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (mounted) _fit(view.width, view.height);
              });
            }
            return ColoredBox(
              color: const Color(0xffe9edf6),
              child: Stack(children: [
                ClipRect(child: Listener(
                  behavior: HitTestBehavior.translucent,
                  onPointerDown: _onViewportDown,
                  onPointerMove: _onViewportMove,
                  onPointerUp: _onViewportEnd,
                  onPointerCancel: _onViewportEnd,
                  child: InteractiveViewer(
                    transformationController: _transform,
                    constrained: false,
                    boundaryMargin: const EdgeInsets.all(700),
                    minScale: 0.2,
                    maxScale: 5.0,
                    // Touch navigation is handled by the two-contact tracker.
                    // Prevent one finger from dragging the paper while drawing.
                    panEnabled: false,
                    scaleEnabled: false,
                    child: _paperSpread(),
                  ),
                )),
                Positioned(bottom: 14, right: 12, child: Row(children: [
                  _miniButton(Icons.remove, () => _zoom(0.8), 'Thu nhỏ'),
                  const SizedBox(width: 4),
                  _miniButton(Icons.fit_screen, () => _fit(view.width, view.height), 'Vừa trang'),
                  const SizedBox(width: 4),
                  _miniButton(Icons.add, () => _zoom(1.25), 'Phóng to'),
                ])),
              ]),
            );
          })),
        ])),
        if (!wide) _bottomPages(),
      ]),
    );
  }

  Widget _miniButton(IconData icon, VoidCallback onPressed, String tip) {
    return Material(
      color: Colors.white,
      elevation: 2,
      borderRadius: BorderRadius.circular(10),
      child: IconButton(icon: Icon(icon), tooltip: tip, onPressed: onPressed),
    );
  }

  Future<void> _chooseColor() async {
    var chosen = _tool == DrawingTool.laser ? _laserColor : _color;
    final picked = await showDialog<Color>(
      context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, update) {
        final hsv = HSVColor.fromColor(chosen);
        return AlertDialog(
          title: const Text('Bảng màu bút'),
          content: SizedBox(width: 340, child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Wrap(spacing: 9, runSpacing: 9, children: [
                for (final color in _colors)
                  InkWell(
                    onTap: () => update(() => chosen = color),
                    borderRadius: BorderRadius.circular(30),
                    child: Container(width: 35, height: 35,
                      decoration: BoxDecoration(color: color, shape: BoxShape.circle,
                        border: Border.all(color: color == chosen
                          ? Theme.of(ctx).colorScheme.primary : Colors.black26,
                          width: color == chosen ? 3.5 : 1))),
                  ),
              ]),
              const SizedBox(height: 12),
              const Align(alignment: Alignment.centerLeft,
                child: Text('Tự chọn màu (HSV)')),
              Slider(value: hsv.hue, max: 360,
                onChanged: (v) => update(() => chosen = hsv.withHue(v).toColor())),
              Slider(value: hsv.saturation, max: 1,
                onChanged: (v) => update(() => chosen = hsv.withSaturation(v).toColor())),
              Slider(value: hsv.value, max: 1,
                onChanged: (v) => update(() => chosen = hsv.withValue(v).toColor())),
              Text('Độ trong suốt: ${(chosen.a * 100).round()}%'),
              Slider(value: chosen.a.clamp(0.1, 1.0).toDouble(),
                min: .1, max: 1.0, divisions: 18,
                onChanged: (v) => update(() => chosen = chosen.withValues(alpha: v))),
              Text('#${chosen.toARGB32().toRadixString(16).substring(2).toUpperCase()}'),
            ],
          )),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(ctx, chosen), child: const Text('Chọn màu')),
          ],
        );
      }),
    );
    if (picked != null && mounted) setState(() {
      if (_tool == DrawingTool.laser) {
        _laserColor = picked;
      } else {
        _color = picked;
      }
    });
  }

  Widget _toolbar() {
    final tools = <(DrawingTool, IconData, String)>[
      (DrawingTool.pen, Icons.edit, 'Bút mực'),
      (DrawingTool.pencil, Icons.create_outlined, 'Bút chì'),
      (DrawingTool.brush, Icons.brush, 'Bút cọ'),
      (DrawingTool.calligraphy, Icons.draw_outlined, 'Bút thư pháp'),
      (DrawingTool.marker, Icons.border_color, 'Dạ quang'),
      (DrawingTool.laser, Icons.flash_on_outlined, 'Bút laser: viết tạm, tự mờ và biến mất'),
      (DrawingTool.eraser, Icons.auto_fix_normal, 'Tẩy một phần nét'),
      (DrawingTool.line, Icons.show_chart, 'Đường thẳng'),
      (DrawingTool.arrow, Icons.arrow_outward, 'Mũi tên'),
      (DrawingTool.rectangle, Icons.crop_square, 'Chữ nhật'),
      (DrawingTool.ellipse, Icons.circle_outlined, 'Hình elip'),
      (DrawingTool.triangle, Icons.change_history, 'Tam giác'),
      (DrawingTool.parallelogram, Icons.crop_landscape, 'Hình bình hành'),
      (DrawingTool.hexagon, Icons.hexagon_outlined, 'Lục giác'),
      (DrawingTool.cube, Icons.view_in_ar_outlined, 'Hình hộp 3D: nét khuất đứt'),
      (DrawingTool.select, Icons.touch_app_outlined, 'Chọn và kéo đối tượng'),
      (DrawingTool.lasso, Icons.gesture, 'Khoanh chọn nhiều nét'),
      (DrawingTool.text, Icons.text_fields, 'Chạm trang để thêm văn bản'),
      (DrawingTool.hand, Icons.pan_tool_outlined, 'Di chuyển trang'),
    ];
    return Material(
      color: Colors.white,
      elevation: 1,
      child: SizedBox(height: 62, child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        children: [
          for (final (tool, icon, tooltip) in tools)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 8),
              child: Tooltip(
                message: tooltip,
                child: IconButton.filledTonal(
                  onPressed: () => _switchTool(tool),
                  style: IconButton.styleFrom(
                    backgroundColor: _tool == tool
                        ? Theme.of(context).colorScheme.primaryContainer
                        : const Color(0xfff2f3f8),
                  ),
                  icon: Icon(icon, size: 22),
                ),
              ),
            ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 8),
            child: Tooltip(message: 'Tự nắn hình vẽ tay (bật/tắt)',
              child: IconButton.filledTonal(
                onPressed: () => setState(() =>
                    _autoRecognizeShapes = !_autoRecognizeShapes),
                style: IconButton.styleFrom(backgroundColor: _autoRecognizeShapes
                    ? Theme.of(context).colorScheme.primaryContainer
                    : const Color(0xfff2f3f8)),
                icon: const Icon(Icons.auto_fix_high))),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 8),
            child: Tooltip(message: 'Thêm PDF để ghi chú',
              child: IconButton.filledTonal(
                onPressed: _importing ? null : _importPdfPages,
                icon: const Icon(Icons.picture_as_pdf_outlined))),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 8),
            child: Tooltip(message: 'Chèn ảnh di chuyển / đổi cỡ',
              child: IconButton.filledTonal(
                onPressed: _insertOverlayImage,
                icon: const Icon(Icons.add_photo_alternate_outlined))),
          ),
          if (_hasSelection) ...[
            IconButton(tooltip: 'Nhân bản đối tượng chọn',
              onPressed: _duplicateSelection, icon: const Icon(Icons.content_copy_outlined)),
            IconButton(tooltip: 'Xóa đối tượng chọn',
              onPressed: _deleteSelection, icon: const Icon(Icons.delete_outline)),
          ],
          const VerticalDivider(indent: 12, endIndent: 12),
          for (final color in _colors.take(8))
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 3),
              child: Center(child: GestureDetector(
                onTap: () => setState(() {
                  if (_tool == DrawingTool.laser) {
                    _laserColor = color;
                  } else {
                    _color = color;
                  }
                }),
                child: Container(
                  width: 27, height: 27,
                  decoration: BoxDecoration(
                    color: color,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: (_tool == DrawingTool.laser ? _laserColor : _color) == color
                          ? Colors.black54 : Colors.white,
                      width: (_tool == DrawingTool.laser ? _laserColor : _color) == color
                          ? 3 : 1,
                    ),
                  ),
                ),
              )),
            ),
          IconButton(tooltip: 'Thêm màu / tùy chọn màu bút',
            onPressed: _chooseColor,
            icon: const Icon(Icons.palette_outlined)),
          const VerticalDivider(indent: 12, endIndent: 12),
          PopupMenuButton<StrokePattern>(
            tooltip: 'Kiểu nét đường và hình',
            initialValue: _strokePattern,
            onSelected: (p) => setState(() => _strokePattern = p),
            itemBuilder: (_) => const [
              PopupMenuItem(value: StrokePattern.solid, child: Text('━━━━  Nét liền')),
              PopupMenuItem(value: StrokePattern.dashed, child: Text('┄┄┄┄  Nét đứt')),
              PopupMenuItem(value: StrokePattern.dotted, child: Text('······  Nét chấm')),
            ],
            child: Padding(padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Center(child: Text(switch (_strokePattern) {
                StrokePattern.solid => '━━━━',
                StrokePattern.dashed => '┄┄┄',
                StrokePattern.dotted => '·····',
              }, style: const TextStyle(fontSize: 17))),
            ),
          ),
          const VerticalDivider(indent: 12, endIndent: 12),
          if (_tool == DrawingTool.laser) ...[
            PopupMenuButton<Duration>(
              tooltip: 'Thời gian nét laser biến mất sau khi nhấc bút',
              onSelected: (v) => setState(() => _laserDuration = v),
              itemBuilder: (_) => [
                for (final seconds in [2, 3, 5])
                  PopupMenuItem(value: Duration(seconds: seconds),
                    child: Text('Laser ${seconds}s')),
              ],
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Center(child: Text('Laser ${_laserDuration.inSeconds}s')),
              ),
            ),
            IconButton(
              tooltip: 'Xóa ngay tất cả nét laser đang hiện',
              onPressed: () => setState(_clearLaser),
              icon: const Icon(Icons.layers_clear_outlined),
            ),
          ],
          if (_tool == DrawingTool.eraser)
            PopupMenuButton<double>(
              tooltip: 'Đường kính tẩy trên trang giấy',
              onSelected: (v) => setState(() => _eraserRadius = v),
              itemBuilder: (_) => [
                for (final r in [6.0, 10.0, 14.0, 22.0, 32.0])
                  PopupMenuItem(value: r,
                    child: Text('Tẩy ${r.toInt() * 2} px')),
              ],
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Center(child: Text('Tẩy ${(_eraserRadius * 2).toInt()} px')),
              ),
            ),
          Tooltip(
            message: 'Chỉnh nét 0,5–30 px; mỗi loại bút nhớ cỡ riêng',
            child: TextButton.icon(
              onPressed: _choosePenWidth,
              icon: const Icon(Icons.line_weight, size: 18),
              label: Text('${(_tool == DrawingTool.laser ? _laserWidth : _size).toStringAsFixed(1)} px'),
            ),
          ),
          const VerticalDivider(indent: 12, endIndent: 12),
          PopupMenuButton<PaperPattern>(
            tooltip: 'Kiểu giấy',
            onSelected: (value) {
              _captureHistory();
              setState(() { _page.pattern = value; _contentRevision++; });
              _queueSave();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: PaperPattern.blank, child: Text('Giấy trắng')),
              PopupMenuItem(value: PaperPattern.lined, child: Text('Giấy kẻ ngang')),
              PopupMenuItem(value: PaperPattern.grid, child: Text('Giấy ô vuông')),
              PopupMenuItem(value: PaperPattern.dots, child: Text('Giấy chấm')),
            ],
            icon: const Icon(Icons.grid_on),
          ),
        ],
      )),
    );
  }

  Widget _pagesPanel() => Container(
    width: 138,
    color: const Color(0xfffafbff),
    child: Column(children: [
      const Padding(
        padding: EdgeInsets.all(12),
        child: Text('TRANG GIẤY', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
      ),
      Expanded(child: ListView.builder(
        itemCount: _book.pages.length,
        itemBuilder: (ctx, i) => Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          child: Card(
            color: i == _pageIndex ? const Color(0xffdfe6ff) : Colors.white,
            child: InkWell(
              onTap: () => _selectPage(i),
              child: SizedBox(height: 95, child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [const Icon(Icons.description_outlined),
                  const SizedBox(height: 6), Text('Trang ${i + 1}')],
              )),
            ),
          ),
        ),
      )),
      Padding(padding: const EdgeInsets.all(10), child: FilledButton.icon(
        onPressed: _newPage, icon: const Icon(Icons.add), label: const Text('Thêm trang'),
      )),
    ]),
  );

  Widget _bottomPages() => Container(
    color: Colors.white,
    height: 55,
    child: Row(children: [
      Expanded(child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: _book.pages.length,
        itemBuilder: (ctx, i) => Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 7),
          child: ChoiceChip(
            label: Text('Trang ${i + 1}'),
            selected: i == _pageIndex,
            onSelected: (_) => _selectPage(i),
          ),
        ),
      )),
      IconButton(tooltip: 'Thêm trang', onPressed: _newPage,
        icon: const Icon(Icons.add_circle_outline)),
    ]),
  );
}
