import 'dart:convert';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:crypto/crypto.dart';

import '../models/notebook.dart';
import 'notebook_asset_store.dart';

/// Portable .studyink.zip backups. A notebook JSON and media blobs are kept
/// separate, avoiding base64 amplification from the legacy JSON export.
///
/// ZIP entries are NEVER extracted as filesystem paths. Only these exact names
/// are accepted: meta.json, notebook.json, media/<sha256>.bin.
class ZipNotebookBackup {
  static const int maxZipBytes = 160 * 1024 * 1024;
  static const int maxNotebookBytes = 20 * 1024 * 1024;
  static const int maxTotalBytes = 240 * 1024 * 1024;
  static const int maxMediaCount = 512;
  static final RegExp _assetId = RegExp(r'^[a-f0-9]{64}$');
  static final RegExp _mediaPath = RegExp(r'^media/([a-f0-9]{64})\.bin$');

  static Future<Uint8List> encode(
    Notebook book,
    NotebookAssetStore assets,
  ) async {
    // Deep copy: never rewrite references on the editor's live notebook.
    final copy = Notebook.fromJson(book.toJson());
    final media = <String, Uint8List>{};
    var totalSize = 0;

    Future<String> addMedia(String? inline, String? id) async {
      if (inline == null && id == null) {
        throw const FormatException('Đối tượng ảnh không có dữ liệu');
      }
      final bytes = inline != null
          ? Uint8List.fromList(base64Decode(inline))
          : await assets.read(book.id, id!);
      if (bytes.isEmpty || bytes.length > NotebookAssetStore.maxAssetBytes) {
        throw const FormatException('Một ảnh vượt giới hạn dung lượng');
      }
      final hash = sha256.convert(bytes).toString();
      if (!media.containsKey(hash)) {
        if (media.length >= maxMediaCount) {
          throw const FormatException('Quá nhiều ảnh trong bản sao lưu');
        }
        totalSize += bytes.length;
        if (totalSize > maxTotalBytes) {
          throw const FormatException('Bản sao lưu vượt giới hạn 240 MB');
        }
        media[hash] = bytes;
      }
      return hash;
    }

    for (final page in copy.pages) {
      if (page.backgroundImageBase64 != null || page.backgroundAssetId != null) {
        page.backgroundAssetId = await addMedia(
          page.backgroundImageBase64, page.backgroundAssetId,
        );
        page.backgroundImageBase64 = null;
      }
      for (final element in page.elements) {
        if (element.type != 'image') continue;
        if (element.imageBase64 != null || element.imageAssetId != null) {
          element.imageAssetId = await addMedia(
            element.imageBase64, element.imageAssetId,
          );
          element.imageBase64 = null;
        }
      }
    }

    final notebookData = Uint8List.fromList(utf8.encode(copy.encode()));
    if (notebookData.length > maxNotebookBytes) {
      throw const FormatException('Dữ liệu nét viết vượt giới hạn 20 MB');
    }
    final metaData = utf8.encode(jsonEncode({
      'format': 'studyink-zip',
      'version': 1,
      'createdAt': DateTime.now().toUtc().toIso8601String(),
      'mediaCount': media.length,
    }));
    final zip = Archive()
      ..add(ArchiveFile.bytes('meta.json', metaData))
      ..add(ArchiveFile.bytes('notebook.json', notebookData));
    for (final entry in media.entries) {
      zip.add(ArchiveFile.bytes('media/${entry.key}.bin', entry.value));
    }
    final encoded = ZipEncoder().encodeBytes(zip);
    if (encoded.length > maxZipBytes) {
      throw const FormatException('ZIP sao lưu vượt giới hạn 160 MB');
    }
    return encoded;
  }

  /// Parse a backup *without writing any files*. Each digest is verified,
  /// including orphan media. The UI can then decide whether to save it.
  static ZipNotebookBundle decode(Uint8List bytes) {
    if (bytes.isEmpty || bytes.length > maxZipBytes) {
      throw const FormatException('Dung lượng ZIP không hợp lệ');
    }
    final archive = ZipDecoder().decodeBytes(bytes, verify: true);
    if (archive.length < 2 || archive.length > maxMediaCount + 2) {
      throw const FormatException('Số lượng tệp ZIP không hợp lệ');
    }
    final entries = <String, ArchiveFile>{};
    var total = 0;
    for (final file in archive) {
      if (!file.isFile || file.isSymbolicLink || file.isHardLink) {
        throw const FormatException('ZIP có đường dẫn hoặc liên kết không hợp lệ');
      }
      final name = file.name;
      final isMedia = _mediaPath.hasMatch(name);
      if (name != 'meta.json' && name != 'notebook.json' && !isMedia) {
        throw const FormatException('ZIP chứa tệp không được phép');
      }
      if (entries.containsKey(name)) {
        throw const FormatException('Tên tệp trùng trong ZIP');
      }
      if (file.size < 0 ||
          file.size > (isMedia ? NotebookAssetStore.maxAssetBytes : maxNotebookBytes)) {
        throw const FormatException('Có tệp ZIP vượt giới hạn');
      }
      total += file.size;
      if (total > maxTotalBytes) {
        throw const FormatException('Tổng dữ liệu ZIP vượt giới hạn');
      }
      entries[name] = file;
    }
    final metaFile = entries['meta.json'];
    final notebookFile = entries['notebook.json'];
    if (metaFile == null || notebookFile == null) {
      throw const FormatException('ZIP thiếu thông tin sổ tay');
    }
    final meta = jsonDecode(utf8.decode(metaFile.readBytes() ?? (throw const FormatException('Không đọc được thông tin ZIP')))) as Map;
    if (meta['format'] != 'studyink-zip' || meta['version'] != 1) {
      throw const FormatException('Phiên bản ZIP chưa được hỗ trợ');
    }
    final book = Notebook.decode(utf8.decode(notebookFile.readBytes() ?? (throw const FormatException('Không đọc được sổ tay'))));
    final media = <String, Uint8List>{};
    for (final entry in entries.entries) {
      final match = _mediaPath.firstMatch(entry.key);
      if (match == null) continue;
      final digest = match.group(1)!;
      final data = entry.value.readBytes() ??
          (throw const FormatException('Không đọc được ảnh trong ZIP'));
      if (data.isEmpty ||
          data.length > NotebookAssetStore.maxAssetBytes ||
          sha256.convert(data).toString() != digest) {
        throw const FormatException('Ảnh trong ZIP bị lỗi hoặc sai mã băm');
      }
      media[digest] = data;
    }
    if (meta['mediaCount'] != media.length) {
      throw const FormatException('Số tệp ảnh không khớp bản sao lưu');
    }
    final referenced = <String>{};
    void checkReference(String? id, String? inline) {
      if (inline != null) {
        throw const FormatException('ZIP chứa ảnh nhúng không đúng định dạng');
      }
      if (id == null) return;
      if (!_assetId.hasMatch(id) || !media.containsKey(id)) {
        throw const FormatException('Bản sao lưu thiếu ảnh hoặc ảnh bị thay đổi');
      }
      referenced.add(id);
    }
    for (final page in book.pages) {
      checkReference(page.backgroundAssetId, page.backgroundImageBase64);
      for (final element in page.elements) {
        if (element.type == 'image') {
          checkReference(element.imageAssetId, element.imageBase64);
        }
      }
    }
    if (referenced.length != media.length) {
      throw const FormatException('ZIP chứa tệp ảnh không được tham chiếu');
    }
    return ZipNotebookBundle(book: book, media: media);
  }
}

class ZipNotebookBundle {
  final Notebook book;
  final Map<String, Uint8List> media;
  const ZipNotebookBundle({required this.book, required this.media});

  /// Import into a fresh notebook ID: never overwrite an existing notebook.
  Future<Notebook> restore(NotebookAssetStore assets, {String? newId}) async {
    final id = newId ?? DateTime.now().microsecondsSinceEpoch.toString();
    final now = DateTime.now();
    final result = Notebook(
      id: id,
      title: book.title,
      updatedAt: now,
      pages: [
        for (var i = 0; i < book.pages.length; i++)
          book.pages[i].duplicate('${id}_$i'),
      ],
    );
    for (final entry in media.entries) {
      final storedId = await assets.put(id, entry.value);
      if (storedId != entry.key) {
        throw const FormatException('Lỗi lưu ảnh: mã băm không khớp');
      }
    }
    return result;
  }
}
