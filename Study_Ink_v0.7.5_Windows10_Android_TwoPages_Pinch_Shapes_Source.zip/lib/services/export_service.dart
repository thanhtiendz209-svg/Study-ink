import 'dart:typed_data';
import 'dart:convert';
import 'dart:ui' as ui;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/notebook.dart';
import 'notebook_asset_store.dart';
import 'portable_backup.dart';
import 'zip_notebook_backup.dart';
import '../widgets/page_painter.dart';

class ExportService {
  static final _assets = NotebookAssetStore();

  static Future<Uint8List> _resolveImage(Notebook book,
      String? base64Data, String? assetId) async {
    if (base64Data != null) return base64Decode(base64Data);
    if (assetId != null) return _assets.read(book.id, assetId);
    throw const FormatException('Không tìm thấy dữ liệu ảnh');
  }

  /// Export all pages to A4 PDF with rasterized annotations and backgrounds.
  static Future<bool> exportPdf(Notebook book) async {
    final pdf = pw.Document();
    for (final page in book.pages) {
      ui.Image? background;
      final elementImages = <String, ui.Image>{};
      try {
        if (page.backgroundImageBase64 != null || page.backgroundAssetId != null) {
          final codec = await ui.instantiateImageCodec(
            await _resolveImage(book, page.backgroundImageBase64,
              page.backgroundAssetId), targetWidth: 900);
          try {
            final frame = await codec.getNextFrame();
            background = frame.image;
          } finally { codec.dispose(); }
        }
        for (final element in page.elements) {
          if (element.type != 'image' ||
              (element.imageBase64 == null && element.imageAssetId == null)) continue;
          final codec = await ui.instantiateImageCodec(
            await _resolveImage(book, element.imageBase64,
              element.imageAssetId), targetWidth: 900);
          try {
            final frame = await codec.getNextFrame();
            elementImages[element.id] = frame.image;
          } finally { codec.dispose(); }
        }
        final recorder = ui.PictureRecorder();
        final canvas = Canvas(recorder);
        PagePainter(pattern: page.pattern, strokes: page.strokes,
          elements: page.elements, elementImages: elementImages,
          background: background).paint(canvas, const Size(paperWidth, paperHeight));
        final picture = recorder.endRecording();
        ByteData? data;
        try {
          final image = await picture.toImage(paperWidth.toInt(), paperHeight.toInt());
          try {
            data = await image.toByteData(format: ui.ImageByteFormat.png);
          } finally { image.dispose(); }
        } finally { picture.dispose(); }
        if (data == null) throw StateError('Không thể kết xuất trang PDF');
        final png = Uint8List.view(data.buffer, data.offsetInBytes, data.lengthInBytes);
        pdf.addPage(pw.Page(pageFormat: PdfPageFormat.a4,
          margin: pw.EdgeInsets.zero,
          build: (_) => pw.Image(pw.MemoryImage(png), fit: pw.BoxFit.fill)));
      } finally {
        background?.dispose();
        for (final image in elementImages.values) { image.dispose(); }
      }
    }
    final bytes = await pdf.save();
    final target = await FilePicker.saveFile(
      fileName: '${_safeName(book.title)}.pdf', bytes: bytes);
    return target != null;
  }

  /// Default portable format since v0.6: media are separate from JSON.
  static Future<bool> exportBackup(Notebook book) async {
    final bytes = await ZipNotebookBackup.encode(book, _assets);
    final target = await FilePicker.saveFile(
      fileName: '${_safeName(book.title)}.studyink.zip',
      bytes: bytes,
    );
    return target != null;
  }

  /// Retain a separate legacy export for older Study Ink builds.
  static Future<bool> exportLegacyBackup(Notebook book) async {
    final backup = await PortableBackup.encode(book, _assets);
    final bytes = Uint8List.fromList(utf8.encode(backup));
    if (bytes.length > 85 * 1024 * 1024) {
      throw const FormatException('Bản sao JSON cũ vượt giới hạn 85 MB');
    }
    final target = await FilePicker.saveFile(
      fileName: '${_safeName(book.title)}.studyink.json', bytes: bytes,
    );
    return target != null;
  }

  static Future<Notebook?> importBackup() async {
    final file = await FilePicker.pickFile(
      type: FileType.custom,
      allowedExtensions: ['zip', 'json'],
    );
    if (file == null) return null;
    final reportedSize = file.lengthSync();
    if (reportedSize != null && reportedSize > ZipNotebookBackup.maxZipBytes) {
      throw const FormatException('Tệp sao lưu quá lớn');
    }
    final bytes = await file.readAsBytes();
    if (bytes.length > ZipNotebookBackup.maxZipBytes) {
      throw const FormatException('Tệp sao lưu quá lớn');
    }
    if (file.name.toLowerCase().endsWith('.zip')) {
      final bundle = ZipNotebookBackup.decode(bytes);
      return bundle.restore(_assets);
    }
    if (!file.name.toLowerCase().endsWith('.json') ||
        bytes.length > 85 * 1024 * 1024) {
      throw const FormatException('Tệp JSON sao lưu không hợp lệ');
    }
    return _importLegacyJson(utf8.decode(bytes));
  }

  static Notebook _importLegacyJson(String content) {
    final decoded = PortableBackup.decode(content);
    // Always use a new notebook ID so imports cannot overwrite local data.
    final now = DateTime.now();
    final id = now.microsecondsSinceEpoch.toString();
    return Notebook(
      id: id,
      title: decoded.title,
      updatedAt: now,
      pages: [
        for (var i = 0; i < decoded.pages.length; i++)
          NotePage(
            id: '${id}_$i',
            pattern: decoded.pages[i].pattern,
            strokes: [for (final s in decoded.pages[i].strokes) s.clone()],
            elements: [
              for (var j = 0; j < decoded.pages[i].elements.length; j++)
                decoded.pages[i].elements[j]
                    .copyWith(id: '${id}_element_${i}_$j')
                  ..imageAssetId = null,
            ],
            backgroundImageBase64: decoded.pages[i].backgroundImageBase64,
            backgroundAssetId: null,
          ),
      ],
    );
  }

  static String _safeName(String value) =>
      value.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_').trim().isEmpty
          ? 'studyink'
          : value.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_').trim();
}
