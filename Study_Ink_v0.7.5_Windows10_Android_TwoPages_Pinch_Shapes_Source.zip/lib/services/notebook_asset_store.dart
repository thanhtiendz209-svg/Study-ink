import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:path_provider/path_provider.dart';

import '../models/notebook.dart';

/// Assets are stored by their SHA-256 digest, scoped to one notebook.
/// This avoids megabytes of Base64 in the notebook JSON. An asset is never
/// removed when editing a page because the .bak notebook may still need it.
class NotebookAssetStore {
  final Directory? rootOverride;
  NotebookAssetStore({this.rootOverride});

  static const maxAssetBytes = 20 * 1024 * 1024;
  static final _validBookId = RegExp(r'^[a-zA-Z0-9_-]+$');
  static final _validAssetId = RegExp(r'^[a-f0-9]{64}$');

  Future<Directory> _directory(String bookId, {bool create = true}) async {
    if (!_validBookId.hasMatch(bookId)) {
      throw const FormatException('Mã sổ tay không hợp lệ');
    }
    final documents = rootOverride ?? await getApplicationDocumentsDirectory();
    final dir = Directory('${documents.path}${Platform.pathSeparator}study_ink'
        '${Platform.pathSeparator}assets${Platform.pathSeparator}$bookId');
    if (create) await dir.create(recursive: true);
    return dir;
  }

  Future<String> put(String bookId, Uint8List bytes) async {
    if (bytes.isEmpty || bytes.length > maxAssetBytes) {
      throw const FormatException('Dung lượng ảnh không hợp lệ');
    }
    final digest = sha256.convert(bytes).toString();
    final folder = await _directory(bookId);
    final destination = File('${folder.path}${Platform.pathSeparator}$digest.bin');
    if (await destination.exists()) return digest;
    // Write completely before publishing. A separate temporary filename avoids
    // collision between concurrent import and autosave operations.
    final tmp = File('${destination.path}.${DateTime.now().microsecondsSinceEpoch}.tmp');
    try {
      await tmp.writeAsBytes(bytes, flush: true);
      if (!await destination.exists()) {
        try {
          await tmp.rename(destination.path);
        } on FileSystemException {
          if (!await destination.exists()) rethrow;
        }
      }
    } finally {
      if (await tmp.exists()) await tmp.delete();
    }
    return digest;
  }

  Future<Uint8List> read(String bookId, String assetId) async {
    if (!_validAssetId.hasMatch(assetId)) {
      throw const FormatException('Mã hình ảnh không hợp lệ');
    }
    final folder = await _directory(bookId, create: false);
    final file = File('${folder.path}${Platform.pathSeparator}$assetId.bin');
    final bytes = await file.readAsBytes();
    // Detect accidental corruption rather than silently displaying wrong media.
    if (sha256.convert(bytes).toString() != assetId) {
      throw const FormatException('Dữ liệu ảnh bị thay đổi hoặc hỏng');
    }
    return bytes;
  }

  Future<void> externalize(Notebook book) async {
    for (final page in book.pages) {
      final background = page.backgroundImageBase64;
      if (background != null) {
        final id = await put(book.id, base64Decode(background));
        page.backgroundAssetId = id;
        page.backgroundImageBase64 = null;
      }
      for (final item in page.elements) {
        final image = item.imageBase64;
        if (item.type == 'image' && image != null) {
          final id = await put(book.id, base64Decode(image));
          item.imageAssetId = id;
          item.imageBase64 = null;
        }
      }
    }
  }

  static bool containsInlineMedia(Notebook book) => book.pages.any((page) =>
      page.backgroundImageBase64 != null ||
      page.elements.any((e) => e.imageBase64 != null));

  Future<void> deleteBookAssets(String bookId) async {
    final folder = await _directory(bookId, create: false);
    if (await folder.exists()) await folder.delete(recursive: true);
  }
}
