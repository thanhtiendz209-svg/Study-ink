import 'dart:math' as math;
import 'notebook.dart';

/// An in-app clipboard. Deliberately does not expose notebook-private media
/// paths through the platform clipboard; assets remain referenced by ID.
class SelectionClipboard {
  final List<InkStroke> strokes;
  final List<PageElement> elements;
  final double sourceX;
  final double sourceY;

  const SelectionClipboard._(this.strokes, this.elements, this.sourceX, this.sourceY);

  bool get isEmpty => strokes.isEmpty && elements.isEmpty;

  factory SelectionClipboard.capture(NotePage page,
      Set<int> selectedStrokes, Set<int> selectedElements) {
    final strokes = <InkStroke>[
      for (final index in selectedStrokes.toList()..sort())
        if (index >= 0 && index < page.strokes.length) page.strokes[index].clone(),
    ];
    final elements = <PageElement>[
      for (final index in selectedElements.toList()..sort())
        if (index >= 0 && index < page.elements.length) page.elements[index].clone(),
    ];
    var left = double.infinity;
    var top = double.infinity;
    for (final stroke in strokes) {
      for (final point in stroke.points) {
        left = math.min(left, point.x);
        top = math.min(top, point.y);
      }
    }
    for (final item in elements) {
      left = math.min(left, item.x);
      top = math.min(top, item.y);
    }
    if (left == double.infinity) left = 0;
    if (top == double.infinity) top = 0;
    return SelectionClipboard._(strokes, elements, left, top);
  }

  /// Pastes without sharing mutable stroke/element instances with the source.
  /// Returns indices of pasted strokes/elements for immediate selection.
  ({Set<int> strokes, Set<int> elements}) pasteInto(
      NotePage destination, String Function() nextId,
      {double? x, double? y}) {
    final dx = (x ?? sourceX + 24) - sourceX;
    final dy = (y ?? sourceY + 24) - sourceY;
    final strokesAdded = <int>{};
    final elementsAdded = <int>{};
    for (final stroke in strokes) {
      destination.strokes.add(stroke.translated(dx, dy));
      strokesAdded.add(destination.strokes.length - 1);
    }
    for (final element in elements) {
      destination.elements.add(element.translated(dx, dy).copyWith(id: nextId()));
      elementsAdded.add(destination.elements.length - 1);
    }
    return (strokes: strokesAdded, elements: elementsAdded);
  }
}
