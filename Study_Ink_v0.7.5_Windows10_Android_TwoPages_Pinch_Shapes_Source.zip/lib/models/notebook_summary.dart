/// Lightweight library entry. Unlike Notebook, no ink or embedded PDF images.
class NotebookSummary {
  final String id;
  final String title;
  final DateTime updatedAt;
  final int pageCount;

  const NotebookSummary({
    required this.id,
    required this.title,
    required this.updatedAt,
    required this.pageCount,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'updatedAt': updatedAt.toIso8601String(),
    'pageCount': pageCount,
  };

  factory NotebookSummary.fromJson(Map<String, dynamic> map) {
    final id = map['id'];
    final count = map['pageCount'];
    if (id is! String || !RegExp(r'^[a-zA-Z0-9_-]+$').hasMatch(id) ||
        count is! int || count < 1) {
      throw const FormatException('Chỉ mục sổ tay không hợp lệ');
    }
    return NotebookSummary(
      id: id,
      title: map['title'] as String? ?? 'Sổ tay',
      updatedAt: DateTime.tryParse(map['updatedAt'] as String? ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0),
      pageCount: count,
    );
  }
}
