import 'dart:convert';

/// Logical A4-like page shared by Windows 10 and Android devices.
const double paperWidth = 900;
const double paperHeight = 1272;

enum PaperPattern { blank, lined, grid, dots }
enum DrawingTool { pen, pencil, brush, calligraphy, marker, laser, eraser,
  line, arrow, rectangle, ellipse, triangle, parallelogram, hexagon,
  cube, select, lasso, text, hand }

/// The pattern applies to geometric shapes and can also be saved on freehand ink.
/// Defaults to solid so notebooks created with Study Ink v0.6 remain readable.
enum StrokePattern { solid, dashed, dotted }

class InkPoint {
  final double x;
  final double y;
  final double pressure;
  const InkPoint(this.x, this.y, [this.pressure = 1.0]);

  /// Compact lossless point format: [x, y] or [x, y, pressure].
  /// Old map-shaped points are still accepted when opening v1-v4 notebooks.
  List<num> toJson() => pressure == 1.0
      ? <num>[x, y]
      : <num>[x, y, pressure];

  factory InkPoint.fromJson(Object? source) {
    if (source is List && (source.length == 2 || source.length == 3) &&
        source[0] is num && source[1] is num &&
        (source.length == 2 || source[2] is num)) {
      return InkPoint(
        (source[0] as num).toDouble(),
        (source[1] as num).toDouble(),
        source.length == 3 ? (source[2] as num).toDouble() : 1.0,
      );
    }
    if (source is Map) {
      final json = Map<String, dynamic>.from(source);
      if (json['x'] is num && json['y'] is num) {
        return InkPoint(
          (json['x'] as num).toDouble(),
          (json['y'] as num).toDouble(),
          ((json['pressure'] as num?) ?? 1).toDouble(),
        );
      }
    }
    throw const FormatException('Điểm nét viết không hợp lệ');
  }
}

class InkStroke {
  final String kind;
  final int color;
  final double width;
  final StrokePattern pattern;
  final List<InkPoint> points;

  InkStroke({
    required this.kind,
    required this.color,
    required this.width,
    this.pattern = StrokePattern.solid,
    required this.points,
  });

  InkStroke translated(double dx, double dy) => InkStroke(
        kind: kind,
        color: color,
        width: width,
        pattern: pattern,
        points: [for (final p in points) InkPoint(p.x + dx, p.y + dy, p.pressure)],
      );

  InkStroke clone() => translated(0, 0);

  Map<String, dynamic> toJson() => {
        'kind': kind,
        'color': color,
        'width': width,
        'pattern': pattern.name,
        'points': points.map((p) => p.toJson()).toList(),
      };

  factory InkStroke.fromJson(Map<String, dynamic> json) => InkStroke(
        kind: json['kind'] as String? ?? 'pen',
        color: (json['color'] as num?)?.toInt() ?? 0xff172b4d,
        width: ((json['width'] as num?) ?? 3).toDouble(),
        pattern: StrokePattern.values.firstWhere(
          (p) => p.name == json['pattern'],
          orElse: () => StrokePattern.solid,
        ),
        points: ((json['points'] as List?) ?? [])
            .map((p) => InkPoint.fromJson(p))
            .toList(),
      );
}

/// Editable overlay on top of a PDF/image background and hand-drawn ink.
/// Images are stored inline for portable offline backup; no external URL.
class PageElement {
  final String id;
  final String type; // 'text' or 'image'
  double x;
  double y;
  double width;
  double height;
  String text;
  String? imageBase64;
  /// Content-addressed asset identifier (SHA-256 hex). No local absolute paths.
  String? imageAssetId;
  double fontSize;
  int color;

  PageElement({
    required this.id,
    required this.type,
    required this.x,
    required this.y,
    required this.width,
    required this.height,
    this.text = '',
    this.imageBase64,
    this.imageAssetId,
    this.fontSize = 30,
    this.color = 0xff172b4d,
  });

  PageElement copyWith({double? x, double? y, double? width, double? height, String? id}) =>
      PageElement(
        id: id ?? this.id,
        type: type,
        x: x ?? this.x,
        y: y ?? this.y,
        width: width ?? this.width,
        height: height ?? this.height,
        text: text,
        imageBase64: imageBase64,
        imageAssetId: imageAssetId,
        fontSize: fontSize,
        color: color,
      );

  PageElement clone() => copyWith();
  PageElement translated(double dx, double dy) => copyWith(x: x + dx, y: y + dy);

  Map<String, dynamic> toJson() => {
        'id': id, 'type': type, 'x': x, 'y': y,
        'width': width, 'height': height,
        if (type == 'text') ...{'text': text, 'fontSize': fontSize, 'color': color},
        if (type == 'image' && imageBase64 != null) 'imageBase64': imageBase64,
        if (type == 'image' && imageAssetId != null) 'imageAssetId': imageAssetId,
      };

  factory PageElement.fromJson(Map<String, dynamic> json) {
    final type = json['type'];
    if (type != 'text' && type != 'image') {
      throw const FormatException('Loại đối tượng trong trang không hợp lệ');
    }
    return PageElement(
      id: json['id'] as String? ?? DateTime.now().microsecondsSinceEpoch.toString(),
      type: type as String,
      x: ((json['x'] as num?) ?? 120).toDouble(),
      y: ((json['y'] as num?) ?? 120).toDouble(),
      width: ((json['width'] as num?) ?? 360).toDouble().clamp(24, 2000).toDouble(),
      height: ((json['height'] as num?) ?? 180).toDouble().clamp(24, 2000).toDouble(),
      text: json['text'] as String? ?? '',
      imageBase64: json['imageBase64'] as String?,
      imageAssetId: json['imageAssetId'] as String?,
      fontSize: ((json['fontSize'] as num?) ?? 30).toDouble().clamp(10, 120).toDouble(),
      color: (json['color'] as num?)?.toInt() ?? 0xff172b4d,
    );
  }
}

class NotePage {
  String id;
  PaperPattern pattern;
  List<InkStroke> strokes;
  List<PageElement> elements;
  /// JPEG/PNG raster background, e.g. an imported page of a PDF.
  String? backgroundImageBase64;
  /// Backing media saved as a binary file alongside the notebook JSON.
  String? backgroundAssetId;

  NotePage({
    required this.id,
    this.pattern = PaperPattern.grid,
    List<InkStroke>? strokes,
    List<PageElement>? elements,
    this.backgroundImageBase64,
    this.backgroundAssetId,
  })  : strokes = strokes ?? [],
        elements = elements ?? [];

  NotePage duplicate(String newId) => NotePage(
        id: newId, pattern: pattern,
        backgroundImageBase64: backgroundImageBase64,
        backgroundAssetId: backgroundAssetId,
        strokes: [for (final stroke in strokes) stroke.clone()],
        elements: [for (final element in elements) element.clone()],
      );

  Map<String, dynamic> toJson() => {
        'id': id, 'pattern': pattern.name,
        'strokes': strokes.map((s) => s.toJson()).toList(),
        'elements': elements.map((e) => e.toJson()).toList(),
        if (backgroundImageBase64 != null) 'backgroundImageBase64': backgroundImageBase64,
        if (backgroundAssetId != null) 'backgroundAssetId': backgroundAssetId,
      };

  factory NotePage.fromJson(Map<String, dynamic> json) => NotePage(
        id: json['id'] as String? ?? DateTime.now().microsecondsSinceEpoch.toString(),
        pattern: PaperPattern.values.firstWhere(
          (v) => v.name == json['pattern'], orElse: () => PaperPattern.grid,
        ),
        backgroundImageBase64: json['backgroundImageBase64'] as String?,
        backgroundAssetId: json['backgroundAssetId'] as String?,
        strokes: ((json['strokes'] as List?) ?? [])
            .map((e) => InkStroke.fromJson(Map<String, dynamic>.from(e as Map))).toList(),
        elements: ((json['elements'] as List?) ?? [])
            .map((e) => PageElement.fromJson(Map<String, dynamic>.from(e as Map))).toList(),
      );
}

class Notebook {
  final String id;
  String title;
  DateTime updatedAt;
  List<NotePage> pages;

  Notebook({required this.id, required this.title,
    required this.updatedAt, required this.pages});

  factory Notebook.create({String title = 'Sổ tay mới'}) {
    final now = DateTime.now();
    final id = now.microsecondsSinceEpoch.toString();
    return Notebook(id: id, title: title, updatedAt: now,
      pages: [NotePage(id: '${id}_1')]);
  }

  Map<String, dynamic> toJson() => {
        'format': 'studyink', 'schemaVersion': 5,
        'id': id, 'title': title, 'updatedAt': updatedAt.toIso8601String(),
        'pages': pages.map((p) => p.toJson()).toList(),
      };

  /// Export a backwards-compatible v4 JSON notebook for older Study Ink apps.
  /// The main autosave / ZIP backup uses compact v5 points without precision loss.
  Map<String, dynamic> toLegacyJson() {
    final snapshot = toJson();
    snapshot['schemaVersion'] = 4;
    for (final rawPage in snapshot['pages'] as List) {
      final page = rawPage as Map<String, dynamic>;
      for (final rawStroke in page['strokes'] as List) {
        final stroke = rawStroke as Map<String, dynamic>;
        stroke['points'] = [
          for (final rawPoint in stroke['points'] as List)
            {
              'x': (rawPoint as List)[0],
              'y': rawPoint[1],
              'pressure': rawPoint.length == 3 ? rawPoint[2] : 1.0,
            },
        ];
      }
    }
    return snapshot;
  }

  String encode() => jsonEncode(toJson());

  factory Notebook.decode(String value) {
    final json = jsonDecode(value);
    if (json is! Map) throw const FormatException('Dữ liệu sổ tay không hợp lệ');
    return Notebook.fromJson(Map<String, dynamic>.from(json));
  }

  factory Notebook.fromJson(Map<String, dynamic> json) {
    final version = json['schemaVersion'];
    if (json['format'] != 'studyink' || ![1, 2, 3, 4, 5].contains(version)) {
      throw const FormatException('Định dạng sổ tay chưa được hỗ trợ');
    }
    final rawPages = (json['pages'] as List?) ?? [];
    final pages = rawPages.map(
        (e) => NotePage.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    if (pages.isEmpty) pages.add(NotePage(id: 'restored_1'));
    return Notebook(
      id: json['id'] as String,
      title: json['title'] as String? ?? 'Sổ tay',
      updatedAt: DateTime.tryParse(json['updatedAt'] as String? ?? '') ?? DateTime.now(),
      pages: pages,
    );
  }
}
