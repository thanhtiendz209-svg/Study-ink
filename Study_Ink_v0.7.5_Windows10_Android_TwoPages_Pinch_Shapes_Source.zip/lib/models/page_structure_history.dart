import 'notebook.dart';

enum PageChangeKind { inserted, deleted }

class PageChange {
  final PageChangeKind kind;
  final int index;
  final NotePage snapshot;
  PageChange(this.kind, this.index, NotePage page)
      : snapshot = page.duplicate(page.id);
}

/// Undo/redo for adding, duplicating and deleting pages. Kept separate from
/// per-page ink history so restoring a deleted page does not lose its strokes.
/// This history is in-memory only and bounded to protect low-memory devices.
class PageStructureHistory {
  final List<PageChange> _undo = [];
  final List<PageChange> _redo = [];
  static const int maxChanges = 30;

  bool get canUndo => _undo.isNotEmpty;
  bool get canRedo => _redo.isNotEmpty;

  void recordInsert(NotePage page, int index) => _record(
      PageChange(PageChangeKind.inserted, index, page));

  void recordDelete(NotePage page, int index) => _record(
      PageChange(PageChangeKind.deleted, index, page));

  void _record(PageChange change) {
    _undo.add(change);
    if (_undo.length > maxChanges) _undo.removeAt(0);
    _redo.clear();
  }

  /// Return the index to display after the operation or null when no action.
  int? undo(List<NotePage> pages) => _apply(pages, _undo, _redo, undo: true);
  int? redo(List<NotePage> pages) => _apply(pages, _redo, _undo, undo: false);

  int? _apply(List<NotePage> pages, List<PageChange> source,
      List<PageChange> target, {required bool undo}) {
    if (source.isEmpty) return null;
    final change = source.last;
    final shouldRemove = (change.kind == PageChangeKind.inserted) == undo;
    if (shouldRemove) {
      // Locate by stable page ID, not an index that may have moved.
      final found = pages.indexWhere((page) => page.id == change.snapshot.id);
      if (found < 0 || pages.length <= 1) return null;
      final removed = pages.removeAt(found);
      target.add(PageChange(change.kind, found, removed));
      source.removeLast();
      if (target.length > maxChanges) target.removeAt(0);
      return found.clamp(0, pages.length - 1).toInt();
    }
    if (pages.any((page) => page.id == change.snapshot.id)) return null;
    final index = change.index.clamp(0, pages.length).toInt();
    final restored = change.snapshot.duplicate(change.snapshot.id);
    pages.insert(index, restored);
    target.add(PageChange(change.kind, index, restored));
    source.removeLast();
    if (target.length > maxChanges) target.removeAt(0);
    return index;
  }
}
