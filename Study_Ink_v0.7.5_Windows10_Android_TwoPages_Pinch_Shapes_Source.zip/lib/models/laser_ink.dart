import 'dart:math' as math;

import 'notebook.dart';

/// A temporary overlay stroke. These strokes must NEVER be added to NotePage.
/// The clock is passed explicitly so lifetime and fade can be tested without
/// timers or device frame-rate assumptions.
class LaserTrace {
  final InkStroke stroke;
  final Duration duration;
  DateTime? finishedAt;

  LaserTrace({required this.stroke, required this.duration});

  bool get isDrawing => finishedAt == null;

  double opacityAt(DateTime now) {
    if (finishedAt == null) return 1.0;
    final elapsedMs = now.difference(finishedAt!).inMilliseconds;
    if (elapsedMs <= 0) return 1.0;
    if (elapsedMs >= duration.inMilliseconds) return 0.0;
    // Stay bright at first, then dissolve over the final 800 ms.
    final fadeMs = math.min(800, duration.inMilliseconds);
    final brightMs = duration.inMilliseconds - fadeMs;
    if (elapsedMs <= brightMs) return 1.0;
    return ((duration.inMilliseconds - elapsedMs) / fadeMs).clamp(0.0, 1.0);
  }

  bool expiredAt(DateTime now) =>
      finishedAt != null && now.difference(finishedAt!) >= duration;
}

/// Keeps transient laser traces separate from notebook ink/undo/exports.
/// Each finished gesture has its own independent expiration time.
class LaserInkSession {
  final List<LaserTrace> _traces = [];
  LaserTrace? _active;

  List<LaserTrace> get traces => List.unmodifiable(_traces);
  bool get hasActive => _active != null;
  bool get isEmpty => _traces.isEmpty;

  void start(InkPoint point, {required int color, required double width,
      required Duration duration}) {
    if (_active != null) cancel();
    final trace = LaserTrace(
      stroke: InkStroke(kind: 'laser', color: color, width: width,
        points: [point]),
      duration: duration,
    );
    _traces.add(trace);
    _active = trace;
  }

  void append(InkPoint point) {
    final trace = _active;
    if (trace == null) return;
    final last = trace.stroke.points.last;
    if (math.sqrt(math.pow(last.x - point.x, 2) +
        math.pow(last.y - point.y, 2)) < 0.6) return;
    trace.stroke.points.add(point);
  }

  void finish(DateTime now) {
    final trace = _active;
    if (trace == null) return;
    trace.finishedAt = now;
    _active = null;
  }

  void cancel() {
    if (_active != null) _traces.remove(_active);
    _active = null;
  }

  bool removeExpired(DateTime now) {
    final before = _traces.length;
    _traces.removeWhere((trace) => trace.expiredAt(now));
    return before != _traces.length;
  }

  void clear() {
    _active = null;
    _traces.clear();
  }
}
