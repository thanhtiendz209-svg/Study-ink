import 'dart:ui' show BlurStyle, MaskFilter;

import 'package:flutter/material.dart';

import '../models/laser_ink.dart';

/// Screen-only glow. Do not invoke from PDF/export or persistent PagePainter.
class LaserInkPainter {
  const LaserInkPainter._();

  static Path _smoothPath(LaserTrace trace) {
    final points = trace.stroke.points;
    final path = Path();
    if (points.isEmpty) return path;
    path.moveTo(points.first.x, points.first.y);
    for (var i = 1; i < points.length - 1; i++) {
      final a = points[i];
      final b = points[i + 1];
      path.quadraticBezierTo(a.x, a.y, (a.x + b.x) / 2, (a.y + b.y) / 2);
    }
    if (points.length > 1) {
      path.lineTo(points.last.x, points.last.y);
    }
    return path;
  }

  static void draw(Canvas canvas, LaserTrace trace, DateTime now) {
    final opacity = trace.opacityAt(now);
    final points = trace.stroke.points;
    if (opacity <= 0 || points.isEmpty) return;
    final core = Color(trace.stroke.color);
    final width = trace.stroke.width;
    final path = _smoothPath(trace);
    final aura = Paint()
      ..color = core.withValues(alpha: opacity * 0.38)
      ..strokeWidth = width * 3.2
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..style = PaintingStyle.stroke
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5);
    final ink = Paint()
      ..color = core.withValues(alpha: opacity)
      ..strokeWidth = width
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..style = PaintingStyle.stroke;
    if (points.length == 1) {
      final offset = Offset(points.first.x, points.first.y);
      canvas.drawCircle(offset, width * 1.8, Paint()
        ..color = core.withValues(alpha: opacity * 0.32)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5));
      canvas.drawCircle(offset, width / 2, Paint()..color = ink.color);
    } else {
      canvas.drawPath(path, aura);
      canvas.drawPath(path, ink);
    }
  }
}
