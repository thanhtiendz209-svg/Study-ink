import 'package:flutter/material.dart';

/// Select a bounded chunk of a possibly long PDF before choosing the file.
class PdfPageRange {
  final int start;
  final int count;
  const PdfPageRange({required this.start, required this.count});
}

Future<PdfPageRange?> choosePdfRange(BuildContext context) async {
  final start = TextEditingController(text: '1');
  final count = TextEditingController(text: '12');
  String? validation;
  final result = await showDialog<PdfPageRange>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (context, refresh) => AlertDialog(
        title: const Text('Chọn trang PDF cần nhập'),
        content: SizedBox(
          width: 360,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('Có thể nhập một phần của PDF dài theo nhiều lượt; '
                'mỗi lượt tối đa 30 trang để tiết kiệm RAM.'),
            const SizedBox(height: 12),
            TextField(
              controller: start,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Bắt đầu từ trang số', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: count,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Số trang nhập (1–30)', border: OutlineInputBorder()),
            ),
            if (validation != null) ...[
              const SizedBox(height: 10),
              Text(validation!, style: TextStyle(color: Theme.of(ctx).colorScheme.error)),
            ],
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Hủy')),
          FilledButton(
            onPressed: () {
              final a = int.tryParse(start.text.trim());
              final b = int.tryParse(count.text.trim());
              if (a == null || a < 1 || b == null || b < 1 || b > 30) {
                refresh(() => validation = 'Trang bắt đầu >= 1; số trang từ 1 đến 30.');
              } else {
                Navigator.pop(ctx, PdfPageRange(start: a, count: b));
              }
            },
            child: const Text('Chọn tệp PDF'),
          ),
        ],
      ),
    ),
  );
  // Do not dispose during the dialog's reverse animation.
  Future<void>.delayed(const Duration(milliseconds: 350), () {
    start.dispose();
    count.dispose();
  });
  return result;
}
