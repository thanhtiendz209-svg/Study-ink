import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../models/notebook.dart';

/// Pure geometry shared by the on-screen editor, PDF export and hit testing.
/// The rear hidden edges of a 3D box use dashed segments independently of the
/// currently selected line pattern.
class StrokeGeometry {
  static Offset at(InkPoint p) => Offset(p.x, p.y);

  static Path pathFor(InkStroke stroke) {
    final points = stroke.points;
    final path = Path();
    if (points.isEmpty) return path;
    final a = at(points.first);
    if (points.length == 1) return path..addOval(Rect.fromCircle(center: a, radius: 0.5));
    final b = at(points.last);
    if (stroke.kind == 'line') {
      return path..moveTo(a.dx, a.dy)..lineTo(b.dx, b.dy);
    }
    if (stroke.kind == 'arrow') {
      final delta = b - a;
      final length = delta.distance;
      if (length < 0.01) return path;
      final unit = delta / length;
      final wing = math.min(26.0, math.max(9.0, length * .18));
      final normal = Offset(-unit.dy, unit.dx);
      final headA = b - unit * wing + normal * wing * .46;
      final headB = b - unit * wing - normal * wing * .46;
      return path..moveTo(a.dx, a.dy)..lineTo(b.dx, b.dy)
        ..moveTo(headA.dx, headA.dy)..lineTo(b.dx, b.dy)
        ..lineTo(headB.dx, headB.dy);
    }
    final r = Rect.fromPoints(a, b);
    if (stroke.kind == 'rectangle') return path..addRect(r);
    if (stroke.kind == 'ellipse') return path..addOval(r);
    if (stroke.kind == 'triangle') {
      if (r.width < 1 || r.height < 1) return path;
      return path..addPolygon([
        Offset(r.center.dx, r.top), r.bottomRight, r.bottomLeft,
      ], true);
    }
    if (stroke.kind == 'parallelogram') {
      if (r.width < 1 || r.height < 1) return path;
      final shift = r.width * .24;
      return path..addPolygon([
        Offset(r.left + shift, r.top), r.topRight,
        Offset(r.right - shift, r.bottom), r.bottomLeft,
      ], true);
    }
    if (stroke.kind == 'hexagon') {
      if (r.width < 1 || r.height < 1) return path;
      final inset = r.width * .25;
      return path..addPolygon([
        Offset(r.left + inset, r.top), Offset(r.right - inset, r.top),
        Offset(r.right, r.center.dy), Offset(r.right - inset, r.bottom),
        Offset(r.left + inset, r.bottom), Offset(r.left, r.center.dy),
      ], true);
    }
    if (stroke.kind == 'cube') return cubePaths(r).$1;
    return path;
  }

  /// Solid visible edges and separate dashed hidden edges of a box in 2D
  /// isometric-ish projection. The user drags over its total bounding rectangle.
  static (Path, Path) cubePaths(Rect r) {
    final solid = Path();
    final hidden = Path();
    if (r.width < 2 || r.height < 2) return (solid, hidden);
    final d = math.min(r.width, r.height) * .25;
    final tl = Offset(r.left, r.top + d);
    final tr = Offset(r.right - d, r.top + d);
    final br = Offset(r.right - d, r.bottom);
    final bl = Offset(r.left, r.bottom);
    final backTl = tl + Offset(d, -d);
    final backTr = tr + Offset(d, -d);
    final backBr = br + Offset(d, -d);
    final backBl = bl + Offset(d, -d);
    // Front rectangle + visible top and right side.
    solid.addRect(Rect.fromPoints(tl, br));
    for (final (a, b) in [(tl, backTl), (tr, backTr),
      (br, backBr), (backTl, backTr), (backTr, backBr)]) {
      solid.moveTo(a.dx, a.dy); solid.lineTo(b.dx, b.dy);
    }
    // Back-left and back-bottom edges are normally occluded.
    for (final (a, b) in [(bl, backBl), (backBl, backTl), (backBl, backBr)]) {
      hidden.moveTo(a.dx, a.dy); hidden.lineTo(b.dx, b.dy);
    }
    return (solid, hidden);
  }

  static Path dashPath(Path source, {required double dash, required double gap}) {
    final output = Path();
    for (final metric in source.computeMetrics()) {
      var dist = 0.0;
      while (dist < metric.length) {
        final to = math.min(dist + dash, metric.length);
        output.addPath(metric.extractPath(dist, to), Offset.zero);
        dist += dash + gap;
      }
    }
    return output;
  }

  static Path patternPath(Path path, StrokePattern style, double width) {
    switch (style) {
      case StrokePattern.solid: return path;
      case StrokePattern.dashed:
        return dashPath(path, dash: math.max(7.0, width * 4), gap: math.max(5.0, width * 2.5));
      case StrokePattern.dotted:
        return dashPath(path, dash: math.max(0.6, width * .35), gap: math.max(3.0, width * 1.8));
    }
  }
}
