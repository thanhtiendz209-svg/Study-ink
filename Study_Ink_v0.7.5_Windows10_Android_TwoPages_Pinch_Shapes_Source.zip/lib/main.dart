import 'package:flutter/material.dart';
import 'screens/library_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const StudyInkApp());
}

class StudyInkApp extends StatelessWidget {
  const StudyInkApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Study Ink',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff5268df)),
          scaffoldBackgroundColor: const Color(0xfff5f7fc),
        ),
        home: const LibraryScreen(),
      );
}
