import 'package:flutter/material.dart';
import '../models/notebook.dart';

/// Geometric lasso selection, independent of gesture and rendering code.
class LassoGeometry {
  static bool pointInside(Offset point, List<Offset> polygon) {
    if (polygon.length < 3) return false;
    var inside = false;
    for (int i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
      final a = polygon[i];
      final b = polygon[j];
      final crosses = (a.dy > point.dy) != (b.dy > point.dy);
      if (crosses && point.dx <
          (b.dx - a.dx) * (point.dy - a.dy) / (b.dy - a.dy) + a.dx) {
        inside = !inside;
      }
    }
    return inside;
  }

  static bool intersectsRect(Rect rect, List<Offset> polygon) {
    if (polygon.length < 3) return false;
    if (pointInside(rect.center, polygon)) return true;
    final rectCorners = [rect.topLeft, rect.topRight, rect.bottomRight, rect.bottomLeft];
    if (rectCorners.any((p) => pointInside(p, polygon))) return true;
    if (polygon.any((p) => rect.contains(p))) return true;
    for (var i = 0; i < 4; i++) {
      for (var j = 0; j < polygon.length; j++) {
        if (_segmentsCross(rectCorners[i], rectCorners[(i + 1) % 4],
            polygon[j], polygon[(j + 1) % polygon.length])) return true;
      }
    }
    return false;
  }

  static bool selectsStroke(InkStroke stroke, List<Offset> polygon) {
    if (polygon.length < 3 || stroke.points.isEmpty) return false;
    // Early filtering with all path vertices; this works for normal handwriting
    // and shapes and avoids expensive segment-vs-polygon tests per sampled point.
    final points = stroke.points.map((p) => Offset(p.x, p.y)).toList();
    if (points.any((p) => pointInside(p, polygon))) return true;
    if (stroke.kind == 'rectangle' || stroke.kind == 'ellipse') {
      return intersectsRect(Rect.fromPoints(points.first, points.last), polygon);
    }
    for (var i = 1; i < points.length; i++) {
      for (var j = 0; j < polygon.length; j++) {
        if (_segmentsCross(points[i - 1], points[i],
            polygon[j], polygon[(j + 1) % polygon.length])) return true;
      }
    }
    return false;
  }

  static bool _segmentsCross(Offset a, Offset b, Offset c, Offset d) {
    double cross(Offset x, Offset y, Offset z) =>
        (y.dx - x.dx) * (z.dy - x.dy) - (y.dy - x.dy) * (z.dx - x.dx);
    final u = cross(a, b, c), v = cross(a, b, d);
    final w = cross(c, d, a), z = cross(c, d, b);
    return ((u > 0 && v < 0) || (u < 0 && v > 0)) &&
        ((w > 0 && z < 0) || (w < 0 && z > 0));
  }
}
