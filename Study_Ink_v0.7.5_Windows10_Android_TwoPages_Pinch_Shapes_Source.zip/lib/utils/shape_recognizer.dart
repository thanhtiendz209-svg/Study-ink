import 'dart:math' as math;

import '../models/notebook.dart';

/// Optional on-pen-up recognition of clearly drawn geometric outlines.
///
/// This is intentionally conservative: a failed recognition leaves the user's
/// original handwriting unchanged. It runs without OCR, network or ML packages.
class ShapeRecognizer {
  const ShapeRecognizer._();

  static InkStroke? recognize(InkStroke stroke) {
    if (!{'pen', 'pencil', 'brush', 'calligraphy'}.contains(stroke.kind)) {
      return null;
    }
    final points = _removeNearDuplicates(stroke.points);
    if (points.length < 6) return null;
    final bounds = _bounds(points);
    final dx = bounds.$3 - bounds.$1;
    final dy = bounds.$4 - bounds.$2;
    final diagonal = math.sqrt(dx * dx + dy * dy);
    final pathLength = _pathLength(points);
    if (diagonal < 42 || pathLength < 65) return null;

    final start = points.first;
    final end = points.last;
    final gap = _distance(start, end);
    final closed = gap <= math.max(19.0, diagonal * 0.13);

    if (!closed) {
      final chord = _distance(start, end);
      if (chord < 45 || pathLength / chord > 1.15) return null;
      final maxError = points.map((p) => _distanceToLine(p, start, end))
          .reduce(math.max);
      if (maxError > math.max(7.0, chord * 0.035)) return null;
      return _converted(stroke, 'line', [start, end]);
    }

    if (points.length < 14 || dx < 35 || dy < 35) return null;
    // A closed scribble that retraces itself is not a polygon or ellipse.
    final (left, top, right, bottom) = bounds;
    final perimeter = 2 * (dx + dy);
    if (pathLength > perimeter * 1.38 || pathLength < perimeter * .55) {
      return null;
    }
    final corners = _closedCorners(points, math.max(7.0, diagonal * .045));
    if (corners.length == 4 && _matchesCorners(corners, [
      InkPoint(left, top), InkPoint(right, top),
      InkPoint(right, bottom), InkPoint(left, bottom),
    ], math.max(13.0, diagonal * .16))) {
      return _converted(stroke, 'rectangle',
        [InkPoint(left, top), InkPoint(right, bottom)]);
    }
    if (corners.length == 3 && _matchesCorners(corners, [
      InkPoint((left + right) / 2, top), InkPoint(right, bottom),
      InkPoint(left, bottom),
    ], math.max(15.0, diagonal * .17))) {
      return _converted(stroke, 'triangle',
        [InkPoint(left, top), InkPoint(right, bottom)]);
    }

    // Normalize a hand-drawn round outline into an ellipse (also circles).
    final cx = (left + right) / 2;
    final cy = (top + bottom) / 2;
    final rx = dx / 2;
    final ry = dy / 2;
    var residual = 0.0;
    var worst = 0.0;
    var quadrants = 0;
    for (final p in points) {
      final nx = (p.x - cx) / rx;
      final ny = (p.y - cy) / ry;
      final error = (math.sqrt(nx * nx + ny * ny) - 1).abs();
      residual += error;
      worst = math.max(worst, error);
      quadrants |= 1 << ((p.x < cx ? 0 : 1) + (p.y < cy ? 0 : 2));
    }
    if (quadrants != 15 || residual / points.length > .15 || worst > .48) {
      return null;
    }
    final ellipsePerimeter = math.pi *
        (3 * (rx + ry) - math.sqrt((3 * rx + ry) * (rx + 3 * ry)));
    if ((pathLength / ellipsePerimeter) < .7 ||
        (pathLength / ellipsePerimeter) > 1.35) return null;
    return _converted(stroke, 'ellipse',
      [InkPoint(left, top), InkPoint(right, bottom)]);
  }

  static InkStroke _converted(InkStroke s, String kind, List<InkPoint> points) =>
      InkStroke(kind: kind, width: s.width, color: s.color,
          pattern: s.pattern, points: points);

  static List<InkPoint> _removeNearDuplicates(List<InkPoint> points) {
    final output = <InkPoint>[];
    for (final p in points) {
      if (output.isEmpty || _distance(output.last, p) >= 1.5) output.add(p);
    }
    return output;
  }

  static (double, double, double, double) _bounds(List<InkPoint> points) {
    var left = points.first.x, right = left;
    var top = points.first.y, bottom = top;
    for (final p in points.skip(1)) {
      left = math.min(left, p.x);
      right = math.max(right, p.x);
      top = math.min(top, p.y);
      bottom = math.max(bottom, p.y);
    }
    return (left, top, right, bottom);
  }

  static double _distance(InkPoint a, InkPoint b) =>
      math.sqrt(math.pow(a.x - b.x, 2) + math.pow(a.y - b.y, 2));

  static double _pathLength(List<InkPoint> points) {
    var total = 0.0;
    for (var i = 1; i < points.length; i++) {
      total += _distance(points[i - 1], points[i]);
    }
    return total;
  }

  static double _distanceToLine(InkPoint p, InkPoint a, InkPoint b) {
    final dx = b.x - a.x, dy = b.y - a.y;
    final length = math.sqrt(dx * dx + dy * dy);
    if (length < 1e-9) return _distance(p, a);
    return ((p.x - a.x) * dy - (p.y - a.y) * dx).abs() / length;
  }

  static List<InkPoint> _simplify(List<InkPoint> points, double epsilon) {
    if (points.length < 3) return points;
    var farthest = -1.0, index = -1;
    final start = points.first, end = points.last;
    for (var i = 1; i < points.length - 1; i++) {
      final dist = _distanceToSegment(points[i], start, end);
      if (dist > farthest) { farthest = dist; index = i; }
    }
    if (farthest <= epsilon || index < 0) return [start, end];
    return [
      ..._simplify(points.sublist(0, index + 1), epsilon).skip(0),
      ..._simplify(points.sublist(index), epsilon).skip(1),
    ];
  }

  static double _distanceToSegment(InkPoint p, InkPoint a, InkPoint b) {
    final dx = b.x - a.x, dy = b.y - a.y;
    final sq = dx * dx + dy * dy;
    if (sq < 1e-9) return _distance(p, a);
    final t = (((p.x - a.x) * dx + (p.y - a.y) * dy) / sq)
        .clamp(0.0, 1.0);
    return _distance(p, InkPoint(a.x + dx * t, a.y + dy * t));
  }

  static List<InkPoint> _closedCorners(List<InkPoint> points, double epsilon) {
    final open = List<InkPoint>.from(points);
    if (_distance(open.first, open.last) < epsilon) open.removeLast();
    if (open.length < 6) return [];
    var split = 1, longest = 0.0;
    for (var i = 1; i < open.length; i++) {
      final d = _distance(open.first, open[i]);
      if (d > longest) { longest = d; split = i; }
    }
    final firstHalf = _simplify(open.sublist(0, split + 1), epsilon);
    final secondHalf = _simplify([
      ...open.skip(split), open.first,
    ], epsilon);
    final vertices = [
      ...firstHalf.take(firstHalf.length - 1),
      ...secondHalf.take(secondHalf.length - 1),
    ];
    // The first sample often falls along an edge instead of on a corner.
    if (vertices.length > 3) {
      final a = vertices.last, b = vertices.first, c = vertices[1];
      if (_distanceToSegment(b, a, c) < epsilon * 1.1) vertices.removeAt(0);
    }
    return vertices;
  }

  static bool _matchesCorners(List<InkPoint> points,
      List<InkPoint> expected, double tolerance) {
    if (points.length != expected.length) return false;
    final used = <int>{};
    for (final target in expected) {
      var nearest = -1, distance = double.infinity;
      for (var i = 0; i < points.length; i++) {
        final d = _distance(points[i], target);
        if (!used.contains(i) && d < distance) {
          nearest = i; distance = d;
        }
      }
      if (nearest < 0 || distance > tolerance) return false;
      used.add(nearest);
    }
    return true;
  }
}
