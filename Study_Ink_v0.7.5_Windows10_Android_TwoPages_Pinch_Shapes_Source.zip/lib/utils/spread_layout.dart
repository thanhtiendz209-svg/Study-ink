/// Pure state helpers for stable 1-based facing-page pairs: 1–2, 3–4, ...
/// All indices here are zero-based. The editor keeps activePage independent
/// from spreadStart so choosing the right page never hides the left page.
class SpreadLayout {
  const SpreadLayout._();

  static int startFor(int activeIndex) => (activeIndex ~/ 2) * 2;

  static List<int> visible(int activeIndex, int pageCount,
      {required bool twoPage}) {
    if (pageCount <= 0) return const [];
    final index = activeIndex.clamp(0, pageCount - 1).toInt();
    if (!twoPage) return [index];
    final first = startFor(index);
    return [for (var i = first; i < first + 2 && i < pageCount; i++) i];
  }
}
