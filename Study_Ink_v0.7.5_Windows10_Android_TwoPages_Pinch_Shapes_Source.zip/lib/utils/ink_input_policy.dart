import 'dart:ui' show PointerDeviceKind;

/// Conservative input filtering, not native hardware-level palm rejection.
/// Stylus-only blocks finger writing while mouse/pan interactions can remain
/// available when disabled. Some cheap capacitive pens report as touch.
class InkInputPolicy {
  final bool stylusOnly;
  const InkInputPolicy({this.stylusOnly = false});

  bool accepts(PointerDeviceKind kind) {
    if (!stylusOnly) return kind != PointerDeviceKind.trackpad;
    return kind == PointerDeviceKind.stylus ||
        kind == PointerDeviceKind.invertedStylus;
  }
}
