import 'package:flutter/material.dart';

/// Pure math for pinch navigation without using a single-finger pan recognizer.
/// The exact paper point beneath [previousFocal] stays beneath [nextFocal].
class TouchNavigation {
  const TouchNavigation._();

  static Matrix4 transform(Matrix4 old, Offset previousFocal,
      Offset nextFocal, double scaleFactor,
      {double minScale = .2, double maxScale = 5}) {
    final current = old.getMaxScaleOnAxis();
    if (!scaleFactor.isFinite || scaleFactor <= 0 ||
        !current.isFinite || current <= 0) return old.clone();
    final scale = (current * scaleFactor).clamp(minScale, maxScale).toDouble();
    final ratio = scale / current;
    final next = Matrix4.identity();
    next.setEntry(0, 0, scale);
    next.setEntry(1, 1, scale);
    next.setEntry(0, 3,
        nextFocal.dx - (previousFocal.dx - old.entry(0, 3)) * ratio);
    next.setEntry(1, 3,
        nextFocal.dy - (previousFocal.dy - old.entry(1, 3)) * ratio);
    return next;
  }
}
