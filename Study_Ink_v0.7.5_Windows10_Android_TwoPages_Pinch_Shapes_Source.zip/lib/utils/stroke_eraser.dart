import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/notebook.dart';
import '../widgets/page_painter.dart';
import '../widgets/stroke_geometry.dart';

/// A geometric (non-destructive-to-neighbours) eraser for ink strokes.
///
/// The circular eraser cuts a stroke into editable surviving fragments. A
/// freehand stroke preserves its pen kind, width, colour and pressure samples.
/// Geometric shapes and patterned strokes are flattened into editable ink
/// fragments only when an eraser actually intersects their visible paths.
class StrokeEraseResult {
  final bool changed;
  final List<InkStroke> strokes;
  const StrokeEraseResult(this.changed, this.strokes);
}

class StrokeEraser {
  const StrokeEraser._();

  static const _epsilon = 1e-7;
  static const _drawingKinds = <String>{
    'pen', 'pencil', 'brush', 'calligraphy', 'marker',
  };

  static double _effectiveWidth(InkStroke stroke) {
    switch (stroke.kind) {
      case 'brush': return stroke.width * 1.8;
      case 'calligraphy': return stroke.width * 1.35;
      default: return stroke.width;
    }
  }

  /// Radius refers to the eraser cursor on the paper, not screen pixels.
  /// Include the ink's width, so no coloured sliver remains along the cut.
  static StrokeEraseResult eraseCircle(
    InkStroke stroke,
    Offset center, {
    required double radius,
  }) {
    if (stroke.points.isEmpty) return StrokeEraseResult(false, [stroke]);
    if (!radius.isFinite || radius <= 0) return StrokeEraseResult(false, [stroke]);
    final inkWidth = _effectiveWidth(stroke);
    final cutRadius = radius + inkWidth * 0.5 + 0.25;
    final bounds = PagePainter.strokeBounds(stroke);
    if (bounds != null && !bounds.inflate(cutRadius + 3).contains(center)) {
      return StrokeEraseResult(false, [stroke]);
    }

    if (_drawingKinds.contains(stroke.kind) &&
        stroke.pattern == StrokePattern.solid) {
      return _cutPolyline(stroke, center, cutRadius);
    }

    // Convert only intersected geometry/dash patterns into ink fragments.
    // Preserve the original shape object exactly if the eraser misses.
    final paths = <({Path path, int color})>[];
    if (_drawingKinds.contains(stroke.kind)) {
      final path = PagePainter.smoothPath(stroke.points);
      paths.add((
        path: StrokeGeometry.patternPath(path, stroke.pattern, inkWidth),
        color: _visibleColor(stroke),
      ));
    } else {
      final path = StrokeGeometry.pathFor(stroke);
      paths.add((
        path: StrokeGeometry.patternPath(path, stroke.pattern, inkWidth),
        color: stroke.color,
      ));
      if (stroke.kind == 'cube' && stroke.points.length >= 2) {
        final rect = Rect.fromPoints(
          StrokeGeometry.at(stroke.points.first),
          StrokeGeometry.at(stroke.points.last),
        );
        final hidden = StrokeGeometry.cubePaths(rect).$2;
        paths.add((
          path: StrokeGeometry.dashPath(hidden,
              dash: math.max(5.0, inkWidth * 2.4),
              gap: math.max(4.0, inkWidth * 2.2)),
          color: Color(stroke.color).withValues(alpha: 0.65).toARGB32(),
        ));
      }
    }

    var changed = false;
    final output = <InkStroke>[];
    for (final rendered in paths) {
      for (final metric in rendered.path.computeMetrics()) {
        if (metric.length <= _epsilon) continue;
        final sampleCount = math.max(1, (metric.length / 1.5).ceil());
        final points = <InkPoint>[];
        for (var i = 0; i <= sampleCount; i++) {
          final tangent = metric.getTangentForOffset(metric.length * i / sampleCount);
          if (tangent == null) continue;
          points.add(InkPoint(tangent.position.dx, tangent.position.dy));
        }
        if (points.length < 2) continue;
        final sampled = InkStroke(
          kind: 'pen',
          color: rendered.color,
          width: inkWidth,
          points: points,
        );
        final result = _cutPolyline(sampled, center, cutRadius);
        changed = changed || result.changed;
        output.addAll(result.strokes);
      }
    }
    return changed ? StrokeEraseResult(true, output) : StrokeEraseResult(false, [stroke]);
  }

  /// Interpolate between successive pointer events so fast swipes do not leave
  /// small untouched gaps. The caller invokes this once per pointer movement.
  static StrokeEraseResult eraseSweep(
    InkStroke stroke,
    Offset from,
    Offset to, {
    required double radius,
  }) {
    if (radius <= 0 || !radius.isFinite) return StrokeEraseResult(false, [stroke]);
    if (stroke.points.isEmpty) return StrokeEraseResult(false, [stroke]);
    final bounds = PagePainter.strokeBounds(stroke);
    if (bounds != null && !bounds.overlaps(
        Rect.fromPoints(from, to).inflate(radius + _effectiveWidth(stroke) + 3))) {
      return StrokeEraseResult(false, [stroke]);
    }
    final distance = (to - from).distance;
    final sampleCount = math.max(1, (distance / math.max(1, radius * 0.5)).ceil());
    var pieces = <InkStroke>[stroke];
    var changed = false;
    for (var i = 0; i <= sampleCount && pieces.isNotEmpty; i++) {
      final p = Offset.lerp(from, to, i / sampleCount)!;
      final updated = <InkStroke>[];
      for (final part in pieces) {
        final result = eraseCircle(part, p, radius: radius);
        changed = changed || result.changed;
        updated.addAll(result.strokes);
      }
      pieces = updated;
    }
    return changed ? StrokeEraseResult(true, pieces) : StrokeEraseResult(false, [stroke]);
  }

  static int _visibleColor(InkStroke stroke) {
    final color = Color(stroke.color);
    if (stroke.kind == 'marker') {
      return color.withValues(alpha: 0.30).toARGB32();
    }
    if (stroke.kind == 'pencil') {
      return color.withValues(alpha: 0.70).toARGB32();
    }
    return stroke.color;
  }

  static StrokeEraseResult _cutPolyline(
    InkStroke original,
    Offset center,
    double cutRadius,
  ) {
    final points = original.points;
    if (points.isEmpty) return StrokeEraseResult(false, [original]);
    if (points.length == 1) {
      final hit = (Offset(points.first.x, points.first.y) - center).distance < cutRadius;
      return hit ? const StrokeEraseResult(true, []) : StrokeEraseResult(false, [original]);
    }
    var changed = false;
    final fragments = <InkStroke>[];
    var current = <InkPoint>[];

    void append(InkPoint p) {
      if (current.isNotEmpty &&
          _distanceSquared(current.last, p) <= _epsilon * _epsilon) return;
      current.add(p);
    }

    void flush() {
      if (current.length >= 2) {
        var length = 0.0;
        for (var i = 1; i < current.length; i++) {
          length += math.sqrt(_distanceSquared(current[i - 1], current[i]));
        }
        if (length > 0.0001) {
          fragments.add(InkStroke(
            kind: original.kind,
            color: original.color,
            width: original.width,
            pattern: original.pattern,
            points: List<InkPoint>.of(current),
          ));
        }
      }
      current = <InkPoint>[];
    }

    for (var i = 1; i < points.length; i++) {
      final a = points[i - 1];
      final b = points[i];
      final dx = b.x - a.x;
      final dy = b.y - a.y;
      final segmentLengthSquared = dx * dx + dy * dy;
      if (segmentLengthSquared <= _epsilon * _epsilon) continue;
      final fx = a.x - center.dx;
      final fy = a.y - center.dy;
      final quadraticB = 2 * (fx * dx + fy * dy);
      final quadraticC = fx * fx + fy * fy - cutRadius * cutRadius;
      final determinant = quadraticB * quadraticB -
          4 * segmentLengthSquared * quadraticC;
      final cuts = <double>[0];
      if (determinant > 0) {
        final root = math.sqrt(determinant);
        final t1 = (-quadraticB - root) / (2 * segmentLengthSquared);
        final t2 = (-quadraticB + root) / (2 * segmentLengthSquared);
        if (t1 > _epsilon && t1 < 1 - _epsilon) cuts.add(t1);
        if (t2 > _epsilon && t2 < 1 - _epsilon) cuts.add(t2);
      }
      cuts.add(1);
      cuts.sort();
      for (var j = 1; j < cuts.length; j++) {
        final start = cuts[j - 1];
        final end = cuts[j];
        if (end - start < _epsilon) continue;
        final middle = (start + end) * 0.5;
        final px = fx + dx * middle;
        final py = fy + dy * middle;
        final inside = px * px + py * py < cutRadius * cutRadius;
        if (inside) {
          changed = true;
          flush();
        } else {
          append(_interpolate(a, b, start));
          append(_interpolate(a, b, end));
        }
      }
    }
    flush();
    return changed ? StrokeEraseResult(true, fragments) : StrokeEraseResult(false, [original]);
  }

  static InkPoint _interpolate(InkPoint a, InkPoint b, double t) => InkPoint(
        a.x + (b.x - a.x) * t,
        a.y + (b.y - a.y) * t,
        a.pressure + (b.pressure - a.pressure) * t,
      );

  static double _distanceSquared(InkPoint a, InkPoint b) {
    final x = a.x - b.x;
    final y = a.y - b.y;
    return x * x + y * y;
  }
}
