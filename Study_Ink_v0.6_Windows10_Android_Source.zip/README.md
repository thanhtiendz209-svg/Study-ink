# Study Ink v0.6 — mã nguồn Flutter cho Windows 10 x64 và Android

**Study Ink** là dự án ứng dụng ghi chú viết tay offline, được phát triển tiếp từ v0.5. **Chỉ hai nền tảng mục tiêu: Windows 10 x64 và Android**. Không yêu cầu hoặc hướng dẫn nâng cấp lên Windows 11. Ứng dụng không sử dụng mã nguồn, logo hay tên thương mại của Scrble Ink.

> **Tình trạng kiểm thử:** đã viết mã nguồn và test cho những thay đổi mới, nhưng môi trường tạo ZIP không có Flutter/Dart SDK. Chưa chạy được `flutter pub get`, `flutter analyze`, `flutter test` hay build EXE/APK. Những tính năng dưới đây được **triển khai trong mã nguồn nhưng chưa được xác minh khi chạy thực tế**.

## Chức năng v0.1–v0.5 tiếp tục giữ

- Tạo nhiều sổ tay; thêm/xóa/nhân bản trang; giấy trắng, kẻ ngang, ô ly và chấm.
- Vẽ bằng chuột, ngón tay, bút cảm ứng; bút, dạ quang, tẩy, màu/cỡ bút, đường thẳng/chữ nhật/ellipse.
- Phóng to, thu nhỏ, khoanh chọn nhiều đối tượng, sao chép/dán nội bộ, Undo/Redo nét vẽ theo từng trang.
- Thêm/chỉnh sửa văn bản, ảnh nổi có thể di chuyển, ảnh làm nền; ghi chú lên PDF đã raster hóa.
- Lưu offline: `study_ink/<id>.json` và ảnh `study_ink/assets/<id>/<sha256>.bin`.
- Xuất PDF hình ảnh (không chỉnh sửa chữ gốc của tài liệu) và nhập bản sao JSON cũ.

## Điểm mới v0.6

### 1. Sao lưu ZIP thực sự

- Menu editor → **Sao lưu ZIP (đề xuất)** → tạo `Tên sổ.studyink.zip`.
- ZIP lưu `meta.json`, `notebook.json`, `media/<SHA-256>.bin` — không nhân 4/3 dung lượng bởi Base64 trong JSON.
- Thư viện → **Nhập bản sao sổ tay** → chọn `.zip` hoặc bản `.json` cũ.
- Kiểm tra đường dẫn, tệp lạ, trùng tên, checksum ZIP, SHA-256 của từng ảnh, và ảnh thiếu; từ chối bản sao hỏng.
- Sổ được nhập có ID mới, không ghi đè sổ hiện có. Ảnh được lưu vào thư mục asset của ID mới.
- Giới hạn thử nghiệm: ZIP 160 MB, tổng dữ liệu giải nén 240 MB, mỗi ảnh 20 MB, JSON nét viết 20 MB, tối đa 512 ảnh. Bản nhập JSON cũ tối đa 85 MB.
- **Tương thích:** v0.6 vẫn xuất được JSON kiểu v0.5 qua menu **Sao lưu JSON cho bản cũ**.

### 2. Bút cảm ứng, chế độ hạn chế chạm nhầm

- Menu editor → bật **Chỉ nhận bút khi viết** để từ chối các sự kiện vẽ từ ngón tay/chuột.
- Bút đảo đầu (`invertedStylus`) vẫn được nhận như đầu bút bình thường; chưa có xóa tự động theo đầu tẩy.
- Đây là **lọc sự kiện đầu vào**, không phải công nghệ palm rejection ở mức phần cứng. Một số bút điện dung rẻ tiền xuất hiện như `touch` và cũng bị chặn; khi đó hãy tắt chế độ.
- Để lại khả năng chọn công cụ **Bàn tay** để di chuyển trang bằng cử chỉ.

### 3. Hoàn tác thao tác với trang

- Sau khi xóa trang, một thanh thông báo có nút **Hoàn tác**.
- Menu editor → **Hoàn tác thêm/xóa trang**, **Làm lại thêm/xóa trang**; hỗ trợ thêm, nhân bản, xóa.
- Lịch sử thay đổi cấu trúc trang giới hạn 30 bước và **tách** khỏi nút Undo/Redo nét viết, tránh xóa dữ liệu ghi chú trong trang khi đổi trang.
- Bản thân lịch sử thao tác chỉ tồn tại trong phiên mở editor, không lưu vào file.

### 4. PDF theo từng trang → asset ngay

- Giữ giới hạn PDF 30 MB, nhập từ 1–30 trang/lượt.
- Thay vì giữ cùng lúc danh sách ảnh đã render dưới dạng Base64, v0.6 kết xuất **từng** trang và ghi trực tiếp vào thư mục ảnh.
- PDF vẫn được đọc vào RAM để mở và văn bản gốc chưa được chỉnh sửa trực tiếp. Chưa có benchmark chứng minh mức giảm RAM cụ thể.

## Build bản chạy thử (trên Windows 10)

Cần Flutter stable có Dart >=3.10, Visual Studio với workload **Desktop development with C++** + Windows SDK, và Android SDK nếu xây dựng APK.

```powershell
flutter doctor
flutter create --project-name study_ink --platforms=windows,android .
flutter pub get
dart run pdfx:install_windows
flutter analyze
flutter test
flutter run -d windows
```

Build phát hành nội bộ:

```powershell
flutter build windows --release
flutter build apk --release
```

**Lưu ý Windows:** phải sao chép trọn bộ thư mục `build/windows/x64/runner/Release/`, không chỉ `.exe`. Android bản release thử nghiệm cần được ký và kiểm tra trên thiết bị trước khi phân phối.

### GitHub Actions

1. Giải nén ZIP mã nguồn v0.6, tải toàn bộ tệp **kể cả `.github/workflows/build.yml`** vào repository riêng.
2. Vào Actions → **Build Study Ink v0.6 (Windows 10 x64 + Android)** → Run workflow.
3. Nếu tất cả bước `flutter analyze`, `flutter test` và build đạt, tải `study-ink-windows10-x64-portable` và `study-ink-android-test-apk` trong phần Artifacts.
4. CI Windows sử dụng Windows Server 2022 để biên dịch; việc kiểm thử trên **máy Windows 10 thực** vẫn bắt buộc. Workflow không tạo bộ cài MSI có chữ ký.

## Kiểm thử bắt buộc trước khi sử dụng ghi chú thật

- Mở sổ tay tạo bằng v0.5, tạo ZIP, chuyển sang Android rồi nhập và kiểm tra mọi trang, chữ/ảnh và nét.
- Thử nhập ZIP không đúng loại, ZIP bị lỗi, ảnh bị hỏng; ứng dụng phải báo lỗi và không ghi đè sổ khác.
- Kiểm tra xóa trang → Hoàn tác → Làm lại, nhất là trang có ảnh PDF.
- Thử bút cảm ứng thật trên Windows 10 và Android; chế độ Chỉ nhận bút cần thử với loại stylus cụ thể.
- Kiểm tra nhập PDF 20–30 trang, xuất PDF và lưu/đóng/mở lại; theo dõi RAM và lỗi treo.

## Giới hạn còn lại

Chưa xác minh biên dịch hoặc tốc độ thực tế. Chưa có OCR, đồng bộ cloud, chỉnh sửa vector/văn bản PDF gốc, dọn asset thừa, clipboard xuyên ứng dụng, hệ thống xử lý palm rejection thực sự hoặc bộ cài thương mại. Không dùng bản này như nơi lưu duy nhất của tài liệu quan trọng; hãy sao lưu đều đặn và kiểm tra mở lại tệp.

Xem [CHANGELOG.md](CHANGELOG.md), [docs/DATA_FORMAT.md](docs/DATA_FORMAT.md), [docs/ROADMAP.md](docs/ROADMAP.md).
