# Study Ink — lịch sử phát triển

## v0.6.0 (mã nguồn, 2026-11-02)

- Thêm `ZipNotebookBackup`, định dạng `.studyink.zip` với JSON và media nhị phân tách biệt, nén ZIP, kiểm tra SHA-256, số lượng/đường dẫn/kích thước thành phần, không giải nén ra đường dẫn tuỳ ý.
- Nhập bản ZIP sang ID sổ tay mới, tiếp tục nhập JSON sao lưu v0.5; lựa chọn xuất JSON kiểu cũ trong menu.
- Thêm `PageStructureHistory` cho hoàn tác/làm lại khi tạo, nhân bản, xóa trang; thông báo hoàn tác ngay sau xóa.
- Thêm `InkInputPolicy` với chế độ **chỉ nhận bút khi viết**, lọc touch/mouse.
- Nhập PDF từng trang và ghi trực tiếp vào asset theo SHA-256, tránh duy trì cùng lúc danh sách Base64 ảnh đã raster hóa.
- Unit test cho ZIP, kiểm tra tệp lạ/ảnh thiếu/ảnh hỏng, hoàn tác trang và lọc đầu vào.
- Giữ mục tiêu: Windows 10 64-bit + Android; mã nguồn chưa được Flutter SDK kiểm thử tại môi trường tạo.

## v0.5.0

- Media tách khỏi JSON autosave, bản sao JSON portable, clipboard nội bộ, Undo/Redo theo trang.

## v0.4.0

- Làm mượt đường vẽ, lớp preview, chỉ mục sổ tay, nhập PDF theo khoảng trang.

## v0.3.0

- Văn bản/hình ảnh độc lập, khoanh chọn, Undo/Redo nội dung.

## v0.2.0

- Nền PDF/ảnh và công cụ chọn, nhân bản trang.

## v0.1.0

- Giao diện và nét vẽ, mẫu giấy, lưu offline, xuất PDF.
