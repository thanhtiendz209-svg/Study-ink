# Study Ink — Roadmap Windows 10 x64 + Android

## v0.1 (source)
- Ink handwriting, basic shapes, notebook pages, local save and PDF export.

## v0.2 (source)
- PDF/image raster backgrounds, individual stroke select/move, duplicate page.

## v0.3 (source)
- Lasso selection of multiple handwriting strokes.
- Editable typed-text overlays with size and color.
- Repositionable, resizable PNG/JPEG image overlays.
- Multi-stroke/group movement and individual element resize handle.
- Full-page Undo/Redo snapshots for ink/overlays/paper/background.
- Portable notebook schema v3 with v1/v2 read compatibility.
- CI/test additions; compilation and real runtime validation still required.

## v0.4 (source implemented, runtime verification pending)
- Improved single-path rendering for smooth uniform-pressure handwriting.
- Split committed background/ink layer from interactive ink/selection overlay.
- Select/move/duplicate/delete multiple image and text overlays within lasso.
- Lightweight `.meta` library summaries; old notebooks rebuilt on first scan.
- JSON serialization on an isolate; sequential PDF page-chunk importing (up to 30 pages/30 MB each).
- Unit tests for metadata, drawPath geometry, selection, and import-window guard.
- Cross-version JSON format remains v3 (no backup migration required).

## v0.5 (source implemented, CI/device validation pending)
- Asset binary riêng theo sổ tay, khóa SHA-256, đồng bộ schema v4.
- Tự chuyển định dạng ảnh Base64 từ sổ v0.1–v0.4 khi mở; không xóa dữ liệu cũ trước khi ghi được bản mới.
- Bộ sao lưu portable JSON có nhúng media, kiểm tra từ chối bản chỉ có tham chiếu ảnh cục bộ.
- Copy/Paste nội bộ cho nhóm nét/chữ/ảnh giữa các trang (không phải clipboard Windows/Android).
- Giữ Undo/Redo trong từng trang khi chuyển trang; giới hạn 40 mốc/trang.
- Kiểm thử codec, media, khoanh chọn, copy/paste — chưa chạy được tests trong môi trường soạn mã.

## v0.6 (source implemented, CI/device validation pending)
- Sao lưu/khôi phục ZIP gồm JSON và ảnh nhị phân, kiểm tra mã băm và giới hạn dữ liệu.
- Lọc đầu vào `stylus-only` nhằm giảm chạm nhầm; chưa phải palm rejection phần cứng.
- Undo/Redo các thao tác thêm, xóa, nhân bản trang (riêng với Undo nét viết).
- Nhập PDF render từng trang rồi ghi trực tiếp media; hạn chế RAM nhưng chưa benchmark.
- Bổ sung tests, workflow build cho Windows 10 x64 + Android; cần chạy Flutter trên CI và thiết bị thật.

## v0.7 (planned)
- Thực thi Flutter analyze/test, sửa lỗi thực tế từ CI và kiểm tra Windows 10/Android.
- Tối ưu PDF lớn hơn bằng chọn trang và giảm bộ nhớ giải mã.
- Dọn media thừa an toàn sau khi tính cả `.bak` và phiên bản ghi chú đã lưu.
- Cải thiện bút cảm ứng (độ trễ, áp lực, xóa bằng đầu bút khi hệ thống hỗ trợ).
- Gói cài đặt thử nghiệm, sao lưu/khôi phục có thanh tiến trình và tự kiểm tra.

## Long-term (planned)
- Multi-notebook full-text index, optional handwriting recognition, robust import/export, accessibility and privacy review, optional opt-in sync.

No Windows 11-specific work is required or planned. Flutter may run on Windows 11, but the target Windows OS for testing remains Windows 10 x64.
