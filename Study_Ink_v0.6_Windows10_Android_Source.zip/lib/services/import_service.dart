import 'dart:convert';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:pdfx/pdfx.dart';

import '../models/notebook.dart';
import 'notebook_asset_store.dart';

/// Offline raster import for Windows 10 and Android. PDF pages are rendered
/// sequentially, not decoded into one giant in-memory image collection.
class ImportService {
  static const maxPdfBytes = 30 * 1024 * 1024;
  static const maxImageBytes = 12 * 1024 * 1024;
  static const maxPagesPerImport = 30;

  static Future<Uint8List?> _pickPdfBytes() async {
    final selected = await FilePicker.pickFile(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );
    if (selected == null) return null;
    final reportedSize = selected.lengthSync();
    if (reportedSize != null && reportedSize > maxPdfBytes) {
      throw const FormatException('PDF vượt giới hạn 30 MB');
    }
    final bytes = await selected.readAsBytes();
    if (bytes.length > maxPdfBytes) {
      throw const FormatException('PDF vượt giới hạn 30 MB');
    }
    return bytes;
  }

  /// Compatibility API for older callers. The v0.6 UI uses the asset-backed
  /// overload below to avoid materializing all rendered pages as Base64.
  static Future<List<NotePage>?> pickPdfPages({
    int startPage = 1,
    int pageCount = 12,
  }) async {
    final bytes = await _pickPdfBytes();
    if (bytes == null) return null;
    return rasterizePdf(bytes, startPage: startPage, pageCount: pageCount);
  }

  static Future<List<NotePage>?> pickPdfPagesToAssets({
    required String bookId,
    required NotebookAssetStore assetStore,
    int startPage = 1,
    int pageCount = 12,
  }) async {
    final bytes = await _pickPdfBytes();
    if (bytes == null) return null;
    return rasterizePdfToAssets(
      bytes, bookId: bookId, assetStore: assetStore,
      startPage: startPage, pageCount: pageCount,
    );
  }

  static Future<List<NotePage>> rasterizePdf(
    Uint8List bytes, {int startPage = 1, int pageCount = 12,
  }) async => _rasterize(
    bytes, startPage: startPage, pageCount: pageCount,
    makePage: (index, image) async => NotePage(
      id: '${DateTime.now().microsecondsSinceEpoch}_pdf_$index',
      pattern: PaperPattern.blank,
      backgroundImageBase64: base64Encode(image),
    ),
  );

  /// Stream individual page renders directly to SHA-addressed files. This
  /// avoids collecting JPEG or Base64 for 30 pages before flushing to disk.
  static Future<List<NotePage>> rasterizePdfToAssets(
    Uint8List bytes, {
    required String bookId,
    required NotebookAssetStore assetStore,
    int startPage = 1,
    int pageCount = 12,
  }) async => _rasterize(
    bytes, startPage: startPage, pageCount: pageCount,
    makePage: (index, image) async => NotePage(
      id: '${DateTime.now().microsecondsSinceEpoch}_pdf_$index',
      pattern: PaperPattern.blank,
      backgroundAssetId: await assetStore.put(bookId, image),
    ),
  );

  static Future<List<NotePage>> _rasterize(
    Uint8List bytes, {
    required int startPage,
    required int pageCount,
    required Future<NotePage> Function(int pageNumber, Uint8List imageBytes)
        makePage,
  }) async {
    if (startPage < 1 || pageCount < 1 || pageCount > maxPagesPerImport) {
      throw const FormatException('Mỗi lượt nhập từ 1 đến 30 trang, bắt đầu từ trang 1');
    }
    if (bytes.isEmpty || bytes.length > maxPdfBytes) {
      throw const FormatException('PDF vượt giới hạn 30 MB');
    }
    final document = await PdfDocument.openData(bytes);
    final pages = <NotePage>[];
    try {
      if (startPage > document.pagesCount) {
        throw FormatException('PDF chỉ có ${document.pagesCount} trang');
      }
      final endPage = (startPage + pageCount - 1).clamp(1, document.pagesCount);
      for (var index = startPage; index <= endPage; index++) {
        final pdfPage = await document.getPage(index);
        try {
          final ratio = pdfPage.width / pdfPage.height;
          final renderWidth = ratio > 1
              ? 960.0 : (960.0 * ratio).clamp(1.0, 960.0).toDouble();
          final renderHeight = ratio > 1
              ? (960.0 / ratio).clamp(1.0, 1400.0).toDouble() : 960.0;
          final rendered = await pdfPage.render(
            width: renderWidth,
            height: renderHeight,
            format: PdfPageImageFormat.jpeg,
            quality: 78,
            backgroundColor: '#ffffff',
          );
          if (rendered == null || rendered.bytes.isEmpty) {
            throw StateError('Không thể chuyển trang $index của PDF');
          }
          pages.add(await makePage(index, rendered.bytes));
          // Each JPEG can be garbage collected before the next PDF page.
        } finally {
          await pdfPage.close();
        }
      }
    } finally {
      await document.close();
    }
    return pages;
  }

  static Future<String?> pickImageBackground() async {
    final selected = await FilePicker.pickFile(
      type: FileType.custom,
      allowedExtensions: ['png', 'jpg', 'jpeg'],
    );
    if (selected == null) return null;
    final reportedSize = selected.lengthSync();
    if (reportedSize != null && reportedSize > maxImageBytes) {
      throw const FormatException('Ảnh vượt giới hạn 12 MB');
    }
    final bytes = await selected.readAsBytes();
    if (bytes.length > maxImageBytes) {
      throw const FormatException('Ảnh vượt giới hạn 12 MB');
    }
    if (!_looksLikeImage(bytes)) {
      throw const FormatException('Tệp không phải PNG hoặc JPEG hợp lệ');
    }
    return base64Encode(bytes);
  }

  static bool _looksLikeImage(Uint8List bytes) {
    if (bytes.length < 8) return false;
    final png = bytes[0] == 137 && bytes[1] == 80 && bytes[2] == 78 &&
        bytes[3] == 71 && bytes[4] == 13 && bytes[5] == 10;
    final jpg = bytes[0] == 0xff && bytes[1] == 0xd8 && bytes[2] == 0xff;
    return png || jpg;
  }
}
