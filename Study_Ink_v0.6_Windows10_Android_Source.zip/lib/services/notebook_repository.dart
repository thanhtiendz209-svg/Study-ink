import 'dart:io';
import 'dart:convert';
import 'dart:typed_data';

import 'package:path_provider/path_provider.dart';
import 'package:flutter/foundation.dart';
import '../models/notebook.dart';
import '../models/notebook_summary.dart';
import 'notebook_asset_store.dart';

/// Serialize large notebook snapshots off the UI isolate.
String _encodeNotebookSnapshot(Map<String, dynamic> snapshot) => jsonEncode(snapshot);

/// One JSON file per notebook with an atomic backup and tiny metadata index.
class NotebookRepository {
  static final Map<String, Future<void>> _saveQueue = {};
  final NotebookAssetStore assets = NotebookAssetStore();

  /// Used by image/PDF import to immediately release Base64 buffers.
  Future<void> externalizeMedia(Notebook book) => assets.externalize(book);

  Future<Uint8List> readMedia(String bookId, String assetId) => assets.read(bookId, assetId);
  Future<Directory> _folder() async {
    final root = await getApplicationDocumentsDirectory();
    final dir = Directory('${root.path}${Platform.pathSeparator}study_ink');
    await dir.create(recursive: true);
    return dir;
  }

  Future<File> _file(String id) async {
    // Khong tin tuong id doc tu file nhap; khong cho path traversal.
    if (!RegExp(r'^[a-zA-Z0-9_-]+$').hasMatch(id)) {
      throw const FormatException('Mã sổ tay không hợp lệ');
    }
    final dir = await _folder();
    return File('${dir.path}${Platform.pathSeparator}$id.json');
  }

  Future<void> save(Notebook book) {
    // Lay snapshot ngay bay gio va ghi noi tiep, tranh hai lan autosave ghi chen.
    final id = book.id;
    // Capture the immutable serializable snapshot at the call site. Computing
    // the JSON in an isolate avoids long UI pauses for image-rich notebooks.
    final snapshot = book.toJson();
    final last = _saveQueue[id] ?? Future<void>.value();
    final summary = NotebookSummary(
      id: id, title: book.title, updatedAt: book.updatedAt,
      pageCount: book.pages.length,
    );
    final next = last.catchError((Object _) {}).then((_) async {
      // Work on the captured snapshot: subsequent UI mutations cannot change
      // the data being committed. Assets are written *before* JSON references.
      final captured = Notebook.fromJson(snapshot);
      await assets.externalize(captured);
      final encoded = await compute(_encodeNotebookSnapshot, captured.toJson());
      await _write(id, encoded, summary);
    });
    _saveQueue[id] = next;
    return next;
  }

  Future<void> _write(String id, String encoded, NotebookSummary summary) async {
    final file = await _file(id);
    final temp = File('${file.path}.tmp');
    final backup = File('${file.path}.bak');
    await temp.writeAsString(encoded, flush: true);
    if (await file.exists()) {
      if (await backup.exists()) await backup.delete();
      await file.rename(backup.path);
    }
    try {
      await temp.rename(file.path);
    } catch (_) {
      if (await backup.exists() && !await file.exists()) {
        await backup.rename(file.path);
      }
      rethrow;
    }
    // A sidecar index avoids decoding every embedded PDF and image in the library.
    // The main notebook was committed first; a failed index update is recoverable.
    await _writeIndex(file, summary);
  }

  Future<void> _writeIndex(File notebookFile, NotebookSummary summary) async {
    final index = File('${notebookFile.path}.meta');
    final temporary = File('${index.path}.tmp');
    await temporary.writeAsString(jsonEncode(summary.toJson()), flush: true);
    if (await index.exists()) await index.delete();
    await temporary.rename(index.path);
  }

  Future<Notebook> read(String id) async {
    final file = await _file(id);
    final backup = File('${file.path}.bak');
    Notebook book;
    try {
      book = Notebook.decode(await file.readAsString());
    } catch (_) {
      if (!await backup.exists()) rethrow;
      book = Notebook.decode(await backup.readAsString());
    }
    if (book.id != id) throw const FormatException('ID trong sổ tay không khớp tên tệp');
    if (NotebookAssetStore.containsInlineMedia(book)) {
      // Keep a read-only fallback so a full disk cannot prevent an old notebook
      // opening. The original file is not replaced until migration commits.
      final fallback = Notebook.fromJson(book.toJson());
      try {
        await assets.externalize(book);
        await save(book);
      } catch (_) {
        return fallback;
      }
    }
    return book;
  }

  Future<List<NotebookSummary>> list() async {
    final dir = await _folder();
    final results = <NotebookSummary>[];
    final ids = <String>{};
    await for (final entry in dir.list()) {
      if (entry is! File) continue;
      final name = entry.uri.pathSegments.last;
      if (name.endsWith('.json')) {
        ids.add(name.substring(0, name.length - 5));
      } else if (name.endsWith('.json.bak')) {
        ids.add(name.substring(0, name.length - 9));
      }
    }
    for (final id in ids) {
      try {
        final file = await _file(id);
        final meta = File('${file.path}.meta');
        if (await meta.exists()) {
          final summary = NotebookSummary.fromJson(
            Map<String, dynamic>.from(jsonDecode(await meta.readAsString()) as Map),
          );
          if (summary.id == id) {
            results.add(summary);
            continue;
          }
        }
      } catch (_) {
        // A missing/corrupt sidecar can be regenerated from the original file.
      }
      try {
        // One-time migration for v0.1-v0.3 and invalid metadata.
        final book = await read(id);
        final summary = NotebookSummary(
          id: book.id, title: book.title, updatedAt: book.updatedAt,
          pageCount: book.pages.length,
        );
        results.add(summary);
        final file = await _file(id);
        await _writeIndex(file, summary);
      } catch (_) {
        // Preserve unreadable files for recovery; never delete user data.
      }
    }
    results.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return results;
  }

  Future<void> delete(String id) async {
    // Cho lan luu cuoi ket thuc truoc khi xoa, tranh so tay tu xuat hien lai.
    try {
      await (_saveQueue[id] ?? Future<void>.value());
    } catch (_) {}
    final file = await _file(id);
    for (final suffix in ['', '.bak', '.tmp', '.meta', '.meta.tmp']) {
      final candidate = File('${file.path}$suffix');
      if (await candidate.exists()) await candidate.delete();
    }
    await assets.deleteBookAssets(id);
    _saveQueue.remove(id);
  }
}
