import 'dart:convert';

import '../models/notebook.dart';
import 'notebook_asset_store.dart';

/// Portable JSON backup: unlike autosave JSON, this contains all media bytes.
/// It is intentionally independent of the OS file picker and can be tested.
class PortableBackup {
  static Future<String> encode(Notebook book, NotebookAssetStore assets) async {
    final snapshot = book.toJson();
    final pages = (snapshot['pages'] as List).cast<Map<String, dynamic>>();
    for (final page in pages) {
      final id = page.remove('backgroundAssetId') as String?;
      if (id != null && page['backgroundImageBase64'] == null) {
        page['backgroundImageBase64'] = base64Encode(await assets.read(book.id, id));
      }
      for (final item in (page['elements'] as List).cast<Map<String, dynamic>>()) {
        final imageId = item.remove('imageAssetId') as String?;
        if (imageId != null && item['imageBase64'] == null) {
          item['imageBase64'] = base64Encode(await assets.read(book.id, imageId));
        }
      }
    }
    return jsonEncode(snapshot);
  }

  static Notebook decode(String source) {
    final result = Notebook.decode(source);
    for (final page in result.pages) {
      if (page.backgroundAssetId != null && page.backgroundImageBase64 == null) {
        throw const FormatException('Bản sao lưu thiếu ảnh nền');
      }
      for (final item in page.elements) {
        if (item.imageAssetId != null && item.imageBase64 == null) {
          throw const FormatException('Bản sao lưu thiếu ảnh chèn');
        }
      }
    }
    return result;
  }
}
