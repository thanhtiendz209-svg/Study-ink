import 'dart:async';
import 'dart:convert';
import 'dart:ui' as ui;
import 'dart:ui' show PointerDeviceKind;

import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';

import '../models/notebook.dart';
import '../models/selection_clipboard.dart';
import '../models/page_structure_history.dart';
import '../services/export_service.dart';
import '../services/import_service.dart';
import '../services/notebook_repository.dart';
import '../widgets/page_painter.dart';
import '../widgets/pdf_range_dialog.dart';
import '../utils/lasso_geometry.dart';
import '../utils/ink_input_policy.dart';

class EditorScreen extends StatefulWidget {
  final Notebook book;
  const EditorScreen({super.key, required this.book});

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen>
    with WidgetsBindingObserver {
  final _repo = NotebookRepository();
  final _transform = TransformationController();
  // Deep-copied page snapshots keep ink, text, images, backgrounds together.
  // Retain up to 40 snapshots on each page independently, even after switching.
  final _undoByPage = <String, List<NotePage>>{};
  final _redoByPage = <String, List<NotePage>>{};
  List<NotePage> get _undo => _undoByPage.putIfAbsent(_page.id, () => <NotePage>[]);
  List<NotePage> get _redo => _redoByPage.putIfAbsent(_page.id, () => <NotePage>[]);
  SelectionClipboard? _clipboard;
  final _pageHistory = PageStructureHistory();
  bool _stylusOnly = false;
  final _colors = const [
    Color(0xff172b4d), Color(0xff2563eb), Color(0xffdf3e4d),
    Color(0xff138a6b), Color(0xff7c3aed), Color(0xffec8b27),
  ];

  late Notebook _book;
  int _pageIndex = 0;
  DrawingTool _tool = DrawingTool.pen;
  Color _color = const Color(0xff172b4d);
  double _size = 3.0;
  InkStroke? _active;
  int? _activePointer;
  bool _erasedThisGesture = false;
  Timer? _saveTimer;
  bool _saving = false;
  Size? _viewportSize;
  ui.Image? _pageBackground;
  int _backgroundRequest = 0;
  final Set<int> _selectedStrokes = <int>{};
  final Set<int> _selectedElements = <int>{};
  int _contentRevision = 0;
  final List<Offset> _lassoPath = [];
  final Map<int, InkStroke> _originalSelectedStrokes = {};
  final Map<int, PageElement> _originalSelectedElements = {};
  Offset? _selectionStart;
  bool _selectionMoved = false;
  bool _resizeSelection = false;
  bool _importing = false;
  Map<String, ui.Image> _elementImages = {};
  int _idSequence = 0;

  String _nextId() => '${DateTime.now().microsecondsSinceEpoch}_${_idSequence++}';

  bool get _hasSelection => _selectedStrokes.isNotEmpty || _selectedElements.isNotEmpty;
  int? get _singleElementIndex => _selectedElements.length == 1
      ? _selectedElements.first : null;

  void _clearSelection() {
    _selectedStrokes.clear();
    _selectedElements.clear();
    _lassoPath.clear();
    _originalSelectedStrokes.clear();
    _originalSelectedElements.clear();
    _selectionStart = null;
    _selectionMoved = false;
    _resizeSelection = false;
  }

  void _selectAllOnPage() {
    setState(() {
      _clearSelection();
      _selectedStrokes.addAll(List<int>.generate(_page.strokes.length, (i) => i));
      _selectedElements.addAll(List<int>.generate(_page.elements.length, (i) => i));
      _tool = DrawingTool.select;
    });
  }

  NotePage get _page => _book.pages[_pageIndex];

  void _copySelection() {
    if (!_hasSelection) return;
    _clipboard = SelectionClipboard.capture(_page, _selectedStrokes, _selectedElements);
    _notify('Đã sao chép các đối tượng, có thể dán sang trang khác');
    setState(() {});
  }

  void _pasteSelection() {
    if (_clipboard == null || _clipboard!.isEmpty) return;
    _captureHistory();
    setState(() {
      _clearSelection();
      final result = _clipboard!.pasteInto(_page, _nextId);
      _selectedStrokes.addAll(result.strokes);
      _selectedElements.addAll(result.elements);
      _tool = DrawingTool.select;
      _contentRevision++;
    });
    _loadPageBackground();
    _queueSave();
  }

  @override
  void initState() {
    super.initState();
    _book = widget.book;
    WidgetsBinding.instance.addObserver(this);
    _loadPageBackground();
  }

  @override
  void dispose() {
    _saveTimer?.cancel();
    // Luu tat ca thay doi chua ghi truoc khi dong trang.
    unawaited(_flushSave());
    WidgetsBinding.instance.removeObserver(this);
    _transform.dispose();
    _pageBackground?.dispose();
    for (final image in _elementImages.values) { image.dispose(); }
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused || state == AppLifecycleState.inactive) {
      _flushSave();
    }
  }

  Future<ui.Image> _decodeImage(String? encoded, String? assetId,
      {int? targetWidth}) async {
    if (encoded == null && assetId == null) {
      throw const FormatException('Thiếu dữ liệu ảnh');
    }
    final bytes = encoded != null
        ? base64Decode(encoded)
        : await _repo.readMedia(_book.id, assetId!);
    final codec = await ui.instantiateImageCodec(bytes,
      targetWidth: targetWidth);
    try {
      final frame = await codec.getNextFrame();
      return frame.image;
    } finally {
      codec.dispose();
    }
  }

  Future<void> _loadPageBackground() async {
    final request = ++_backgroundRequest;
    final page = _page;
    ui.Image? nextBackground;
    final images = <String, ui.Image>{};
    try {
      if (page.backgroundImageBase64 != null || page.backgroundAssetId != null) {
        nextBackground = await _decodeImage(page.backgroundImageBase64,
          page.backgroundAssetId, targetWidth: 900);
      }
      for (final element in page.elements) {
        if (element.type == 'image' &&
            (element.imageBase64 != null || element.imageAssetId != null)) {
          images[element.id] = await _decodeImage(element.imageBase64,
            element.imageAssetId, targetWidth: 800);
        }
      }
      if (!mounted || request != _backgroundRequest) return;
      final oldBackground = _pageBackground;
      final oldImages = _elementImages;
      setState(() {
        _pageBackground = nextBackground;
        _elementImages = Map<String, ui.Image>.of(images);
      });
      oldBackground?.dispose();
      for (final image in oldImages.values) { image.dispose(); }
      nextBackground = null;
      images.clear();
    } catch (error) {
      if (mounted && request == _backgroundRequest) _notifyError(error);
    } finally {
      nextBackground?.dispose();
      for (final image in images.values) { image.dispose(); }
    }
  }

  Future<void> _importPdfPages() async {
    if (_importing) return;
    final range = await choosePdfRange(context);
    if (range == null || !mounted) return;
    setState(() => _importing = true);
    try {
      final pages = await ImportService.pickPdfPagesToAssets(
        bookId: _book.id, assetStore: _repo.assets,
        startPage: range.start, pageCount: range.count);
      if (pages == null || pages.isEmpty || !mounted) return;
      setState(() {
        for (final page in pages) {
          _pageHistory.recordInsert(page, _book.pages.length);
          _book.pages.add(page);
        }
        _contentRevision++;
        _pageIndex = _book.pages.length - pages.length;
        _undo.clear();
        _redo.clear();
        _clearSelection();
      });
      await _loadPageBackground();
      _queueSave();
      _notify('Đã thêm ${pages.length} trang PDF để ghi chú');
    } catch (error) {
      _notifyError(error);
    } finally {
      if (mounted) setState(() => _importing = false);
    }
  }

  Future<void> _importImageBackground() async {
    try {
      final image = await ImportService.pickImageBackground();
      if (image == null || !mounted) return;
      if (_page.backgroundImageBase64 != null) {
        final confirm = await showDialog<bool>(context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Thay ảnh nền?'),
            content: const Text('Ảnh nền hiện tại sẽ được thay, các nét vẽ vẫn giữ nguyên.'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Hủy')),
              FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Thay ảnh')),
            ],
          ),
        );
        if (confirm != true || !mounted) return;
      }
      final assetBook = Notebook(id: _book.id, title: _book.title,
          updatedAt: _book.updatedAt, pages: [NotePage(id: _page.id,
            backgroundImageBase64: image)]);
      await _repo.externalizeMedia(assetBook);
      if (!mounted) return;
      _captureHistory();
      setState(() {
        _page.backgroundImageBase64 = null;
        _page.backgroundAssetId = assetBook.pages.first.backgroundAssetId;
        _page.pattern = PaperPattern.blank;
        _contentRevision++;
      });
      await _loadPageBackground();
      _queueSave();
      _notify('Đã chèn ảnh làm nền trang');
    } catch (error) {
      _notifyError(error);
    }
  }

  void _notify(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  void _duplicatePage() {
    final copy = _page.duplicate(
      '${DateTime.now().microsecondsSinceEpoch}_copy',
    );
    setState(() {
      _pageHistory.recordInsert(copy, _pageIndex + 1);
      _book.pages.insert(_pageIndex + 1, copy);
      _pageIndex++;
      _undo.clear();
      _redo.clear();
      _clearSelection();
    });
    _loadPageBackground();
    _queueSave();
  }

  void _deleteSelection() {
    if (!_hasSelection) return;
    _captureHistory();
    setState(() {
      final indices = _selectedStrokes.toList()..sort((a, b) => b.compareTo(a));
      for (final index in indices) {
        if (index >= 0 && index < _page.strokes.length) _page.strokes.removeAt(index);
      }
      final elements = _selectedElements.toList()..sort((a, b) => b.compareTo(a));
      for (final element in elements) {
        if (element >= 0 && element < _page.elements.length) {
          _page.elements.removeAt(element);
        }
      }
      _clearSelection();
      _contentRevision++;
    });
    _loadPageBackground();
    _queueSave();
  }

  void _duplicateSelection() {
    if (!_hasSelection) return;
    _captureHistory();
    setState(() {
      final previousStrokes = _selectedStrokes.toList()..sort();
      final previousElements = _selectedElements.toList()..sort();
      _clearSelection();
      for (final index in previousStrokes) {
        if (index < 0 || index >= _page.strokes.length) continue;
        _page.strokes.add(_page.strokes[index].translated(24, 24));
        _selectedStrokes.add(_page.strokes.length - 1);
      }
      for (final index in previousElements) {
        if (index < 0 || index >= _page.elements.length) continue;
        _page.elements.add(_page.elements[index]
            .translated(24, 24).copyWith(id: _nextId()));
        _selectedElements.add(_page.elements.length - 1);
      }
      _contentRevision++;
    });
    _loadPageBackground();
    _queueSave();
  }

  Future<void> _insertOverlayImage() async {
    try {
      final base64Image = await ImportService.pickImageBackground();
      if (base64Image == null || !mounted) return;
      final decoded = await _decodeImage(base64Image, null, targetWidth: 800);
      final ratio = decoded.width / decoded.height;
      decoded.dispose();
      const width = 430.0;
      final height = (width / ratio).clamp(80.0, 650.0).toDouble();
      final imageBook = Notebook(id: _book.id, title: _book.title,
        updatedAt: _book.updatedAt, pages: [NotePage(id: _page.id, elements: [
          PageElement(id: _nextId(), type: 'image', x: 150, y: 150,
            width: width, height: height, imageBase64: base64Image),
        ])]);
      await _repo.externalizeMedia(imageBook);
      if (!mounted) return;
      _captureHistory();
      setState(() {
        _page.elements.add(imageBook.pages.first.elements.first);
        _clearSelection();
        _selectedElements.add(_page.elements.length - 1);
        _tool = DrawingTool.select;
        _contentRevision++;
      });
      await _loadPageBackground();
      _queueSave();
      _notify('Đã chèn ảnh: dùng công cụ Chọn để kéo hoặc thay đổi kích thước');
    } catch (error) { _notifyError(error); }
  }

  Future<void> _textDialog({Offset? at, int? editIndex}) async {
    final pageWhenOpened = _page;
    final current = editIndex == null ? null : _page.elements[editIndex];
    final controller = TextEditingController(text: current?.text ?? '');
    double fontSize = current?.fontSize ?? 30;
    if (![18.0, 24.0, 30.0, 36.0, 48.0, 60.0].contains(fontSize)) {
      fontSize = 30;
    }
    final value = await showDialog<(String, double)>(
      context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, update) => AlertDialog(
        title: Text(current == null ? 'Chèn văn bản' : 'Sửa văn bản'),
        content: SizedBox(width: 390, child: Column(
          mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(controller: controller, autofocus: true, maxLines: 4,
              maxLength: 2000,
              decoration: const InputDecoration(labelText: 'Nội dung',
                border: OutlineInputBorder())),
            const SizedBox(height: 10),
            Row(children: [
              const Text('Cỡ chữ: '),
              DropdownButton<double>(value: fontSize,
                items: [18.0, 24.0, 30.0, 36.0, 48.0, 60.0].map((n) =>
                  DropdownMenuItem(value: n, child: Text('${n.toInt()} px'))).toList(),
                onChanged: (size) { if (size != null) update(() => fontSize = size); }),
            ]),
          ],
        )),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(ctx,
            (controller.text.trim(), fontSize)), child: const Text('Lưu')),
        ],
      )),
    );
    Future<void>.delayed(const Duration(milliseconds: 350), controller.dispose);
    if (!mounted || value == null || value.$1.isEmpty ||
        !identical(pageWhenOpened, _page)) return;
    _captureHistory();
    setState(() {
      if (editIndex != null && editIndex < _page.elements.length) {
        _page.elements[editIndex]
          ..text = value.$1
          ..fontSize = value.$2;
        _clearSelection();
        _selectedElements.add(editIndex);
      } else {
        _page.elements.add(PageElement(
          id: _nextId(), type: 'text',
          x: (at?.dx ?? 160).clamp(0, paperWidth - 400).toDouble(),
          y: (at?.dy ?? 200).clamp(0, paperHeight - 140).toDouble(),
          width: 400, height: 140, text: value.$1,
          fontSize: value.$2, color: _color.toARGB32(),
        ));
        _clearSelection();
        _selectedElements.add(_page.elements.length - 1);
      }
      _tool = DrawingTool.select;
      _contentRevision++;
    });
    _queueSave();
  }

  void _editSelectedText() {
    final index = _singleElementIndex;
    if (index != null && index < _page.elements.length &&
        _page.elements[index].type == 'text') {
      _textDialog(editIndex: index);
    }
  }

  Future<void> _flushSave() async {
    _saveTimer?.cancel();
    _book.updatedAt = DateTime.now();
    try {
      await _repo.save(_book);
    } catch (error) {
      _notifyError(error);
    }
  }

  void _queueSave() {
    _saveTimer?.cancel();
    _book.updatedAt = DateTime.now();
    _saveTimer = Timer(const Duration(milliseconds: 550), () async {
      if (mounted) setState(() => _saving = true);
      try {
        await _repo.save(_book);
      } catch (error) {
        _notifyError(error);
      } finally {
        if (mounted) setState(() => _saving = false);
      }
    });
  }

  void _notifyError(Object error) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Không thể thực hiện: $error')),
    );
  }

  void _captureHistory() {
    _undo.add(_page.duplicate(_page.id));
    if (_undo.length > 40) _undo.removeAt(0);
    _redo.clear();
  }

  void _restoreSnapshot(NotePage snapshot) {
    _page.strokes = [for (final s in snapshot.strokes) s.clone()];
    _page.elements = [for (final e in snapshot.elements) e.clone()];
    _page.pattern = snapshot.pattern;
    _page.backgroundImageBase64 = snapshot.backgroundImageBase64;
    _page.backgroundAssetId = snapshot.backgroundAssetId;
    _contentRevision++;
    _clearSelection();
  }

  void _undoAction() {
    if (_undo.isEmpty) return;
    setState(() {
      _redo.add(_page.duplicate(_page.id));
      _restoreSnapshot(_undo.removeLast());
    });
    _loadPageBackground();
    _queueSave();
  }

  void _redoAction() {
    if (_redo.isEmpty) return;
    setState(() {
      _undo.add(_page.duplicate(_page.id));
      _restoreSnapshot(_redo.removeLast());
    });
    _loadPageBackground();
    _queueSave();
  }

  InkPoint _fromEvent(PointerEvent e) {
    var pressure = 1.0;
    if (e.kind == PointerDeviceKind.stylus && e.pressureMax > e.pressureMin) {
      pressure = 0.5 + 0.8 *
          ((e.pressure - e.pressureMin) / (e.pressureMax - e.pressureMin));
    }
    return InkPoint(e.localPosition.dx.clamp(0.0, paperWidth).toDouble(),
        e.localPosition.dy.clamp(0.0, paperHeight).toDouble(), pressure);
  }

  void _down(PointerDownEvent e) {
    if (_tool == DrawingTool.hand || _activePointer != null) return;
    if (!InkInputPolicy(stylusOnly: _stylusOnly).accepts(e.kind)) return;
    if (e.kind == PointerDeviceKind.mouse && e.buttons != kPrimaryButton) return;
    if (_tool == DrawingTool.text) {
      _textDialog(at: e.localPosition);
      return;
    }
    _activePointer = e.pointer;
    _erasedThisGesture = false;
    if (_tool == DrawingTool.eraser) {
      setState(_clearSelection);
      _eraseAt(e.localPosition);
      return;
    }
    if (_tool == DrawingTool.lasso) {
      setState(() {
        _clearSelection();
        _lassoPath.add(e.localPosition);
      });
      return;
    }
    if (_tool == DrawingTool.select) {
      _selectionStart = e.localPosition;
      _selectionMoved = false;
      _resizeSelection = false;
      final single = _singleElementIndex;
      if (single != null && _selectedStrokes.isEmpty &&
          single < _page.elements.length) {
        final handle = PagePainter.elementBounds(
          _page.elements[single]).inflate(6).bottomRight;
        if ((e.localPosition - handle).distance <= 25) {
          _resizeSelection = true;
        }
      }
      if (!_resizeSelection) {
        final onSelectedElement = _selectedElements.any((i) =>
          i >= 0 && i < _page.elements.length &&
          PagePainter.elementBounds(_page.elements[i])
              .inflate(8).contains(e.localPosition));
        final onSelectedStroke = _selectedStrokes.any((i) =>
          i >= 0 && i < _page.strokes.length && PagePainter.touchesStroke(
            _page.strokes[i], e.localPosition, radius: 20));
        if (!onSelectedElement && !onSelectedStroke) {
          final element = _page.elements.lastIndexWhere((item) =>
            PagePainter.elementBounds(item).contains(e.localPosition));
          final stroke = element < 0 ? _page.strokes.lastIndexWhere((item) =>
            PagePainter.touchesStroke(item, e.localPosition, radius: 15)) : -1;
          setState(() {
            _clearSelection();
            if (element >= 0) _selectedElements.add(element);
            if (stroke >= 0) _selectedStrokes.add(stroke);
          });
          _selectionStart = e.localPosition;
        }
      }
      _originalSelectedStrokes.clear();
      for (final index in _selectedStrokes) {
        _originalSelectedStrokes[index] = _page.strokes[index].clone();
      }
      _originalSelectedElements.clear();
      for (final index in _selectedElements) {
        _originalSelectedElements[index] = _page.elements[index].clone();
      }
      return;
    }
    _captureHistory();
    final point = _fromEvent(e);
    _active = InkStroke(kind: _tool.name,
      color: _color.toARGB32(),
      width: _tool == DrawingTool.marker ? _size * 5 : _size,
      points: [point]);
    setState(() {});
  }

  void _move(PointerMoveEvent e) {
    if (_activePointer != e.pointer) return;
    if (_tool == DrawingTool.eraser) {
      _eraseAt(e.localPosition);
      return;
    }
    if (_tool == DrawingTool.lasso) {
      if (_lassoPath.isEmpty ||
          (e.localPosition - _lassoPath.last).distance > 3) {
        setState(() => _lassoPath.add(e.localPosition));
      }
      return;
    }
    if (_tool == DrawingTool.select) {
      final start = _selectionStart;
      if (start == null || !_hasSelection) return;
      final delta = e.localPosition - start;
      if (!_selectionMoved && delta.distance > 2) {
        _captureHistory();
        _selectionMoved = true;
      }
      if (!_selectionMoved) return;
      setState(() {
        for (final entry in _originalSelectedStrokes.entries) {
          _page.strokes[entry.key] = entry.value.translated(delta.dx, delta.dy);
        }
        for (final entry in _originalSelectedElements.entries) {
          final index = entry.key;
          final base = entry.value;
          if (_resizeSelection && _singleElementIndex == index) {
            _page.elements[index] = base.copyWith(
              width: (base.width + delta.dx).clamp(
                60.0, (paperWidth - base.x).clamp(60.0, paperWidth)).toDouble(),
              height: (base.height + delta.dy).clamp(
                40.0, (paperHeight - base.y).clamp(40.0, paperHeight)).toDouble(),
            );
          } else {
            _page.elements[index] = base.translated(delta.dx, delta.dy);
          }
        }
        _contentRevision++;
      });
      return;
    }
    if (_active == null) return;
    final point = _fromEvent(e);
    if (_tool == DrawingTool.pen || _tool == DrawingTool.marker) {
      final previous = _active!.points.last;
      final distance = (Offset(point.x, point.y) - Offset(previous.x, previous.y)).distance;
      if (distance < 0.6) return;
      _active!.points.add(point);
    } else {
      if (_active!.points.length == 1) {
        _active!.points.add(point);
      } else {
        _active!.points[1] = point;
      }
    }
    setState(() {});
  }

  void _up(PointerEvent e) {
    if (_activePointer != e.pointer) return;
    _activePointer = null;
    if (_tool == DrawingTool.lasso) {
      final polygon = List<Offset>.of(_lassoPath)..add(e.localPosition);
      setState(() {
        _lassoPath.clear();
        _selectedStrokes.clear();
        _selectedElements.clear();
        for (var i = 0; i < _page.strokes.length; i++) {
          if (LassoGeometry.selectsStroke(_page.strokes[i], polygon)) {
            _selectedStrokes.add(i);
          }
        }
        for (var i = 0; i < _page.elements.length; i++) {
          if (LassoGeometry.intersectsRect(
              PagePainter.elementBounds(_page.elements[i]), polygon)) {
            _selectedElements.add(i);
          }
        }
        _tool = DrawingTool.select;
      });
      if (_hasSelection) _notify('Đã khoanh chọn: kéo đối tượng hoặc chọn Sao chép / Xóa');
      return;
    }
    if (_tool == DrawingTool.select) {
      if (_selectionMoved) _queueSave();
      _originalSelectedStrokes.clear();
      _originalSelectedElements.clear();
      _selectionStart = null;
      _selectionMoved = false;
      _resizeSelection = false;
      return;
    }
    if (_active != null) {
      setState(() {
        _page.strokes.add(_active!);
        _active = null;
        _contentRevision++;
      });
      _queueSave();
    } else if (_erasedThisGesture) {
      _queueSave();
    }
  }

  void _cancel(PointerCancelEvent e) {
    if (_activePointer != e.pointer) return;
    _activePointer = null;
    if (_tool == DrawingTool.lasso) {
      setState(() => _lassoPath.clear());
      return;
    }
    if (_tool == DrawingTool.select) {
      if (_selectionMoved && _undo.isNotEmpty) {
        setState(() => _restoreSnapshot(_undo.removeLast()));
        _loadPageBackground();
      }
      _originalSelectedStrokes.clear();
      _originalSelectedElements.clear();
      _selectionStart = null;
      _selectionMoved = false;
      _resizeSelection = false;
      return;
    }
    if (_active != null && _undo.isNotEmpty) _undo.removeLast();
    setState(() => _active = null);
    if (_erasedThisGesture) _queueSave();
  }

  void _eraseAt(Offset position) {
    final touches = _page.strokes.any((s) => PagePainter.touchesStroke(s, position));
    if (!touches) return;
    if (!_erasedThisGesture) {
      _captureHistory();
      _erasedThisGesture = true;
    }
    setState(() {
      _page.strokes.removeWhere((s) => PagePainter.touchesStroke(s, position));
      _contentRevision++;
    });
  }

  void _selectPage(int index) {
    if (index == _pageIndex) return;
    setState(() {
      _pageIndex = index;
      _active = null;
      _activePointer = null;
      _clearSelection();
    });
    _loadPageBackground();
  }

  void _newPage() {
    setState(() {
      final newPage = NotePage(
        id: _nextId(),
        pattern: _page.pattern,
      );
      _pageHistory.recordInsert(newPage, _book.pages.length);
      _book.pages.add(newPage);
      _pageIndex = _book.pages.length - 1;
      _undo.clear();
      _redo.clear();
      _clearSelection();
    });
    _loadPageBackground();
    _queueSave();
  }

  Future<void> _deletePage() async {
    if (_book.pages.length <= 1) return;
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Xóa trang?'),
      content: const Text('Nội dung trang sẽ bị xóa khỏi sổ tay.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Hủy')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Xóa')),
      ],
    ));
    if (ok != true || !mounted) return;
    setState(() {
      _pageHistory.recordDelete(_page, _pageIndex);
      _book.pages.removeAt(_pageIndex);
      _pageIndex = _pageIndex.clamp(0, _book.pages.length - 1).toInt();
      _clearSelection();
    });
    _loadPageBackground();
    _queueSave();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Text('Đã xóa trang'),
      action: SnackBarAction(label: 'Hoàn tác', onPressed: _undoPageStructure),
    ));
  }

  void _undoPageStructure() {
    if (!_pageHistory.canUndo) return;
    setState(() {
      final destination = _pageHistory.undo(_book.pages);
      if (destination == null) return;
      _pageIndex = destination;
      _activePointer = null;
      _active = null;
      _contentRevision++;
      _clearSelection();
    });
    _loadPageBackground();
    _queueSave();
  }

  void _redoPageStructure() {
    if (!_pageHistory.canRedo) return;
    setState(() {
      final destination = _pageHistory.redo(_book.pages);
      if (destination == null) return;
      _pageIndex = destination;
      _activePointer = null;
      _active = null;
      _contentRevision++;
      _clearSelection();
    });
    _loadPageBackground();
    _queueSave();
  }

  Future<void> _rename() async {
    final controller = TextEditingController(text: _book.title);
    final value = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Đổi tên sổ tay'),
        content: TextField(controller: controller, autofocus: true,
          maxLength: 80, decoration: const InputDecoration(labelText: 'Tên sổ tay')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('Lưu')),
        ],
      ),
    );
    // Doi dialog hoan tat animation truoc khi dispose controller.
    Future<void>.delayed(const Duration(milliseconds: 350), controller.dispose);
    if (value == null || value.isEmpty) return;
    setState(() => _book.title = value);
    _queueSave();
  }

  Future<void> _export(String what) async {
    try {
      await _flushSave();
      final success = what == 'pdf'
          ? await ExportService.exportPdf(_book)
          : what == 'legacyBackup'
              ? await ExportService.exportLegacyBackup(_book)
              : await ExportService.exportBackup(_book);
      if (!mounted || !success) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã xuất tệp thành công')));
    } catch (error) {
      _notifyError(error);
    }
  }

  void _fit(double viewportW, double viewportH) {
    final scale = (viewportW / (paperWidth + 64))
        .clamp(0.25, 1.0).toDouble();
    final yFit = (viewportH / (paperHeight + 50)).clamp(0.25, 1.0).toDouble();
    final s = scale < yFit ? scale : yFit;
    final x = (viewportW - paperWidth * s) / 2;
    final y = (viewportH - paperHeight * s) / 2;
    _transform.value = Matrix4.identity()
      ..translate(x, y)
      ..scale(s);
  }

  void _zoom(double factor) {
    _transform.value = _transform.value.clone()..scale(factor);
  }

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.sizeOf(context).width > 700;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: InkWell(
          onTap: _rename,
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Flexible(child: Text(_book.title, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 17))),
            const SizedBox(width: 5), const Icon(Icons.edit_outlined, size: 16),
          ]),
        ),
        actions: [
          if (_importing) const Padding(
            padding: EdgeInsets.symmetric(horizontal: 8),
            child: Center(child: SizedBox(width: 16, height: 16,
              child: CircularProgressIndicator(strokeWidth: 2))),
          ),
          if (_saving) const Padding(
            padding: EdgeInsets.symmetric(horizontal: 8),
            child: Center(child: SizedBox(width: 16, height: 16,
              child: CircularProgressIndicator(strokeWidth: 2))),
          ),
          if (_hasSelection) IconButton(tooltip: 'Sao chép',
            onPressed: _copySelection, icon: const Icon(Icons.content_copy_outlined)),
          if (_clipboard != null && !_clipboard!.isEmpty)
            IconButton(tooltip: 'Dán', onPressed: _pasteSelection,
              icon: const Icon(Icons.content_paste_outlined)),
          IconButton(tooltip: 'Hoàn tác', onPressed: _undo.isEmpty ? null : _undoAction,
            icon: const Icon(Icons.undo)),
          IconButton(tooltip: 'Làm lại', onPressed: _redo.isEmpty ? null : _redoAction,
            icon: const Icon(Icons.redo)),
          PopupMenuButton<String>(
            tooltip: 'Tệp và xuất',
            onSelected: (v) {
              if (v == 'pdf' || v == 'backup' || v == 'legacyBackup') _export(v);
              if (v == 'undoPage') _undoPageStructure();
              if (v == 'redoPage') _redoPageStructure();
              if (v == 'stylusOnly') setState(() => _stylusOnly = !_stylusOnly);
              if (v == 'deletePage') _deletePage();
              if (v == 'duplicatePage') _duplicatePage();
              if (v == 'importPdf') _importPdfPages();
              if (v == 'imageBackground') _importImageBackground();
              if (v == 'imageOverlay') _insertOverlayImage();
              if (v == 'editText') _editSelectedText();
              if (v == 'removeBackground') {
                _captureHistory();
                setState(() { _page.backgroundImageBase64 = null; _page.backgroundAssetId = null; _contentRevision++; });
                _loadPageBackground();
                _queueSave();
              }
              if (v == 'deleteSelected') _deleteSelection();
              if (v == 'selectAll') _selectAllOnPage();
              if (v == 'duplicateSelected') _duplicateSelection();
              if (v == 'copySelected') _copySelection();
              if (v == 'pasteSelected') _pasteSelection();
            },
            itemBuilder: (ctx) => [
              const PopupMenuItem(value: 'pdf', child: Text('Xuất PDF')),
              const PopupMenuItem(value: 'backup', child: Text('Sao lưu ZIP (đề xuất)')),
              const PopupMenuItem(value: 'legacyBackup', child: Text('Sao lưu JSON cho bản cũ')),
              CheckedPopupMenuItem(value: 'stylusOnly', checked: _stylusOnly,
                child: const Text('Chỉ nhận bút khi viết')),
              if (_pageHistory.canUndo)
                const PopupMenuItem(value: 'undoPage', child: Text('Hoàn tác thêm/xóa trang')),
              if (_pageHistory.canRedo)
                const PopupMenuItem(value: 'redoPage', child: Text('Làm lại thêm/xóa trang')),
              const PopupMenuItem(value: 'importPdf', child: Text('Thêm các trang từ PDF')),
              const PopupMenuItem(value: 'imageBackground', child: Text('Chèn ảnh làm nền trang')),
              const PopupMenuItem(value: 'imageOverlay', child: Text('Chèn ảnh có thể di chuyển / đổi cỡ')),
              if (_page.backgroundImageBase64 != null || _page.backgroundAssetId != null)
                const PopupMenuItem(value: 'removeBackground', child: Text('Bỏ ảnh nền')),
              const PopupMenuItem(value: 'duplicatePage', child: Text('Nhân bản trang hiện tại')),
              const PopupMenuItem(value: 'selectAll', child: Text('Chọn tất cả đối tượng trong trang')),
              if (_clipboard != null && !_clipboard!.isEmpty)
                const PopupMenuItem(value: 'pasteSelected', child: Text('Dán đối tượng đã sao chép')), 
              if (_singleElementIndex != null &&
                  _page.elements[_singleElementIndex!].type == 'text')
                const PopupMenuItem(value: 'editText', child: Text('Sửa văn bản đã chọn')),
              if (_hasSelection) ...[
                const PopupMenuItem(value: 'copySelected', child: Text('Sao chép đối tượng đã chọn')),
                const PopupMenuItem(value: 'duplicateSelected', child: Text('Nhân bản đối tượng đã chọn')),
                const PopupMenuItem(value: 'deleteSelected', child: Text('Xóa đối tượng đã chọn')),
              ],
              if (_book.pages.length > 1)
                const PopupMenuItem(value: 'deletePage', child: Text('Xóa trang hiện tại')),
            ],
          ),
        ],
      ),
      body: Column(children: [
        _toolbar(),
        if (_stylusOnly) MaterialBanner(
          content: const Text('Chế độ chỉ bút: chạm bằng ngón tay không tạo nét viết. Bút cảm ứng thông thường có thể được nhận là ngón tay.'),
          actions: [TextButton(
            onPressed: () => setState(() => _stylusOnly = false),
            child: const Text('Tắt'),
          )],
        ),
        Expanded(child: Row(children: [
          if (wide) _pagesPanel(),
          Expanded(child: LayoutBuilder(builder: (context, constraints) {
            final view = Size(constraints.maxWidth, constraints.maxHeight);
            if (_viewportSize != view) {
              _viewportSize = view;
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (mounted) _fit(view.width, view.height);
              });
            }
            return ColoredBox(
              color: const Color(0xffe9edf6),
              child: Stack(children: [
                ClipRect(child: InteractiveViewer(
                  transformationController: _transform,
                  constrained: false,
                  boundaryMargin: const EdgeInsets.all(700),
                  minScale: 0.2,
                  maxScale: 5.0,
                  panEnabled: _tool == DrawingTool.hand,
                  scaleEnabled: _tool == DrawingTool.hand,
                  child: Container(
                    decoration: BoxDecoration(boxShadow: [BoxShadow(
                      color: Colors.black.withValues(alpha: 0.12),
                      blurRadius: 12, offset: const Offset(0, 4),
                    )]),
                    child: SizedBox(
                      width: paperWidth, height: paperHeight,
                      child: Listener(
                        behavior: HitTestBehavior.opaque,
                        onPointerDown: _down,
                        onPointerMove: _move,
                        onPointerUp: _up,
                        onPointerCancel: _cancel,
                        child: Stack(children: [
                          Positioned.fill(child: RepaintBoundary(child: CustomPaint(
                            painter: PagePainter(
                              pattern: _page.pattern,
                              strokes: _page.strokes,
                              elements: _page.elements,
                              background: _pageBackground,
                              elementImages: _elementImages,
                              revision: _contentRevision,
                              pageId: _page.id,
                            ),
                          ))),
                          Positioned.fill(child: IgnorePointer(child: CustomPaint(
                            painter: InkInteractionPainter(
                              preview: _active,
                              strokes: _page.strokes,
                              elements: _page.elements,
                              selectedStrokeIndices: _selectedStrokes,
                              selectedElementIndices: _selectedElements,
                              lassoPath: _lassoPath,
                            ),
                          ))),
                        ]),
                      ),
                    ),
                  ),
                )),
                Positioned(bottom: 14, right: 12, child: Row(children: [
                  _miniButton(Icons.remove, () => _zoom(0.8), 'Thu nhỏ'),
                  const SizedBox(width: 4),
                  _miniButton(Icons.fit_screen, () => _fit(view.width, view.height), 'Vừa trang'),
                  const SizedBox(width: 4),
                  _miniButton(Icons.add, () => _zoom(1.25), 'Phóng to'),
                ])),
              ]),
            );
          })),
        ])),
        if (!wide) _bottomPages(),
      ]),
    );
  }

  Widget _miniButton(IconData icon, VoidCallback onPressed, String tip) {
    return Material(
      color: Colors.white,
      elevation: 2,
      borderRadius: BorderRadius.circular(10),
      child: IconButton(icon: Icon(icon), tooltip: tip, onPressed: onPressed),
    );
  }

  Widget _toolbar() {
    final tools = <(DrawingTool, IconData, String)>[
      (DrawingTool.pen, Icons.edit, 'Bút'),
      (DrawingTool.marker, Icons.border_color, 'Dạ quang'),
      (DrawingTool.eraser, Icons.auto_fix_normal, 'Tẩy nét'),
      (DrawingTool.line, Icons.show_chart, 'Đường thẳng'),
      (DrawingTool.rectangle, Icons.crop_square, 'Chữ nhật'),
      (DrawingTool.ellipse, Icons.circle_outlined, 'Hình elip'),
      (DrawingTool.select, Icons.touch_app_outlined, 'Chọn và kéo đối tượng'),
      (DrawingTool.lasso, Icons.gesture, 'Khoanh chọn nhiều nét'),
      (DrawingTool.text, Icons.text_fields, 'Chạm trang để thêm văn bản'),
      (DrawingTool.hand, Icons.pan_tool_outlined, 'Di chuyển trang'),
    ];
    return Material(
      color: Colors.white,
      elevation: 1,
      child: SizedBox(height: 62, child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        children: [
          for (final (tool, icon, tooltip) in tools)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 8),
              child: Tooltip(
                message: tooltip,
                child: IconButton.filledTonal(
                  onPressed: () => setState(() {
                    _tool = tool;
                    if (tool != DrawingTool.select) _clearSelection();
                  }),
                  style: IconButton.styleFrom(
                    backgroundColor: _tool == tool
                        ? Theme.of(context).colorScheme.primaryContainer
                        : const Color(0xfff2f3f8),
                  ),
                  icon: Icon(icon, size: 22),
                ),
              ),
            ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 8),
            child: Tooltip(message: 'Chèn ảnh di chuyển / đổi cỡ',
              child: IconButton.filledTonal(
                onPressed: _insertOverlayImage,
                icon: const Icon(Icons.add_photo_alternate_outlined))),
          ),
          if (_hasSelection) ...[
            IconButton(tooltip: 'Nhân bản đối tượng chọn',
              onPressed: _duplicateSelection, icon: const Icon(Icons.content_copy_outlined)),
            IconButton(tooltip: 'Xóa đối tượng chọn',
              onPressed: _deleteSelection, icon: const Icon(Icons.delete_outline)),
          ],
          const VerticalDivider(indent: 12, endIndent: 12),
          for (final color in _colors)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 3),
              child: Center(child: GestureDetector(
                onTap: () => setState(() => _color = color),
                child: Container(
                  width: 27, height: 27,
                  decoration: BoxDecoration(
                    color: color,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _color == color ? Colors.black54 : Colors.white,
                      width: _color == color ? 3 : 1,
                    ),
                  ),
                ),
              )),
            ),
          const VerticalDivider(indent: 12, endIndent: 12),
          PopupMenuButton<double>(
            tooltip: 'Cỡ nét bút',
            onSelected: (v) => setState(() => _size = v),
            itemBuilder: (_) => [
              for (final value in [2.0, 3.0, 5.0, 8.0, 12.0])
                PopupMenuItem(value: value, child: Text('Nét ${value.toInt()} px')),
            ],
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Center(child: Text('${_size.toInt()} px')),
            ),
          ),
          const VerticalDivider(indent: 12, endIndent: 12),
          PopupMenuButton<PaperPattern>(
            tooltip: 'Kiểu giấy',
            onSelected: (value) {
              _captureHistory();
              setState(() { _page.pattern = value; _contentRevision++; });
              _queueSave();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: PaperPattern.blank, child: Text('Giấy trắng')),
              PopupMenuItem(value: PaperPattern.lined, child: Text('Giấy kẻ ngang')),
              PopupMenuItem(value: PaperPattern.grid, child: Text('Giấy ô vuông')),
              PopupMenuItem(value: PaperPattern.dots, child: Text('Giấy chấm')),
            ],
            icon: const Icon(Icons.grid_on),
          ),
        ],
      )),
    );
  }

  Widget _pagesPanel() => Container(
    width: 138,
    color: const Color(0xfffafbff),
    child: Column(children: [
      const Padding(
        padding: EdgeInsets.all(12),
        child: Text('TRANG GIẤY', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
      ),
      Expanded(child: ListView.builder(
        itemCount: _book.pages.length,
        itemBuilder: (ctx, i) => Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          child: Card(
            color: i == _pageIndex ? const Color(0xffdfe6ff) : Colors.white,
            child: InkWell(
              onTap: () => _selectPage(i),
              child: SizedBox(height: 95, child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [const Icon(Icons.description_outlined),
                  const SizedBox(height: 6), Text('Trang ${i + 1}')],
              )),
            ),
          ),
        ),
      )),
      Padding(padding: const EdgeInsets.all(10), child: FilledButton.icon(
        onPressed: _newPage, icon: const Icon(Icons.add), label: const Text('Thêm trang'),
      )),
    ]),
  );

  Widget _bottomPages() => Container(
    color: Colors.white,
    height: 55,
    child: Row(children: [
      Expanded(child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: _book.pages.length,
        itemBuilder: (ctx, i) => Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 7),
          child: ChoiceChip(
            label: Text('Trang ${i + 1}'),
            selected: i == _pageIndex,
            onSelected: (_) => _selectPage(i),
          ),
        ),
      )),
      IconButton(tooltip: 'Thêm trang', onPressed: _newPage,
        icon: const Icon(Icons.add_circle_outline)),
    ]),
  );
}
