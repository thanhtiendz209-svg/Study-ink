import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import '../models/notebook.dart';

class PagePainter extends CustomPainter {
  final PaperPattern pattern;
  final List<InkStroke> strokes;
  final List<PageElement> elements;
  final int revision;
  final String? pageId;
  final ui.Image? background;
  final Map<String, ui.Image> elementImages;

  PagePainter({
    required this.pattern,
    required this.strokes,
    this.elements = const [],
    this.revision = 0,
    this.pageId,
    this.background,
    this.elementImages = const {},
  });

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.clipRect(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, Paint()..color = Colors.white);
    if (background == null) {
      _drawPattern(canvas, size);
    } else {
      drawImageFitted(canvas, background!, Offset.zero & size);
    }
    for (final stroke in strokes) {
      drawStroke(canvas, stroke);
    }
    for (final element in elements) {
      drawElement(canvas, element, elementImages[element.id]);
    }
    canvas.restore();
  }

  static void drawImageFitted(Canvas canvas, ui.Image image, Rect rect) {
    final src = Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble());
    final srcRatio = src.width / src.height;
    final targetRatio = rect.width / rect.height;
    final target = srcRatio > targetRatio
        ? Rect.fromLTWH(rect.left, rect.top + (rect.height - rect.width / srcRatio) / 2,
            rect.width, rect.width / srcRatio)
        : Rect.fromLTWH(rect.left + (rect.width - rect.height * srcRatio) / 2,
            rect.top, rect.height * srcRatio, rect.height);
    canvas.drawImageRect(image, src, target, Paint()..filterQuality = FilterQuality.medium);
  }

  static Rect elementBounds(PageElement e) => Rect.fromLTWH(e.x, e.y, e.width, e.height);

  static void drawElement(Canvas canvas, PageElement e, ui.Image? image) {
    final rect = elementBounds(e);
    if (e.type == 'image') {
      if (image != null) {
        drawImageFitted(canvas, image, rect);
      } else {
        canvas.drawRect(rect, Paint()..color = const Color(0xffedf2fa));
        final label = TextPainter(
          text: const TextSpan(text: 'Ảnh chưa tải', style: TextStyle(
              color: Color(0xff5d6b83), fontSize: 18)),
          textDirection: TextDirection.ltr,
        )..layout(maxWidth: rect.width);
        label.paint(canvas, rect.topLeft + const Offset(8, 8));
        label.dispose();
      }
    } else if (e.type == 'text') {
      canvas.save();
      canvas.clipRect(rect);
      final painter = TextPainter(
        text: TextSpan(text: e.text, style: TextStyle(
          color: Color(e.color), fontSize: e.fontSize, height: 1.2,
        )),
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: rect.width);
      painter.paint(canvas, rect.topLeft);
      painter.dispose();
      canvas.restore();
    }
  }

  void _drawPattern(Canvas canvas, Size size) {
    if (pattern == PaperPattern.blank) return;
    const step = 32.0;
    final faint = Paint()..color = const Color(0xffdbe5f5)..strokeWidth = 0.8;
    if (pattern == PaperPattern.lined || pattern == PaperPattern.grid) {
      for (double y = step; y < size.height; y += step) {
        canvas.drawLine(Offset(0, y), Offset(size.width, y), faint);
      }
    }
    if (pattern == PaperPattern.grid) {
      for (double x = step; x < size.width; x += step) {
        canvas.drawLine(Offset(x, 0), Offset(x, size.height), faint);
      }
    }
    if (pattern == PaperPattern.dots) {
      for (double y = step; y < size.height; y += step) {
        for (double x = step; x < size.width; x += step) {
          canvas.drawCircle(Offset(x, y), 1.15, faint);
        }
      }
    }
    if (pattern == PaperPattern.lined) {
      canvas.drawLine(const Offset(72, 0), Offset(72, size.height),
          Paint()..color = const Color(0xfff5bdc5)..strokeWidth = 1.0);
    }
  }

  static void drawStroke(Canvas canvas, InkStroke stroke) {
    if (stroke.points.isEmpty) return;
    final color = Color(stroke.color).withValues(
      alpha: stroke.kind == 'marker' ? 0.32 : 1.0,
    );
    final paint = Paint()
      ..color = color
      ..strokeWidth = stroke.width
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..style = PaintingStyle.stroke
      ..isAntiAlias = true;
    final points = stroke.points;
    final start = Offset(points.first.x, points.first.y);
    if (stroke.kind == 'line' && points.length >= 2) {
      canvas.drawLine(start, Offset(points.last.x, points.last.y), paint);
      return;
    }
    if (stroke.kind == 'rectangle' && points.length >= 2) {
      canvas.drawRect(Rect.fromPoints(start,
          Offset(points.last.x, points.last.y)), paint);
      return;
    }
    if (stroke.kind == 'ellipse' && points.length >= 2) {
      canvas.drawOval(Rect.fromPoints(start,
          Offset(points.last.x, points.last.y)), paint);
      return;
    }
    if (points.length == 1) {
      canvas.drawCircle(start, stroke.width / 2, Paint()..color = color);
      return;
    }
    // Use one smoothed quadratic path for uniform-pressure strokes. This
    // drastically reduces draw calls compared with one drawLine per sample.
    final varyingPressure = points.any((p) => (p.pressure - points.first.pressure).abs() > 0.08);
    if (!varyingPressure) {
      paint.strokeWidth = stroke.width * points.first.pressure.clamp(0.45, 1.6);
      canvas.drawPath(smoothPath(points), paint);
      return;
    }
    // Preserve stylus pressure variation for pens that report it.
    for (var i = 1; i < points.length; i++) {
      final prev = points[i - 1];
      final next = points[i];
      paint.strokeWidth = stroke.width *
          ((prev.pressure + next.pressure) / 2).clamp(0.45, 1.6);
      canvas.drawLine(Offset(prev.x, prev.y), Offset(next.x, next.y), paint);
    }
  }

  /// Smooths mouse/touch input without modifying original saved samples.
  static Path smoothPath(List<InkPoint> points) {
    final path = Path();
    if (points.isEmpty) return path;
    path.moveTo(points.first.x, points.first.y);
    if (points.length == 1) return path;
    for (var i = 1; i < points.length - 1; i++) {
      final a = points[i];
      final b = points[i + 1];
      path.quadraticBezierTo(a.x, a.y, (a.x + b.x) / 2, (a.y + b.y) / 2);
    }
    path.lineTo(points.last.x, points.last.y);
    return path;
  }

  static Rect? strokeBounds(InkStroke stroke) {
    if (stroke.points.isEmpty) return null;
    var left = stroke.points.first.x;
    var top = stroke.points.first.y;
    var right = left;
    var bottom = top;
    for (final point in stroke.points.skip(1)) {
      left = math.min(left, point.x);
      top = math.min(top, point.y);
      right = math.max(right, point.x);
      bottom = math.max(bottom, point.y);
    }
    return Rect.fromLTRB(left, top, right, bottom).inflate(stroke.width / 2);
  }

  static bool touchesStroke(InkStroke s, Offset position, {double radius = 11}) {
    if (s.points.isEmpty) return false;
    final points = s.points;
    final threshold = radius + s.width / 2;
    if (points.length == 1) {
      return (position - Offset(points.first.x, points.first.y)).distance <= threshold;
    }
    if (s.kind == 'rectangle' || s.kind == 'ellipse') {
      final a = Offset(points.first.x, points.first.y);
      final b = Offset(points.last.x, points.last.y);
      final rect = Rect.fromPoints(a, b).inflate(threshold);
      if (!rect.contains(position)) return false;
      if (s.kind == 'rectangle') {
        return !Rect.fromPoints(a, b).deflate(threshold).contains(position);
      }
      final cx = (a.dx + b.dx) / 2;
      final cy = (a.dy + b.dy) / 2;
      final rx = (a.dx - b.dx).abs() / 2;
      final ry = (a.dy - b.dy).abs() / 2;
      if (rx < 1 || ry < 1) return true;
      final v = math.pow((position.dx - cx) / rx, 2) +
          math.pow((position.dy - cy) / ry, 2);
      return (v - 1).abs() * math.min(rx, ry) < 2 * threshold;
    }
    for (var i = 1; i < points.length; i++) {
      final a = Offset(points[i - 1].x, points[i - 1].y);
      final b = Offset(points[i].x, points[i].y);
      if (_distanceToSegment(position, a, b) <= threshold) return true;
    }
    return false;
  }

  static double _distanceToSegment(Offset p, Offset a, Offset b) {
    final d = b - a;
    final squared = d.dx * d.dx + d.dy * d.dy;
    if (squared == 0) return (p - a).distance;
    final t = (((p.dx - a.dx) * d.dx + (p.dy - a.dy) * d.dy) /
            squared).clamp(0.0, 1.0);
    return (p - Offset(a.dx + d.dx * t, a.dy + d.dy * t)).distance;
  }

  @override
  bool shouldRepaint(covariant PagePainter old) =>
      old.revision != revision || old.pageId != pageId ||
      old.background != background || old.elementImages != elementImages ||
      old.pattern != pattern || old.strokes != strokes ||
      old.elements != elements;
}

/// Foreground layer: repaint the active stroke/selection without repainting
/// the PDF background and thousands of committed strokes underneath.
class InkInteractionPainter extends CustomPainter {
  final InkStroke? preview;
  final List<InkStroke> strokes;
  final List<PageElement> elements;
  final Set<int> selectedStrokeIndices;
  final Set<int> selectedElementIndices;
  final List<Offset> lassoPath;

  InkInteractionPainter({
    required this.preview,
    required this.strokes,
    required this.elements,
    required this.selectedStrokeIndices,
    required this.selectedElementIndices,
    required this.lassoPath,
  });

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.clipRect(Offset.zero & size);
    if (preview != null) PagePainter.drawStroke(canvas, preview!);
    Rect? selection;
    for (final index in selectedStrokeIndices) {
      if (index < 0 || index >= strokes.length) continue;
      final r = PagePainter.strokeBounds(strokes[index]);
      if (r != null) selection = selection == null ? r : selection.expandToInclude(r);
    }
    for (final index in selectedElementIndices) {
      if (index < 0 || index >= elements.length) continue;
      final r = PagePainter.elementBounds(elements[index]);
      selection = selection == null ? r : selection.expandToInclude(r);
    }
    if (selection != null) {
      final outline = selection.inflate(6);
      canvas.drawRect(outline, Paint()
        ..color = const Color(0xff3569f6)
        ..strokeWidth = 2.2
        ..style = PaintingStyle.stroke);
      if (selectedElementIndices.length == 1 && selectedStrokeIndices.isEmpty) {
        canvas.drawCircle(outline.bottomRight, 9,
            Paint()..color = const Color(0xff3569f6));
        canvas.drawCircle(outline.bottomRight, 4, Paint()..color = Colors.white);
      }
    }
    if (lassoPath.length >= 2) {
      final path = Path()..moveTo(lassoPath.first.dx, lassoPath.first.dy);
      for (final point in lassoPath.skip(1)) {
        path.lineTo(point.dx, point.dy);
      }
      canvas.drawPath(path, Paint()
        ..color = const Color(0xff377cff)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5);
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant InkInteractionPainter old) => true;
}
