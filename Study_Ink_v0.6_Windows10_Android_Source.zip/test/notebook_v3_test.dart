import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:study_ink/models/notebook.dart';

void main() {
  test('v3 text and image overlay survive JSON round-trip', () {
    final book = Notebook.create();
    final page = book.pages.first;
    page.elements.add(PageElement(
      id: 'text_1', type: 'text', x: 11, y: 20,
      width: 300, height: 100, text: 'x² + y² = 1',
      fontSize: 36, color: 0xff1369be,
    ));
    page.elements.add(PageElement(
      id: 'image_1', type: 'image', x: 120, y: 150,
      width: 250, height: 180, imageBase64: base64Encode([137, 80, 78]),
    ));
    final restored = Notebook.decode(book.encode());
    expect(restored.toJson()['schemaVersion'], 4);
    expect(restored.pages.single.elements, hasLength(2));
    expect(restored.pages.single.elements.first.text, 'x² + y² = 1');
    expect(restored.pages.single.elements.first.fontSize, 36);
    expect(restored.pages.single.elements.last.imageBase64, page.elements.last.imageBase64);
  });

  test('page duplicate deep-copies editable objects', () {
    final page = NotePage(id: 'orig');
    page.elements.add(PageElement(
      id: 'label', type: 'text', x: 5, y: 6,
      width: 180, height: 70, text: 'Hello',
    ));
    final duplicate = page.duplicate('clone');
    duplicate.elements.first.x = 99;
    duplicate.elements.first.text = 'Changed';
    expect(page.elements.first.x, 5);
    expect(page.elements.first.text, 'Hello');
    expect(duplicate.id, 'clone');
  });

  test('legacy v2 format loads with empty overlay list', () {
    final input = {
      'format': 'studyink', 'schemaVersion': 2,
      'id': 'old2', 'title': 'Old', 'updatedAt': '2026-10-01T12:00:00',
      'pages': [{'id': 'page', 'pattern': 'grid', 'strokes': [],
        'backgroundImageBase64': 'ABC'}],
    };
    final book = Notebook.decode(jsonEncode(input));
    expect(book.pages.first.elements, isEmpty);
    expect(book.pages.first.backgroundImageBase64, 'ABC');
  });

  test('rejects unexpected element type', () {
    expect(() => PageElement.fromJson({'type': 'script', 'id': 'x'}),
        throwsFormatException);
  });
}
