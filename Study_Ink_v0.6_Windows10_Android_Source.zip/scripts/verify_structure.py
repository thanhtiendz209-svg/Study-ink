"""Static, non-compiler sanity checks. Run `flutter analyze` for real validation."""
from pathlib import Path
import re

root = Path(__file__).resolve().parent.parent
required = [
    'pubspec.yaml', 'analysis_options.yaml', 'lib/main.dart',
    'lib/models/notebook.dart', 'lib/widgets/page_painter.dart',
    'lib/services/notebook_repository.dart', 'lib/services/export_service.dart',
    'lib/screens/library_screen.dart', 'lib/screens/editor_screen.dart',
    'test/notebook_test.dart', 'test/page_painter_test.dart',
    'test/notebook_v3_test.dart', 'test/lasso_geometry_test.dart',
    'lib/utils/lasso_geometry.dart',
    'lib/models/notebook_summary.dart',
    'lib/widgets/pdf_range_dialog.dart',
    'test/notebook_summary_test.dart', 'test/ink_v04_test.dart',
    'lib/models/selection_clipboard.dart',
    'lib/services/notebook_asset_store.dart',
    'lib/services/portable_backup.dart',
    'test/clipboard_v05_test.dart',
    'test/media_v05_test.dart',
    'test/portable_backup_v05_test.dart',
    'lib/services/zip_notebook_backup.dart',
    'lib/models/page_structure_history.dart',
    'lib/utils/ink_input_policy.dart',
    'test/zip_backup_v06_test.dart',
    'test/page_history_v06_test.dart',
    'test/input_policy_v06_test.dart',
    '.github/workflows/build.yml', 'README.md', 'docs/ROADMAP.md',
    'docs/DATA_FORMAT.md',
]
for relative in required:
    f = root / relative
    assert f.exists() and f.stat().st_size > 0, f'Missing or empty: {relative}'
for f in root.rglob('*.dart'):
    content = f.read_text('utf-8')
    for m in re.finditer(r"(?:import|export)\s+['\"](\.\.?/[^'\"]+)['\"]", content):
        local = (f.parent / m.group(1)).resolve()
        assert local.is_file(), f'Broken relative import in {f}: {m.group(1)}'
    assert '\ufffd' not in content, f'Encoding replacement character in {f}'
print(f'PASS: {len(required)} required files, relative imports, UTF-8 source')
print('NOTE: dart/flutter runtime NOT available; compiler and integration tests not run.')
